#ifndef RPAG_H
#define RPAG_H

#include "types.h"

typedef enum {LL_FPGA,HL_FPGA,LL_ASIC,HL_ASIC} cost_model_t;

class rpag
{
public:
  rpag();
  virtual ~rpag();

  //user specified parameters:
  cost_model_t cost_model;
  bool exhaustive;

  double rand_variance;
  int rand_seed;
  int no_of_runs; //number of runs (with random variance)

  int mult_wordsize;
  int max_no_of_mult;
  int stages_embedded_mult;
  int no_of_extra_stages;
  bool force_minimal_depth;
  static int input_wordsize;
  int meta_greedy_search_depth;

  vector<int> wordsize_constraints;
  vector<int> adder_depth_constraints;

  bool msd_successor_evaluation; //determines, if predecessors are computed from all MSDs for gain calculation (more precise but more time consuming)  

  int optimize(const int_set_t *target_set);

protected:

  int optimize_single_run(const int_set_t *target_fun_set, pipeline_set_t *pipeline_set);

  //internal parameters:
  int_t c_max;

  int stages_input_pag;
  int stages_output_pag;

  static double cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_hl_fpga(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_hl_fpga(int_t x);
  static double cost_pag_hl_fpga(pipeline_set_t *pipeline_set);

  static double cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_ll_fpga(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_ll_fpga(int_t x);
  static double cost_pag_ll_fpga(pipeline_set_t *pipeline_set);

  static double cost_add_hl_asic(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_hl_asic(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_hl_asic(int_t x);
  static double cost_pag_hl_asic(pipeline_set_t *pipeline_set);


  //function pointer to selected cost model:
  double (*cost_add)(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  double (*cost_ternary_add)(int_t x, int_t u, int_t v, int_t w);
  double (*cost_reg)(int_t x);
  double (*cost_pag)(pipeline_set_t *pipeline_set);

  void compute_topology_a_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_a=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_b_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_b=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_c_predecessors_2_Add_I(const int_set_t *working_set, const int_set_t *predecessor_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_c=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_d_predecessors_2_Add_I(int_t x, int nz_max, int ws_max, int_pair_set_t *predecessor_pair_set);

  int get_rand_variance_decision(int min_decision);

  virtual int adder_depth(int_t x);

  int_vec_t decision_vec;
  int_vec_t decision_max_vec;
  unsigned decision_cnt;

private:
  //###################################################################
  virtual inline bool is_this_a_two_input_system(void){return true;}

  virtual int_t get_best_single_predecessor(const int_set_t &working_set, const int_set_t &predecessor_set, int s);
  virtual void get_best_multi_predecessor(const int_set_t &working_set, int_set_t *predecessor_set, int s);

  int_t compute_c_max(int_t target_fun_max);

  int initialize(const int_set_t* target_set, int_set_t* target_fun_set);
  int create_constraints(int adder_depth_max, int target_wordsize_max);
  void check_constraints(int no_of_pipeline_stages);
  int validate_parameters();

};

#endif // RPAG_H
