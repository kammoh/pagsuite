#include "types.h"

void compute_successor_set(int_t r1, int_t r2, int_t c_max, int_set_t *successor_set, bool erase_predecessor = true, bool two_input_adder = true);
void compute_successor_set(const int_set_t *r1_set, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor = true, bool two_input_adder = true);

void compute_successor_set(const int_set_t *realized_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor=true, bool two_input_adder = true);
void compute_successor_set(int_t r1, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor=true, bool two_input_adder = true);

void compute_successor_set(int_t r1, int_t r2, int_t r3, int_t c_max, int_set_t *successor_set, bool erase_predecessor=true);

void permut(int &a, int &b, int &c, int &k, int &l, int index);
