#ifndef LOG2_64_H
#define LOG2_64_H

#include <inttypes.h>

int log2f_64(uint64_t n);
int log2c_64(uint64_t n);

int log3f_64(uint64_t n);
int log3c_64(uint64_t n);

#endif // LOG2_64_H
