#ifndef TYPES_H
#define TYPES_H

#include <vector>
#include <set>
#include <map>
#include <list>
#include <ostream>

#define UNUSED(x) (void)(x)
#define MAX_INT32 2147483647;
#define MAX_UINT32 4294967295;

using namespace std;

//typedef int int_t; //type of integer numbers
typedef long long int_t; //type of integer numbers
typedef vector<int_t> int_vec_t;
typedef set<int_t> int_set_t;

typedef vector<int_set_t> pipeline_set_t;

typedef vector<int> sd_t;
typedef set<sd_t> msd_set_t;

typedef map<int_t, double> int_double_map_t;

typedef pair<int_t,int_t> int_pair_t;
typedef set<int_pair_t> int_pair_set_t;
typedef map<int_pair_t, double> int_pair_double_map_t;


class int_double_map_cmp
{
  public:
  bool operator()(const std::pair<int_t,double> &a, const std::pair<int_t,double> &b)
  {
    return a.second < b.second;
  }
};

class int_double_map_cmp_both
{
  public:
  bool operator()(const std::pair<int_t,double> &a, const std::pair<int_t,double> &b)
  {
    if(a.second == b.second)
    {
      return a.first < b.first;
    }
    else
    {
      return a.second < b.second;
    }
  }
};

class int_pair_double_map_cmp
{
  public:
  bool operator()(const std::pair<int_pair_t,double> &a, const std::pair<int_pair_t,double> &b)
  {
    return a.second < b.second;
  }
};



template <typename T1, typename T2, typename T3>
class triplet
{
public:

  T1 first;
  T2 second;
  T3 third;

  triplet(){}
  triplet(T1 f, T2 s, T3 t)
  {
    first   = f;
    second  = s;
    third   = t;
  }
  bool operator==(triplet input)
  {
    if((first == input.first)&&(second == input.second)&&(third == input.third))
    {
      return true;
    }
    else
    {
      return false;
    }
  }
  bool operator!=(triplet input)
  {
    if((*this) == input)
    {
      return false;
    }
    else
    {
      return true;
    }
  }
  void operator=(triplet input)
  {
    first = input.first;
    second = input.second;
    third = input.third;
  }
  bool operator < (const triplet& input) const
  {
    if(third == input.third)
    {
      if(second == input.second)
      {
        return first < input.first;
      }
      else
      {
        return second < input.second;
      }
    }
    else
    {
      return third < input.third;
    }
  }

};

typedef triplet<int_t, int_t, int_t> int_triplet_t;
typedef set<int_triplet_t> int_triplet_set_t;
typedef map<int_triplet_t, double> int_triplet_double_map_t;


class int_triplet_double_map_cmp
{
  public:
  bool operator()(const std::pair<int_triplet_t,double> &a, const std::pair<int_triplet_t,double> &b)
  {
    return a.second < b.second;
  }
};

#endif //TYPES_H
