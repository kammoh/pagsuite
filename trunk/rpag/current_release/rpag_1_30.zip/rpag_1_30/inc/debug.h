#ifndef _DEBUG_H
#define _DEBUG_H

#include <cassert>
#include <iostream>
#include <iomanip>

#include "types.h"

#define DEBUG

using namespace std;

extern int global_verbose;

#define IF_VERBOSE(verbose) if(global_verbose >= verbose) for(int i=0; i < verbose; i++) cout << "  "; if(global_verbose >= verbose)
//#define IF_VERBOSE(verbose) cout << verb(0); if(global_verbose >= verbose)
//#define IF_VERBOSE(verbose) if(global_verbose >= verbose)

ostream& operator<<(ostream &s, sd_t& sd);
ostream& operator<<(ostream &s, int_vec_t& vec);
ostream& operator<<(ostream &s, int_set_t &st);
ostream& operator<<(ostream &s, pipeline_set_t& ps);
ostream& operator<<(ostream &s, int_double_map_t& gain_map);
ostream& operator<<(ostream &s, int_pair_double_map_t& int_pair_double_map);
ostream& operator<<(ostream &s, msd_set_t& msd_set);
ostream& operator<<(ostream &s, int_pair_t& int_pair);
ostream& operator<<(ostream &s, int_pair_set_t& int_pair_set);

ostream& operator<<(ostream &s, int_triplet_t& int_triplet);
ostream& operator<<(ostream &s, int_triplet_double_map_t& int_triplet_double_map);

#endif //_DEBUG_H


