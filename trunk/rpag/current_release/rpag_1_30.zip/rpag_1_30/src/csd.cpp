#include "csd.h"
#include "debug.h"


void dec2bin(int_t x, sd_t* csd)
{
  assert(x > 0);
  while(x != 0)
  {
    csd->push_back(x & 1);
    x = x >> 1;
  }
}

int csd_replace(sd_t* csd)
{
  bool replace=false;
  sd_t::iterator iter;
  sd_t::iterator end_iter=csd->end();
  for (iter=csd->begin(); iter != end_iter; ++iter)
  {
    if(*iter == 1)
    {
      if(replace)
      {
        *iter = 0;
      }
      else if(iter+1 != end_iter)
      {
        if(*(iter+1) == 1)
        {
          *iter = -1;
          replace = true;
        }
      }
    }
    else if(replace && (*iter == 0))
    {
      *iter = 1;
      return 0;
    }
  }
  if(replace)
  {
    csd->push_back(1);
  }
  return 1;
}

int dec2csd(int_t x, sd_t* csd)
{
  dec2bin(x, csd);
  IF_VERBOSE(7) cout << x << ": bin=" << *csd << endl;

  while(!csd_replace(csd)) ;

  IF_VERBOSE(7) cout << x << ": csd=" << *csd << endl;
  return 1;
}

int nonzeros(sd_t *sd)
{
  sd_t::iterator iter;
  int nz=0;
  for (iter=sd->begin(); iter != sd->end(); ++iter)
  {
    if(*iter != 0)
      nz++;
  }
  return nz;
}

int nonzeros(int_t x)
{
  sd_t csd;
  dec2csd(x,&csd);
  return nonzeros(&csd);
}

void dec2msd(int_t x, msd_set_t* msd_set)
{
  sd_t msd,msd_next;
  msd_set_t msd_next_set;

  dec2csd(x,&msd);

  IF_VERBOSE(6) cout << "csd representation of " << x << ": " << msd << endl;

  msd_set->insert(msd);
  msd_next_set = *msd_set;

  do
  {
    msd = (*msd_next_set.begin());
    msd_next_set.erase(msd);

    for (unsigned int i=0; i < msd.size()-2; i++)
    {
      if((msd[i]==-1) && (msd[i+1]==0) && (msd[i+2]==1))
      {
        msd_next = msd;
        msd_next[i]=1;
        msd_next[i+1]=1;
        msd_next[i+2]=0;
        IF_VERBOSE(6) cout << "new msd representation of " << x << " found: " << msd_next << endl;
        msd_next_set.insert(msd_next);
        msd_set->insert(msd_next);
      }
      else if((msd[i]==1) && (msd[i+1]==0) && (msd[i+2]==-1))
      {
        msd_next = msd;
        msd_next[i]=-1;
        msd_next[i+1]=-1;
        msd_next[i+2]=0;
        IF_VERBOSE(6) cout << "new msd representation of " << x << " found: " << msd_next << endl;
        msd_next_set.insert(msd_next);
        msd_set->insert(msd_next);
      }
    }
  } while(!msd_next_set.empty());

  IF_VERBOSE(5) cout << "msd_set=" << *msd_set << endl;
}
