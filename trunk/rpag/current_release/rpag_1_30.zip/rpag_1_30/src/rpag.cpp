#include "rpag.h"
#include "adder_depth.h"
#include "fundamental.h"
#include "log2_64.h"
#include "debug.h"
#include "csd.h"
#include "compute_successor_set.h"
#include <utility>
#include <cmath>
#include <cstdlib>
#include <algorithm>

rpag::rpag()
{
  //default values:
  cost_model=HL_FPGA;
  exhaustive=false;
  max_no_of_mult=-1; //no limit of multipliers
  mult_wordsize=-1;  //no multipliers used
  stages_embedded_mult=-1; //no of pipeline stages used for multiplication
  msd_successor_evaluation=true;
//  extra_pipeline_stages=0;
  stages_input_pag=-1;
  stages_output_pag=-1;
  force_minimal_depth=false;
  input_wordsize=-1;
  no_of_extra_stages=0;

  rand_variance=0.0;
  rand_seed=-1;
  no_of_runs=1;
  meta_greedy_search_depth=10;
}

rpag::~rpag()
{}

int rpag::input_wordsize;

/*** cost functions for high-level FPGA model ***/

#if 1
double rpag::cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  return no_of_predecessors_used;
}

#else

double rpag::cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  if(no_of_predecessors_used == 1)
  {
//    return (double) log2c_64(nonzeros(x)); //(2)
//    return ((double) nonzeros(u))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)))/((double) log2c_64(nonzeros(x))); //(3b)
    return ((double) log2c_64(u))/((double) log2c_64(x)); //(3c)
  }
  else
  {
//    return (double) log2c_64(nonzeros(x)); //(2)
//    return ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)) + log2c_64(nonzeros(v)))/((double) log2c_64(nonzeros(x))); //(3b)
    return ((double) log2c_64(u) + log2c_64(v))/((double) log2c_64(x)); //(3c)
  }
}

#endif

double rpag::cost_ternary_add_hl_fpga(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return 1;
}

double rpag::cost_reg_hl_fpga(int_t x)
{
  UNUSED(x);
  return 1;
}

double rpag::cost_pag_hl_fpga(pipeline_set_t *pipeline_set)
{
  double pag_cost=0;

  for(unsigned s=0; s < pipeline_set->size(); s++)
  {
    pag_cost += ((double) (*pipeline_set)[s].size());
  }
  return pag_cost;
}


/*** cost functions for low-level FPGA model ***/

#if 0
double rpag::cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(u);
  UNUSED(v);
  return input_wordsize+log2c_64(x);
}
#else
double factor = 1.0;

double rpag::cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  assert(no_of_predecessors_used <= 2);

  if(no_of_predecessors_used == 0)
  {
    return 1; //(1)
//    return input_wordsize+log2c_64(x); //(2)
//    return 1; //(3a-d)
//    return 1.0; //(4)
  }
  else if(no_of_predecessors_used == 1)
  {
    return 1; //(1)
//    return input_wordsize+log2c_64(x); //(2)
//    return ((double) nonzeros(u))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)))/((double) log2c_64(nonzeros(x))); //(3b)
//    return ((double) log2c_64(u))/((double) log2c_64(x)); //(3c)
//    return ((double) input_wordsize+log2c_64(u))/((double) input_wordsize+log2c_64(x)); //(3c)
//    return 1.0/(1.0 + factor*(1.0 - ((double) nonzeros(u))/((double) nonzeros(x))) ); //(4a)
//    return 1.0/(1.0 + factor*(1.0 - ((double) input_wordsize+log2c_64(u))/((double) input_wordsize+log2c_64(x))) ); //(4b)
  }
  else
  {
//    cout << "no_of_predecessors_used=" << no_of_predecessors_used << endl;
    return 2; //(1)
//    return 2*input_wordsize+log2c_64(x); //(2)
//    return ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)) + log2c_64(nonzeros(v)))/((double) log2c_64(nonzeros(x))); //(3b)
//    return ((double) log2c_64(u) + log2c_64(v))/((double) log2c_64(x)); //(3c)
//    return ((double) 2*input_wordsize + log2c_64(u) + log2c_64(v))/((double) input_wordsize + log2c_64(x)); //(3c)
//    return 1.0/(1.0 + factor*(1.0 - ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x))) ); //(4a)
//    return 1.0/(1.0 + factor*(1.0 - ((double) 2*input_wordsize+log2c_64(u)+log2c_64(v))/((double) input_wordsize+log2c_64(x))) ); //(4b)
  }
}
#endif

double rpag::cost_ternary_add_ll_fpga(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return input_wordsize+log2c_64(x);
}

#if 0
double rpag::cost_reg_ll_fpga(int_t x)
{
  return input_wordsize+log2c_64(x);
}
#else
double rpag::cost_reg_ll_fpga(int_t x)
{
  return cost_add_ll_fpga(x,0,0,0);
}
#endif


double rpag::cost_pag_ll_fpga(pipeline_set_t *pipeline_set)
{  
  int_set_t::iterator set_iter;
  double cost=0.0;

  for(unsigned s=0; s < pipeline_set->size(); s++)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      cost += ((double) input_wordsize+log2c_64(*set_iter));
    }
  }
  return cost;
}

/*** cost functions for high-level ASIC model ***/


double rpag::cost_add_hl_asic(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  return 2*no_of_predecessors_used;
}

double rpag::cost_ternary_add_hl_asic(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return 4;
}

double rpag::cost_reg_hl_asic(int_t x)
{
  UNUSED(x);
  return 1;
}

double rpag::cost_pag_hl_asic(pipeline_set_t *pipeline_set)
{
  UNUSED(pipeline_set);
  cerr << "unsupported cost model!" << endl;
  return -1;
}

int_t rpag::get_best_single_predecessor(const int_set_t &working_set, const int_set_t &predecessor_set, int s)
{
  int_set_t::iterator set_iter;
  int_set_t p_set_a,p_set_b,p_set_c,p_set_d;
  int_double_map_t single_p_gain_map;

  IF_VERBOSE(3) cout << "searching for best single predecessor ..." << endl;
  IF_VERBOSE(5)
  {
    compute_topology_a_predecessors_2_Add_I(&working_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1], &p_set_a);
    cout << "p_set_a=" << p_set_a << endl;

    compute_topology_b_predecessors_2_Add_I(&working_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1],&p_set_b);
    cout << "p_set_b=" << p_set_b << endl;

    compute_topology_c_predecessors_2_Add_I(&working_set, &predecessor_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1],&p_set_c);
    IF_VERBOSE(5) cout << "p_set_c=" << p_set_c << endl;

  }
  else
  {
      compute_topology_a_predecessors_2_Add_I(&working_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1]);
      compute_topology_b_predecessors_2_Add_I(&working_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1]);
      compute_topology_c_predecessors_2_Add_I(&working_set, &predecessor_set, &single_p_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1]);
  }

  //remove already chosen predecessors from gain map:
  for(set_iter = predecessor_set.begin(); set_iter != predecessor_set.end(); ++set_iter)
  {
    single_p_gain_map.erase(*set_iter);
  }
  IF_VERBOSE(3) cout << "gain_map=" << single_p_gain_map << endl;

  if(single_p_gain_map.empty())
    return -1;

  int_t best_single_predecessor;
  int_double_map_t::iterator single_p_gain_map_iter;

  int decision = get_rand_variance_decision(single_p_gain_map.size()-1);
  IF_VERBOSE(3) cout << "rand variance decision= " << decision << endl;

  //remove the best N (which is equal to 'decision') elements from set:
  for(int i=0; i < decision; i++)
  {
    single_p_gain_map_iter = max_element(single_p_gain_map.begin(), single_p_gain_map.end(), int_double_map_cmp());
    single_p_gain_map.erase((*single_p_gain_map_iter).first);
  }
  single_p_gain_map_iter = max_element(single_p_gain_map.begin(), single_p_gain_map.end(), int_double_map_cmp());
  best_single_predecessor = (*single_p_gain_map_iter).first;

  IF_VERBOSE(5) cout << "best single gain map: " << (*single_p_gain_map_iter).first << "," << (*single_p_gain_map_iter).second << endl;

  IF_VERBOSE(3) cout << "choosing best predecessor to " << best_single_predecessor << endl;
  return best_single_predecessor;

}
void  rpag::get_best_multi_predecessor(const int_set_t &working_set, int_set_t *predecessor_set, int s)
{
  IF_VERBOSE(3) cout << "searching for best single predecessor pairs ..." << endl;
  int_set_t::iterator set_iter;

  int nz_max;

  if(adder_depth_constraints[s-1] >= 0)
    nz_max = 1 << adder_depth_constraints[s-1];
  else
    nz_max = -1;

  IF_VERBOSE(3) cout << "optimizing for wordsize constraint=" << wordsize_constraints[s-1] << ", max. nonzeros constraint=" << nz_max << ", adder depth constraint=" << adder_depth_constraints[s-1] << endl;

  //ab hier
  IF_VERBOSE(3) cout << "searching for best predecessor pair from MSD using max. nonzeros=" << nz_max << " and max. wordsize " << wordsize_constraints[s-1] << endl;

  int_pair_set_t predecessor_pair_set;
  int_pair_set_t::iterator p_set_iter;
  int_pair_double_map_t pair_gain_map;

  int_set_t successor_set;
  int_set_t realized_target_set;


  double gain, gain_max=0;
  int_pair_t predecessor_pair,predecessor_pair_best;


  int_set_t::iterator working_set_iter;

  for(working_set_iter = working_set.begin(); working_set_iter != working_set.end(); ++working_set_iter)
  {
    int_t w=*working_set_iter;

    compute_topology_d_predecessors_2_Add_I(w, nz_max, wordsize_constraints[s-1], &predecessor_pair_set);

    for(p_set_iter=predecessor_pair_set.begin(); p_set_iter != predecessor_pair_set.end(); ++p_set_iter)
    {
      predecessor_pair = *p_set_iter;

      if(msd_successor_evaluation)
      {
        if(pair_gain_map.find(predecessor_pair) == pair_gain_map.end())
        {
          successor_set.clear();
          compute_successor_set(predecessor_pair.first, predecessor_pair.second, c_max, &successor_set, false);

          realized_target_set.clear();
          set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

          for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          {
            gain = pair_gain_map[predecessor_pair] + 1.0 / (cost_add(*set_iter,predecessor_pair.first,predecessor_pair.second,2));
            pair_gain_map[predecessor_pair] = gain;
          }
        }
      }
      else
      {
        gain = pair_gain_map[predecessor_pair] + 1.0 / (cost_add(w,predecessor_pair.first,predecessor_pair.second,2));
        pair_gain_map[predecessor_pair] = gain;
      }
    }
    predecessor_pair_set.clear();
  }

  IF_VERBOSE(4) cout << "predecessor pair gain map=" << pair_gain_map << endl;

  //select best predecessor pair:
  int decision = get_rand_variance_decision(pair_gain_map.size()-1);
  IF_VERBOSE(4) cout << "rand variance decision= " << decision << endl;

  int_pair_double_map_t::iterator pair_gain_map_iter;

  //remove the best N (which is equal to 'decision') elements from set:
  for(int i=0; i < decision; i++)
  {
    pair_gain_map_iter = max_element(pair_gain_map.begin(), pair_gain_map.end(), int_pair_double_map_cmp());
    pair_gain_map.erase((*pair_gain_map_iter).first);
  }
  pair_gain_map_iter = max_element(pair_gain_map.begin(), pair_gain_map.end(), int_pair_double_map_cmp());
  predecessor_pair_best = (*pair_gain_map_iter).first;
  gain_max = (*pair_gain_map_iter).second;

  IF_VERBOSE(3) cout << "best predecessor pair: " << predecessor_pair_best << " with gain " << gain_max << endl;

  if((predecessor_pair_best.first == 0) && (predecessor_pair_best.second == 0))
  {
    cerr << "Error: no predecessors were found (maybe optimization plan is too tough?)" << endl;
    flush(cerr);
    exit(-1);
  }
  predecessor_set->insert(predecessor_pair_best.first);
  predecessor_set->insert(predecessor_pair_best.second);

}
int_t rpag::compute_c_max(int_t target_fun_max)
{
  return 1LL << (log2c_64(target_fun_max)+1);
}

int rpag::adder_depth(int_t x)
{
  assert(is_this_a_two_input_system());
  return log2c_64(nonzeros(x));
}

void rpag::compute_topology_a_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *single_p_gain_map, int s_max, int ws_max, int_set_t *p_set_a, int_pair_double_map_t *p_w_gain_map)
{
  IF_VERBOSE(4) cout << "compute 2-input predecessors for topology a (register)" << endl;
  int_set_t::iterator set_iter;
  for(set_iter = working_set->begin(); set_iter != working_set->end(); ++set_iter)
  {
    int_t w = *set_iter;
    if(((s_max < 0) || (adder_depth(w) <= s_max)) && ((ws_max < 0) || (log2c_64(w) <= ws_max)))
    {
      IF_VERBOSE(4) cout << "**case 2a met for c=" << *set_iter << " (p'=" << *set_iter << ")" << endl;
      if(p_set_a != NULL)
        p_set_a->insert(w);

      if(single_p_gain_map != NULL)
        (*single_p_gain_map)[w] = (*single_p_gain_map)[w] + 1/cost_reg(w);

      if(p_w_gain_map != NULL)
        (*p_w_gain_map)[int_pair_t(w,w)] = max((*p_w_gain_map)[int_pair_t(w,w)],1/cost_reg(w));
    }
  }
}

void rpag::compute_topology_b_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *single_p_gain_map, int s_max, int ws_max, int_set_t *p_set_b, int_pair_double_map_t *p_w_gain_map)
{
  IF_VERBOSE(4) cout << "compute 2-input predecessors for topology b" << endl;
  flush(cout);
  int_set_t::iterator set_iter;
  for(set_iter = working_set->begin(); set_iter != working_set->end(); ++set_iter)
  {
    int k=2;
    int_t div=3,quot;
    int_t w=*set_iter;
    while(div <= w)
    {
      div=(1LL << k)-1; //=2^k-1
      if((w % div) == 0)
      {
        quot=w/div;
        if(((s_max < 0) || (adder_depth(quot) <= s_max)) && ((ws_max < 0) || (log2c_64(quot) <= ws_max)))
        {
          IF_VERBOSE(4) cout << "**case 2b met for w=" << w << " (p'=" << quot << ")" << endl;

          if(p_set_b != NULL)
            p_set_b->insert(quot);

          if(single_p_gain_map != NULL)
            (*single_p_gain_map)[quot] = (*single_p_gain_map)[quot] + 1/cost_add(w,quot,quot,1);

          if(p_w_gain_map != NULL)
            (*p_w_gain_map)[int_pair_t(quot,w)] = max((*p_w_gain_map)[int_pair_t(quot,w)],1/cost_add(w,quot,quot,1));
        }
      }
      div += 2; //=2^k+1
      if((w % div) == 0)
      {
        quot=w/div;
        if(((s_max < 0) || (adder_depth(quot) <= s_max)) && ((ws_max < 0) || (log2c_64(quot) <= ws_max)))
        {
          IF_VERBOSE(4) cout << "**case 2b met for w=" << w << " (p'=" << quot << ")" << endl;

          if(p_set_b != NULL)
            p_set_b->insert(quot);

          if(single_p_gain_map != NULL)
            (*single_p_gain_map)[quot] = (*single_p_gain_map)[quot] + 1/cost_add(w,quot,quot,1);

          if(p_w_gain_map != NULL)
            (*p_w_gain_map)[int_pair_t(quot,w)] = max((*p_w_gain_map)[int_pair_t(quot,w)],1/cost_add(w,quot,quot,1));
        }
      }
      k++;
    }
  }
}

void rpag::compute_topology_c_predecessors_2_Add_I(const int_set_t *working_set, const int_set_t *predecessor_set, int_double_map_t *single_p_gain_map, int s_max, int ws_max, int_set_t *p_set_c, int_pair_double_map_t *p_w_gain_map)
{
  IF_VERBOSE(4) cout << "compute 2-input predecessors for topology c" << endl;
  if(!predecessor_set->empty())
  {
    int_set_t::iterator working_set_iter;
    int_set_t::iterator potential_set_iter;
    int_set_t::iterator predecessor_set_iter;

    int_set_t predecessor_ignore_set; //set for predecessors that have to be ignored to avoid double counting predecessors of the same element in working set

    int_set_t potential_predecessors;
    for(working_set_iter = working_set->begin(); working_set_iter != working_set->end(); ++working_set_iter)
    {
      int_t w = *working_set_iter;
      predecessor_ignore_set.clear();

      for(predecessor_set_iter = predecessor_set->begin(); predecessor_set_iter != predecessor_set->end(); ++predecessor_set_iter)
      {
        int_t p_realized = *predecessor_set_iter;
        compute_successor_set(w, p_realized, c_max, &potential_predecessors);

        for(potential_set_iter = potential_predecessors.begin(); potential_set_iter != potential_predecessors.end(); ++potential_set_iter)
        {
          int_t p = *potential_set_iter;
          if(((s_max < 0) || (adder_depth(p) <= s_max)) && ((ws_max < 0) || (log2c_64(p) <= ws_max)))
          {
            IF_VERBOSE(4) cout << "**case 2c met for w=" << w << " (p=" << p << ", p'=" << p_realized << ")" << endl;

            if(p_set_c != NULL)
              p_set_c->insert(p);

            if(single_p_gain_map != NULL)
            {
              if(predecessor_ignore_set.find(p) == predecessor_ignore_set.end())
              {
                (*single_p_gain_map)[p] = (*single_p_gain_map)[p] + 1/cost_add(w,p,p_realized,1);
                predecessor_ignore_set.insert(p);
              }
              else
              {
                IF_VERBOSE(5) cout << "-> ignored for gain" << endl;
              }
            }

            if(p_w_gain_map != NULL)
              (*p_w_gain_map)[int_pair_t(p,w)] = max((*p_w_gain_map)[int_pair_t(p,w)],1/cost_add(w,p,p_realized,1));

          }
        }
        potential_predecessors.clear();
      }
    }

  }
}

void rpag::compute_topology_d_predecessors_2_Add_I(int_t x, int nz_max, int ws_max, int_pair_set_t *predecessor_pair_set)
{
  IF_VERBOSE(4) cout << "compute 2-input predecessors for topology d (pairs)" << endl;

  msd_set_t msd_set;

  int ws = log2c_64(x);

  //if max. nonzeros are unconstrained, use wordsize-1
  if(nz_max < 0)
  {
    nz_max=ws-1;
  }

  IF_VERBOSE(4) cout << "max. nonzeros:" << nz_max << endl;
  IF_VERBOSE(4) cout << "max. wordsize:" << ws_max << endl;
  IF_VERBOSE(4) cout << "ws(" << x << ") = " << ws << endl;
  dec2msd(x, &msd_set);
  IF_VERBOSE(5) cout << "msd_set(" << x << "):" << endl << msd_set << endl;

  msd_set_t::iterator msd_set_iter;
  for(msd_set_iter = msd_set.begin(); msd_set_iter != msd_set.end(); ++msd_set_iter)
  {
    sd_t msd = *msd_set_iter;
    int nz = nonzeros(&msd);

    IF_VERBOSE(5) cout << "msd(" << x << ")=" << msd << ", nz=" << nz << endl;

    vector<int> nonzero_values(nz);        //vector that stores signs of nonzero values
    vector<int_t> nonzero_shift_factor(nz); //vector that stores the shift weight (2^"shift factor")

    //fill nonzero_values and nonzero_shift_factor with data:
    vector<int>::iterator int_vector_iter;
    int i=0;
    int_t shift_factor=0;
    for (int_vector_iter=msd.begin(); int_vector_iter != msd.end(); ++int_vector_iter)
    {
      if(*int_vector_iter != 0)
      {
        nonzero_values[i]=*int_vector_iter;
        nonzero_shift_factor[i]=shift_factor;
        i++;
      }
      shift_factor++;
    }
    IF_VERBOSE(5) cout << "nonzero_values=" << nonzero_values << endl;
    IF_VERBOSE(5) cout << "nonzero_shift_factor=" << nonzero_shift_factor << endl;

    //iterate for different nonzero count for the left side predecessor p1 (the right side predecessor p2 has size nz-nz_p1):
    int nz_p2;

    for(int nz_p1=nz_max; nz_p1 > 0; nz_p1--)
    {
      if(nz_p1 >= nz)
        continue;

      nz_p2=nz-nz_p1;
      if(nz_p2 > nz_max)
        break;

      IF_VERBOSE(5) cout << "nz_p1=" << nz_p1 << ", nz_p2=" << nz_p2 << endl;
      vector<int> left_nonzero_indices(nz_p1); //vector left_nonzeros is used to address the nonzeros which are used for one part of the pair

      //init left_nonzero_indices:
      for(int i=0; i < nz_p1; i++)
      {
        left_nonzero_indices[i] = i;
      }

      //permutate left_nonzero_indices:
      int_t p1,p2;
      int ws_p1,ws_p2;  //word size of p1 and p2
      int index;
      while(true) //do permutation: (if(index < 0) break;)
      {
        index=nz_p1-1;
        p1=0;
        //evaluate nonzero_values:
        for(int i=0; i < nz_p1; i++)
        {
          p1 += ((int_t) nonzero_values[left_nonzero_indices[i]]) << nonzero_shift_factor[left_nonzero_indices[i]];
        }

        int min_index_p2,max_index_p2;

        if(ws_max > 0)
        {
          //detect wordsize of p1 and p2:

          IF_VERBOSE(6) cout << "left_nonzero_indices=" << left_nonzero_indices << endl;

          int min_index_p1,max_index_p1;
          min_index_p1=left_nonzero_indices[0];
          max_index_p1=left_nonzero_indices[nz_p1-1];

          //wordsize of p1 can be directly determined:
          ws_p1 = nonzero_shift_factor[max_index_p1]-nonzero_shift_factor[min_index_p1]+1;
          IF_VERBOSE(6) cout << "min. index p1=" << left_nonzero_indices[0] << " max. index p1=" << left_nonzero_indices[nz_p1-1] << " wordsize p1=" << ws_p1 << endl;

          // if wordsize constraint of p1 is met, check p2:
          if(ws_p1 <= ws_max)
          {
            int i;
            //to find the first index of p2, search for the first occurrence of an index step by 2:
            for(i=0; i < nz_p1; i++)
            {
              if(i != left_nonzero_indices[i])
                break;
            }
            min_index_p2 = i; //min index is step position

            //to find the last index of p2, search backwards for the first occurrence of an index step by -2:
            int j=0;
            for(i=nz_p1-1; i >= 0; i--, j++)
            {
              if(left_nonzero_indices[i] != nz-1-j)
                break;
            }
            max_index_p2 = nz-1-j;
            ws_p2 = nonzero_shift_factor[max_index_p2]-nonzero_shift_factor[min_index_p2]+1;
            IF_VERBOSE(6) cout << "min. index p2=" << min_index_p2 << " max. index p2=" << max_index_p2 << " wordsize p2=" << ws_p2 << endl;
          }
        }

        //for constrained wordsize, check wordsize for p1 and p2 before computing them, otherwise continue with permutation:
        if((ws_max < 0) || ((ws_p1 <= ws_max) && (ws_p2 <= ws_max)))
        {
          p2 = x - p1;
          IF_VERBOSE(7) cout << "left_nonzero_indices=" << left_nonzero_indices << ": (" << x << "=" << p1 << "+" << p2 << ")";

          p1 = fundamental(abs(p1));
          p2 = fundamental(abs(p2));
          IF_VERBOSE(5) cout  << " fun pair: (" << p1 << "," << p2 << ")" << endl;

          if(ws_max > 0)
          {
            if(!((log2f_64(p1)+1==ws_p1) || (log2f_64(p1)+2==ws_p1)) || !((log2f_64(p2)+1==ws_p2) || (log2f_64(p2)+2==ws_p2)))
            {
              cout << "nonzero_values=" << nonzero_values << endl;
              cout << "nonzero_shift_factor=" << nonzero_shift_factor << endl;
              cout << "left_nonzero_indices=" << left_nonzero_indices << ": fun pair: (" << p1 << "," << p2 << ")" << endl;
              cout << "min. index p1=" << left_nonzero_indices[0] << " max. index p1=" << left_nonzero_indices[nz_p1-1] << " wordsize p1=" << ws_p1 << endl;
              cout << "min. index p2=" << min_index_p2 << " max. index p2=" << max_index_p2 << " wordsize p2=" << ws_p2 << endl;
              cout << "?? wl_p1: " << log2f_64(p1)+1 << "<=" <<  ws_p1 << "??" << endl;
              cout << "?? wl_p2: " << log2f_64(p2)+1 << "<=" <<  ws_p2 << "??" << endl;
            }
            assert((log2f_64(p1)+1==ws_p1) || (log2f_64(p1)+2==ws_p1));
            assert((log2f_64(p2)+1==ws_p2) || (log2f_64(p2)+2==ws_p2));
          }

          if(p2 < p1) //swap elements such that p1 <= p2
          {
            int_t tmp=p1;
            p1=p2;
            p2=tmp;
          }
          predecessor_pair_set->insert(int_pair_t(p1,p2));
        }

        //do permutation:
        while(left_nonzero_indices[index] >= nz-1-(nz_p1-1-index))
        {
          index--;
          if(index < 0)
            break;
        }
        if(index < 0)
          break;

        if(left_nonzero_indices[index] < nz-1-(nz_p1-1-index))
          left_nonzero_indices[index]++;

        for(;index < nz_p1-1;index++)
        {
          if(left_nonzero_indices[index] < nz-1)
            left_nonzero_indices[index+1] = left_nonzero_indices[index]+1;
        }
      }
    }
  }

  IF_VERBOSE(4) cout << "predecessor_pair_set=" << *predecessor_pair_set << endl;
}

int rpag::get_rand_variance_decision(int decision_max)
{
  int decision;

  if((meta_greedy_search_depth <= 0) && (rand_variance > 0) && (decision_max > 0))
  {
    //random selection heuristic is selected:
    double rnd=(double) rand()/RAND_MAX;
    decision = round(rnd*min(rand_variance,((double) decision_max)));
  }
  else
  {
    decision=0;
  }

  if(decision_cnt >= decision_vec.size())
  {
    //decision vector length is less than actual decision -> enlarge vector
    decision_vec.push_back(decision);
    decision_max_vec.push_back(decision_max);
  }
  else
  {
    //decision vector length is large enough, read from or write result (for debug) to this vector
    if(meta_greedy_search_depth > 0)
    {
      decision = decision_vec[decision_cnt];
      decision_max_vec[decision_cnt] = decision_max;
    }
    else
    {
      decision_vec[decision_cnt] = decision;
    }
  }
  decision_cnt++;

//  IF_VERBOSE(0) cout << "decision=" << decision << endl;
  return decision;
}

int rpag::initialize(const int_set_t* target_set, int_set_t* target_fun_set)
{
  int_set_t::iterator set_iter;
  int ad,ad_max=0,no_of_pipeline_stages;

  srand(rand_seed); //set random seed

  if(adder_depth_constraints.size() != wordsize_constraints.size())
  {
    cerr << "Error: adder depth and word size constraints must be of equal length!" << endl;
    exit(1);
  }

  if((max_no_of_mult > 0) && (mult_wordsize < 0))
  {
    cerr << "Error: No multiplier word size is given.";
    exit(-1);

  }

  //select cost model:
  switch(cost_model)
  {
  case HL_FPGA:
    IF_VERBOSE(2) cout << "using hl_fpga cost model" << endl;
    cost_add = cost_add_hl_fpga;
    cost_ternary_add = cost_ternary_add_hl_fpga;
    cost_reg = cost_reg_hl_fpga;
    cost_pag = cost_pag_hl_fpga;
    break;
  case LL_FPGA:
    IF_VERBOSE(2) cout << "using ll_fpga cost model" << endl;
    if(input_wordsize < 0)
    {
      cerr << "Error: input word size necessary for ll_fpga cost model (parameter: --input_wordsize)" << endl;
      exit(-1);
    }
    cost_add = cost_add_ll_fpga;
    cost_ternary_add = cost_ternary_add_ll_fpga;
    cost_reg = cost_reg_ll_fpga;
    cost_pag = cost_pag_ll_fpga;
    break;
  case LL_ASIC:
    cerr << "Error: LL_ASIC cost model currently not supported!" << endl;
    exit(-1);
    break;
  case HL_ASIC:
    IF_VERBOSE(2) cout << "using hl_asic cost model" << endl;
    cost_add = cost_add_hl_asic;
    cost_ternary_add = cost_ternary_add_hl_asic;
    cost_reg = cost_reg_hl_asic;
    cost_pag = cost_pag_hl_asic;
  }

  if(max_no_of_mult == 0)
    mult_wordsize=-1;

  //compute fundamentals and adder depths:
  int_t fun;
  for(set_iter = target_set->begin(); set_iter != target_set->end(); ++set_iter)
  {
    fun = fundamental(abs(*set_iter));
    if(fun > 0)
      target_fun_set->insert(fun);
  }
  IF_VERBOSE(2) cout << "target fundamentals=" << *target_fun_set << endl;

  int_t target_fun_max=0;
  for(set_iter = target_fun_set->begin(); set_iter != target_fun_set->end(); ++set_iter)
  {
    ad = adder_depth(*set_iter);
    IF_VERBOSE(5) cout << "adder_depth(" << *set_iter << ")=" << ad << endl;
    if(ad > ad_max)
      ad_max = ad;

    if(*set_iter > target_fun_max)
      target_fun_max = *set_iter;
  }

  c_max = this->compute_c_max(target_fun_max);

  IF_VERBOSE(2) cout << "c_max=" << c_max << endl;

  int target_wordsize_max = log2c_64(target_fun_max);

  IF_VERBOSE(2) cout << "max target value is " << target_fun_max << ", max target word size is " << target_wordsize_max << " bit" << endl;

  if((adder_depth_constraints.size() == 0) && (wordsize_constraints.size() == 0))
  {
    IF_VERBOSE(3) cout << "Determining adder depth and word size constraints" << endl;
    create_constraints(ad_max + no_of_extra_stages,target_wordsize_max);
    no_of_pipeline_stages=stages_output_pag+stages_input_pag;
  }
  else
  {
    if(mult_wordsize > 0)
    {
      stages_input_pag = log2c_64(mult_wordsize+1)-1;
      no_of_pipeline_stages = adder_depth_constraints.size();
      stages_output_pag = no_of_pipeline_stages - stages_input_pag + no_of_extra_stages;
    }
    else
    {
      stages_input_pag = adder_depth_constraints.size() + no_of_extra_stages;
      no_of_pipeline_stages = stages_input_pag;
      stages_output_pag = 0;
    }
  }


  IF_VERBOSE(2) cout << "optimization plan:" << endl;
  for(int s=0; s < no_of_pipeline_stages; s++)
  {
    IF_VERBOSE(2) cout << "stage " << s+1 << ", wordsize constraint=" << wordsize_constraints[s] << ", adder depth constraint=" << adder_depth_constraints[s] << endl;
  }

  return no_of_pipeline_stages;
}

int rpag::optimize(const int_set_t *target_set)
{
  int_set_t target_fun_set;
  int no_of_pipeline_stages = initialize(target_set,&target_fun_set);
  unsigned act_decision_no=0,act_decision_value=0;
  unsigned act_decision_value_best=0;

  check_constraints(no_of_pipeline_stages);

  //  validate_parameters();
  IF_VERBOSE(2) cout << "No of pipeline stages: " << no_of_pipeline_stages << endl;

  double rand_variance = this->rand_variance;

  pipeline_set_t pipeline_set(no_of_pipeline_stages),pipeline_set_best(no_of_pipeline_stages);
  double pag_cost,pag_cost_best=10E10;

  for(int i=0; (i < no_of_runs) || (meta_greedy_search_depth > 0); i++)
  {
    //if several runs are done, the first one should be without random variance
    if((no_of_runs > 1) && (i==0))
    {
      this->rand_variance = 0.0;
    }
    else
    {
      this->rand_variance = rand_variance;
    }

    optimize_single_run(&target_fun_set,&pipeline_set);

    //check total cost of result:
    pag_cost = cost_pag(&pipeline_set);
    if(pag_cost < pag_cost_best)
    {
      pag_cost_best = pag_cost;
      pipeline_set_best = pipeline_set;
      act_decision_value_best = act_decision_value;
    }

    IF_VERBOSE(1) cout << "iteration " << i << ": decision_vec=(" << decision_vec << "), pag_cost=" << pag_cost << ", pipeline_set=" << pipeline_set << endl;
//    IF_VERBOSE(0) cout << "decision_vec=(" << decision_vec << ")" << endl;
//    IF_VERBOSE(0) cout << "decision_max_vec=(" << decision_max_vec << ")" << endl;


    //adjust decision vector:
    if(meta_greedy_search_depth > 0)
    {
      if(decision_cnt < decision_vec.size())
      {
        decision_vec.resize(decision_cnt);
        decision_max_vec.resize(decision_cnt);
        if(act_decision_no >= decision_cnt) break; //decision vector was resized in one of the last iteration -> exit optimization loop
      }
      if((((int) act_decision_value) < meta_greedy_search_depth) && (act_decision_value < decision_max_vec[act_decision_no]))
      {
        act_decision_value++;
      }
      else
      {
        act_decision_value=0;
        if(act_decision_no < decision_cnt-1)
        {
          decision_vec[act_decision_no] = act_decision_value_best;
          act_decision_value_best=0;
          act_decision_no++;
        }
        else
        {
          break; //exit optimization loop
        }
      }
      decision_vec[act_decision_no] = act_decision_value;
    }

  }

  IF_VERBOSE(0) cout << "best result: pag_cost=" << pag_cost_best << ", pipeline_set_best=" << pipeline_set_best << endl;
//  cout << pag_cost_best << endl;


  return 1;
}

int rpag::optimize_single_run(const int_set_t *target_fun_set, pipeline_set_t *pipeline_set)
{
  int_set_t::iterator set_iter;
  int s=0;

  decision_cnt = 0; //reset decision counter

  int no_of_pipeline_stages = pipeline_set->size();

  if((stages_embedded_mult < 0) && (mult_wordsize > 0))
  {
    stages_embedded_mult = stages_input_pag;
    IF_VERBOSE(2) cout << "Embedded multiplier pipeline stages: " << stages_embedded_mult << endl;
  }

  //Variables, sets and maps needed during optimization
  int_set_t embedded_mult_set;
  int_set_t working_set;
  int_set_t predecessor_set;

  embedded_mult_set.clear();
  working_set.clear();
  predecessor_set.clear();


  int_t best_single_predecessor;
  int_set_t best_multi_predecessor_set;

  int_set_t successor_set;
  int_set_t realized_target_set;

  int no_of_stages_skipped=0;

  if(no_of_pipeline_stages == 0)
  {
    //all elements can be realized using embedded multipliers
    embedded_mult_set = *target_fun_set;
    goto finito;
  }

#if 1
  (*pipeline_set)[no_of_pipeline_stages-1] = *target_fun_set;
#else
  //test!!!
  (*pipeline_set)[2].insert(7567);
  (*pipeline_set)[3].insert(1);
  (*pipeline_set)[3].insert(10203);
  (*pipeline_set)[4].insert(1);
  (*pipeline_set)[4].insert(10203);
  (*pipeline_set)[5].insert(7567);
#endif

  //############################################################################################################//
  //######################################      main optimization loop   #######################################//
  //############################################################################################################//
  for(s=no_of_pipeline_stages-1; s > 0; s--)
  {
    IF_VERBOSE(3) cout << "****** realizing elements in pipeline stage " << s << " ******" << endl;

//    predecessor_set = (*pipeline_set)[s-1];
    predecessor_set.clear();
    working_set = (*pipeline_set)[s];

    //if there are target coefficients which should be realized in a lower pipeline stage than the output stage (which currently can not be configured),
    //remove corresponding elements from working set
    if(!predecessor_set.empty())
    {
      successor_set.clear();
      realized_target_set.clear();
      compute_successor_set(&predecessor_set, c_max, &successor_set, false, is_this_a_two_input_system());
      set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

      if(!realized_target_set.empty())
      {
        IF_VERBOSE(3) cout << "**coefficient(s) " << realized_target_set << " can be already be realized using p=" << predecessor_set << endl;

        for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          working_set.erase(*set_iter);
      }
    }


    if(s == stages_embedded_mult-1)
    {
      //remove elements from working set that are realized by embedded multipliers
      for(set_iter = embedded_mult_set.begin(); set_iter != embedded_mult_set.end(); ++set_iter)
        working_set.erase(*set_iter);
    }


    IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
    IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;

    //############################################################################################################//
    //#######################     include embedded multipliers for hybrid PMCM   #################################//
    //############################################################################################################//
    if(s == stages_embedded_mult-1)
    {
      IF_VERBOSE(3) cout << "realizing coefficients with embedded multipliers..." << endl;

      //coefficients can be realized using embedded multipliers in this stage:
      if((max_no_of_mult < 0) || (working_set.size() <= (unsigned) max_no_of_mult))
      {
        IF_VERBOSE(2) cout << "all coefficients at this stage can be realized using multipliers -> terminate" << endl;
        embedded_mult_set = working_set;
        no_of_stages_skipped = s;
        break;
      }
      else
      {
        //chose coefficients that are realized using embedded multipliers:
        int_double_map_t working_set_depth_map;
        for(set_iter = working_set.begin(); set_iter != working_set.end(); ++set_iter)
        {
          working_set_depth_map[*set_iter] = log(nonzeros(*set_iter))/log(2);
        }
        IF_VERBOSE(3) cout << "working_set_depth_map=" << working_set_depth_map << endl;

        int_double_map_t::iterator max_ad_gain_map_iter;
        while(embedded_mult_set.size() < (unsigned) max_no_of_mult)
        {
          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp_both());
//          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp());

          IF_VERBOSE(4) cout << "max. adder depth: " << (*max_ad_gain_map_iter).first << "," << (*max_ad_gain_map_iter).second << endl;

          embedded_mult_set.insert((*max_ad_gain_map_iter).first);
          working_set.erase((*max_ad_gain_map_iter).first);
          //set depth to -1 that embedded multiplier elements are ignored for remaining adder depth:
          working_set_depth_map[(*max_ad_gain_map_iter).first] = -1;
        }

        if(force_minimal_depth)
        {
          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp());
          IF_VERBOSE(3) cout << "remaining adder depth for element " << (*max_ad_gain_map_iter).first << ": " << ceil((*max_ad_gain_map_iter).second) << endl;
          no_of_stages_skipped = adder_depth_constraints[s]-ceil((*max_ad_gain_map_iter).second);
          IF_VERBOSE(3) cout << "skipping " << no_of_stages_skipped << " stage(s)" << endl;

          if(no_of_stages_skipped > 0)
          {
            for(int i=0; i < no_of_pipeline_stages; i++)
            {
              if(i+no_of_stages_skipped < no_of_pipeline_stages)
              {
                (*pipeline_set)[i] = (*pipeline_set)[i+no_of_stages_skipped];
              }
              else
              {
                pipeline_set->pop_back();
              }
            }
            IF_VERBOSE(3) cout << "reduced pipeline_set=" << (*pipeline_set) << endl;
            s -= no_of_stages_skipped;
            stages_embedded_mult -= no_of_stages_skipped;
            IF_VERBOSE(3) cout << "****** pipeline stages reduced to " << s << " ******" << endl;
            if(s == 0)
            {
              IF_VERBOSE(3) cout << "remaining elements can be realized from input '1' -> terminating" << endl;
              no_of_stages_skipped = no_of_pipeline_stages;
              goto finito;
            }
          }
        }
      }
      IF_VERBOSE(3) cout << "coefficients realized with embedded multipliers: " << embedded_mult_set << endl;

      if(s+no_of_stages_skipped == no_of_pipeline_stages)
      {
        IF_VERBOSE(3) cout << "embedded multipliers at last stage realized -> continue with next lower stage" << endl;
        continue; //embedded multipliers at last stage realized -> continue with next previous stage
      }

      IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
      IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;
    }


    //############################################################################################################//
    //######################################     single stage optimization loop    ###############################//
    //############################################################################################################//
    predecessor_set.clear();

    while(!working_set.empty())
    {
      //searching for best predecessors
      best_single_predecessor = get_best_single_predecessor(working_set, predecessor_set, s);

      if(exhaustive)
      {
        cerr << "error: exhaustive mode currently unsupported!" << endl;
        exit(-1);
      }
      else
      {
        if((best_single_predecessor > 0))
        {
          predecessor_set.insert(best_single_predecessor);
        }
        else
        {
          IF_VERBOSE(3) cout << "no single predecessor found, searching for multiple predecessors" << endl;

          get_best_multi_predecessor(working_set, &predecessor_set, s);

        }

        successor_set.clear();
        compute_successor_set(&predecessor_set, c_max, &successor_set, false,is_this_a_two_input_system());
        IF_VERBOSE(8)
        {
          std::cout << "predecessor_set = " << predecessor_set << std::endl;
          std::cout << "successor_set = " << successor_set << std::endl;
          std::cout << "working_set = " << working_set << std::endl;
        }
        realized_target_set.clear();
        set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

        IF_VERBOSE(3) cout << "coefficient(s) " << realized_target_set << " can be realized using p=" << predecessor_set << endl;

        for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          working_set.erase(*set_iter);

        IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
        IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;
      }
    }
    (*pipeline_set)[s-1] = predecessor_set;
//    predecessor_set.clear();

  }

  finito:

  //elliminate multiplier nodes from realization:
  if(stages_embedded_mult > 0)
  {
    IF_VERBOSE(2) cout << "pipeline_set=" << (*pipeline_set) << endl;
    for(set_iter = embedded_mult_set.begin(); set_iter != embedded_mult_set.end(); ++set_iter)
    {
      (*pipeline_set)[stages_embedded_mult-1].erase(*set_iter);
    }
    IF_VERBOSE(2) cout << "reduced pipeline_set=" << (*pipeline_set) << endl;
  }

  if(!embedded_mult_set.empty())
  {
    IF_VERBOSE(2) cout << "coefficients realized by embedded multiplers: [" << embedded_mult_set << "]" << endl;
  }

  //count no of adders and registers:
  int no_of_adders=0,no_of_registers=0,no_of_registered_ops=0;
  for(unsigned int s=0; s < pipeline_set->size(); s++)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      if(s == 0)
      {
        if(*set_iter == 1)
          no_of_registers++;
        else
          no_of_adders++;
      }
      else
      {
        bool element_is_mult=false;
        //is the element realized by a multiplier?
        if(s == (unsigned) stages_embedded_mult-1)
        {
          if(embedded_mult_set.find(*set_iter) != embedded_mult_set.end())
          {
            element_is_mult=true;
          }
        }
        //ignore multiplies for counting adders and registers
        if(!element_is_mult)
        {
          //seach element in previous stage
          if((*pipeline_set)[s-1].find(*set_iter) != (*pipeline_set)[s-1].end())
          {
            //element found -> count as register
            no_of_registers++;
          }
          else
          {
            no_of_adders++;
          }
        }
      }

    }
    no_of_registered_ops += (*pipeline_set)[s].size();
  }

  IF_VERBOSE(2) cout << "no of adders=" << no_of_adders << endl;
  IF_VERBOSE(2) cout << "no of registers=" << no_of_registers << endl;
  IF_VERBOSE(2) cout << "no of registered operations=" << no_of_registers + no_of_adders << endl;
  IF_VERBOSE(2) cout << "no of embedded multipliers= " << embedded_mult_set.size() << endl;
  IF_VERBOSE(2) cout << "effective adder depth / min. pipeline depth of multipliers=" << no_of_pipeline_stages-no_of_stages_skipped << endl;

//  cout << " adders & registers & add+reg & mults & stages & time\\" << endl;
//  cout << " " << no_of_adders << " & " << no_of_registers << " & " << no_of_registers + no_of_adders << " & " << embedded_mult_set.size() << " & " << no_of_pipeline_stages-no_of_stages_skipped << "\\" << endl;
  IF_VERBOSE(2) cout << "pipeline_set=" << (*pipeline_set) << endl;

  return 1;
}

int rpag::validate_parameters()
{
  return 1;
}

int rpag::create_constraints(int adder_depth_max, int target_wordsize_max)
{
  if(stages_input_pag < 0)
  {
    IF_VERBOSE(3) cout << "No stages for input PAG are given, determining the minimal necessary number of stages" << endl;

    if(mult_wordsize > 0)
    {
      //multipliers are used, the input PAG stages are determined using half the multiplier wordsize
//      stages_input_pag = log2c_64(ceil(mult_wordsize/2.0));
      stages_input_pag = log2c_64(mult_wordsize+1)-1;
    }
    else
    {
      //no multipliers are used, the input PAG stages are determined from the maximum adder depth of the target coefficients:
      stages_input_pag = adder_depth_max;
    }
  }
  IF_VERBOSE(3) cout << "Input PAG stages: " << stages_input_pag << endl;

  if(stages_output_pag < 0)
  {
    IF_VERBOSE(3) cout << "No stages for output PAG are given, determining the minimal necessary number of stages" << endl;

    if((mult_wordsize > 0) && (target_wordsize_max > mult_wordsize))
    {
      //if wordsize is halfed in each stage, ceil(log2(target_wordsize_max/mult_wordsize))+1 stages are necessary:
      stages_output_pag = ceil(log2(((double) target_wordsize_max)/mult_wordsize));
    }
    else
    {
      //no mutliplier is used, so no output PAG is necessary:
      stages_output_pag = 0;
    }
  }
  IF_VERBOSE(3) cout << "Output PAG stages: " << stages_output_pag << endl;

  //determine the optimization plan
  if(mult_wordsize == -1)
  {
    //no multipliers are used, simply constrain the adder depth
    for(int s=0; s < stages_input_pag; s++)
    {
      wordsize_constraints.push_back(-1);
      adder_depth_constraints.push_back(s+1);
    }
  }
  else
  {
    //multipliers are used, constrain the adder depth of the input PAG and the word length of the output PAG:
    for(int s=0; s < stages_input_pag-1; s++)
    {
      wordsize_constraints.push_back(-1);
      adder_depth_constraints.push_back(s+1);
    }
    wordsize_constraints.push_back(mult_wordsize);
    adder_depth_constraints.push_back(-1);
    for(int s=0; s < stages_output_pag-1; s++)
    {
      adder_depth_constraints.push_back(-1);
      wordsize_constraints.push_back((s+2)*mult_wordsize); //!!!!
    }
    wordsize_constraints.push_back(target_wordsize_max);
    adder_depth_constraints.push_back(-1);
  }



  return 1;
}

void rpag::check_constraints(int no_of_pipeline_stages)
{
  for(int s=0; s < no_of_pipeline_stages-1; s++)
  {
    IF_VERBOSE(4) cout << "checking constraints in stage " << s << endl;
    if((adder_depth_constraints[s] > 0) && (adder_depth_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << adder_depth_constraints[s+1] << "<=" << adder_depth_constraints[s]+1 << endl;
      if(adder_depth_constraints[s+1] > adder_depth_constraints[s]+1)
      {
        cout << "Warning: constraints inconsistent, adder depth difference is greater than one from stage " << s << " to stage " << s+1 << endl;
      }
    }
    if((wordsize_constraints[s] > 0) && (wordsize_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << wordsize_constraints[s+1] << "<=" << (wordsize_constraints[s]<<1) << endl;

      if(is_this_a_two_input_system())
      {
        if(wordsize_constraints[s+1] > (wordsize_constraints[s]<<1))
        {
          cout << "Warning: constraints inconsistent, word size is more than doubled from stage " << s << " to stage " << s+1 << endl;
        }
      }
      else
      {
        if(wordsize_constraints[s+1] > 3*(wordsize_constraints[s]))
        {
          cout << "Warning: constraints inconsistent, word size is more than a factor of three from stage " << s << " to stage " << s+1 << endl;
        }
      }
    }
    if((adder_depth_constraints[s] > 0) && (wordsize_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << (log2c_64(wordsize_constraints[s+1]+1)-1) << "<=" << adder_depth_constraints[s]+1 << endl;
      if((log2c_64(wordsize_constraints[s+1]+1)-1) > adder_depth_constraints[s]+1)
      {
        cout << "Warning: there is no guarantee that a word size of " << wordsize_constraints[s+1] << " in stage " << s+1 << " can be reached with an adder depth of " << adder_depth_constraints[s] << " in stage " << s << endl;
      }
    }
  }
}
