#include "compute_successor_set.h"
#include "fundamental.h"
#include "log2_64.h"
#include "debug.h"
#include <cstdlib>
#include <cmath>

//###################################################################################################
//#######################################     basis     #############################################
//###################################################################################################
void compute_successor_set(int_t r1, int_t r2, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    //set r1 to the maximum value
    if(r2 > r1)
    {
        int tmp = r1;
        r1=r2;
        r2=tmp;
    }
    int_t s;

    if(r1 > c_max) return;

    //for k=0, the fundamental() method hast to be called
    s=fundamental(r1 + r2);
#ifdef DEBUG
    IF_VERBOSE(7) cout << s << "=" << r1 << "+" << r2 << endl;
#endif
    if(s <= c_max) (*successor_set).insert(s);
#ifdef DEBUG
    if(s <= c_max) IF_VERBOSE(8) cout << s << "=|" << r1 << "+" << r2 << "|" << endl;
#endif
    if(s <= c_max) (*successor_set).insert(fundamental(abs(r1 - r2)));

    int k_max=log2c_64(((int_t) round(c_max-r1)/r2));
    if(k_max < 0) return;

#ifdef DEBUG
    IF_VERBOSE(7) cout << "r1=" << r1 << ", r2=" << r2 << ", k_max=" << k_max << ", c_max=" << c_max << endl;
#endif

    for(int k=1; k <= k_max; k++)
    {
        s=(r1 << k) + r2;
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << k << "*" << r1 << "+" << r2 << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=r1 + (r2 << k);
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << r1 << "+" << "2^" << k << "*" << r2 << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=abs((r1 << k) - r2);
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=|" << "2^" << k << "*" << r1 << "-" << r2 << "|" << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=abs(r1 - (r2 << k));
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=|" << r1 << "-" << "2^" << k << "*" << r2 << "|" << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
    }
    successor_set->erase(0);
    //successor_set->erase(1); //!!!!!!!!!!!
    if(erase_predecessor)
    {
      successor_set->erase(r1);
      successor_set->erase(r2);
    }
  }
  else
  {
    compute_successor_set(r1,r2,c_max,successor_set,erase_predecessor);
    compute_successor_set(r1,r2,r2,c_max,successor_set,erase_predecessor);
    compute_successor_set(r1,r1,r2,c_max,successor_set,erase_predecessor);
  }
}

void compute_successor_set(const int_set_t *r1_set, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    int_t r1,r2,s;
    int k_max;

    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;
    
    for (r1_p=r1_set->begin(); r1_p != r1_set->end(); ++r1_p)
    {
        for (r2_p=r2_set->begin(); r2_p != r2_set->end(); ++r2_p) //!!!
        {
            //set r1 to the maximum value
            if(*r1_p > *r2_p)
            {
                r1=*r1_p;
                r2=*r2_p;
            }
            else
            {
                r1=*r2_p;
                r2=*r1_p;
            }
            
//            k_max=(int) ceil(abs(log10((c_max-r1)/r2)/log10(2)));
            k_max=log2c_64(((int_t) round(c_max-r1)/r2));

            IF_VERBOSE(7) cout << "computing successor set of " << r1 << " and " << r2 << " k_max=" << k_max << endl;

            //for k=0, the fundamental() method hast to be called
            (*successor_set).insert(fundamental(r1 + r2));
            (*successor_set).insert(fundamental(abs(r1 - r2)));
            
            for(int k=1; k < k_max; k++)
            {
                s=(r1 << k) + r2;
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
                s=r1 + (r2 << k);
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
                s=abs((r1 << k) - r2);
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
                s=abs(r1 - (r2 << k));
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
            }
            if(erase_predecessor)
            {
              successor_set->erase(r1);
              successor_set->erase(r2);
            }
        }
    }
    successor_set->erase(0);
//    successor_set->erase(1);
  }
  else
  {
    // 3 input adders
    int_t r1,r2;

    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;

    for (r1_p=r1_set->begin(); r1_p != r1_set->end(); ++r1_p)
    {
      for (r2_p=r1_set->begin(); r2_p != r1_set->end(); ++r2_p) //!!!
      {
        r1 = *r1_p;
        r2 = *r2_p;
          compute_successor_set(r1,r1,r2,c_max,successor_set,erase_predecessor);
          compute_successor_set(r1,r2,r2,c_max,successor_set,erase_predecessor);
      }
    }
  }
}

//Diese Funktion lässt sich beschleunigen!!! Siehe fir_mcm_opt, "Berechnung der Nachfolgemenge" !!!!
void compute_successor_set(const int_set_t *realized_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    compute_successor_set(realized_set, realized_set, c_max, successor_set, erase_predecessor, two_input_adder);
  }
  else
  {
    // 3 input adders
    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;
    int_set_t::iterator r3_p;

    for (r1_p=realized_set->begin(); r1_p != realized_set->end(); ++r1_p)
    {
      for (r2_p=realized_set->begin(); r2_p != realized_set->end(); ++r2_p) //!!!
      {
        for (r3_p=realized_set->begin(); r3_p != realized_set->end(); ++r3_p) //!!!
        {
          compute_successor_set((*r1_p),(*r2_p),(*r3_p),c_max,successor_set,erase_predecessor);
        }
      }
    }
  }
}

/* This function is currently not used:
void compute_successor_set(int_t r1, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
    int_set_t::iterator r2_p;

    for (r2_p=r2_set->begin(); r2_p != r2_set->end(); ++r2_p) //!!!
    {
      compute_successor_set(r1, *r2_p, c_max, successor_set, erase_predecessor, two_input_adder);
    }
}
*/
//###################################################################################################
//#######################################    3 input    #############################################
//###################################################################################################

void permut(int &a, int &b, int &c, int &k, int &l, int index)
{
  switch(index)
  {
  case 0:
    a = k;
    b = 0;
    c = l;
  break;
  case 1:
    a = l;
    b = k;
    c = 0;
  break;
  case 2:
    a = 0;
    b = l;
    c = k;
  break;
  case 3:
    a = k;
    b = l;
    c = 0;
  break;
  case 4:
    a = l;
    b = 0;
    c = k;
  break;
  case 5:
    a = 0;
    b = k;
    c = l;
  break;
  default:
    std::cout << "unknown index in: void permut(int &a, int &b, int &c, int &k, int &l, int index)" << std::endl;
    exit(-1);
  break;
  }

}

void compute_successor_set(int_t r1, int_t r2, int_t r3, int_t c_max, int_set_t *successor_set, bool erase_predecessor)
{
  int a = 0;
  int b = 0;
  int c = 0;
  int permut_border = 6;

  r1 = fundamental(r1);
  r2 = fundamental(r2);
  r3 = fundamental(r3);
  //set r1 to the maximum value
  { //to make r1 > r2 > r3
    int tmp;
    if(r3 > r2)
    {
        tmp = r2;
        r2 = r3;
        r3 = tmp;
    }
    if(r2 > r1)
    {
        tmp = r1;
        r1 = r2;
        r2 = tmp;
    }
    if(r3 > r2)
    {
        tmp = r2;
        r2 = r3;
        r3 = tmp;
    }
  }
  int_t s;

  if(r1 > c_max) return;

  int k_max = log2c_64(((int_t) round(c_max-r1)/(r2)));

  //k_max = logf_64(c_max-r1);

  if(k_max < 0) return;

#ifdef DEBUG
  IF_VERBOSE(7) cout << "r1=" << r1 << ", r2=" << r2 << ", r3=" << r3 << ", k_max=" << k_max << ", c_max=" << c_max << endl;
#endif


  for(int k = 0; k <= k_max; k++)
  {
    for(int l = 0; l <= k; l++)
    {
      if((k == l)||(k==0)||(l==0)){permut_border = 3;} else {permut_border = 6;}//if k = l it's not necessary to switch k and l

      for(int permut_counter = 0; permut_counter < permut_border; permut_counter++)
      {
        permut(a,b,c,k,l,permut_counter);

        s = abs((r1<<a) + (r2<<b) + (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) + (r2<<b) - (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) - (r2<<b) + (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) - (r2<<b) - (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl << std::endl;
        #endif

        /* unn�tig da durch bereits abgedekt
        s = abs(-(r1<<a) + (r2<<b) + (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs(-(r1<<a) + (r2<<b) - (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs(-(r1<<a) - (r2<<b) + (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl << std::endl;
        #endif


        //unn�tig da durch  + + + bereits abgedekt
        //s = abs(-r1<<a - r2<<b - r2<<c);
        //if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
        */
      }
    }
  }
  successor_set->erase(0);
  //successor_set->erase(1); //!!!!!!!!!!!
  if(erase_predecessor)
  {
    successor_set->erase(r1);
    successor_set->erase(r2);
    successor_set->erase(r3);
  }
}
