% writes a '.dot' file for a pipelined adder graph of a pipelined_realization
function write_pipelined_realization_graph_dot(filename, pipelined_realization, varargin)

% open dot-file and write header:
fid = fopen(filename, 'wt');
fprintf(fid, 'digraph G {\n');

for k=1:2:size(varargin,2)
  switch(varargin{k})
    case 'keeporder'
      if varargin{k+1} == true
        fprintf(fid, 'ordering=out;\n');
      end
    case 'ranksep'
      if varargin{k+1} > 0
        fprintf(fid, 'ranksep=%f;\n',varargin{k+1});
      end
  end
end

%write root node '1'
fprintf(fid, ['x_1_s0 [label="1",shape="ellipse"];\n']);
s_last=-1; %remembers the last pipeline stage
%write nodes
pipelined_realization_size = size(pipelined_realization);
for l=1:pipelined_realization_size(1)
    if (pipelined_realization(l,2) ~= s_last) || (pipelined_realization(l,2) == pipelined_realization(l,4))
      if s_last ~= -1
        fprintf(fid, '}\n');
      end
      fprintf(fid, '{ rank=same\n');
      s_last = pipelined_realization(l,2);
    end
    if (sign(pipelined_realization(l,3))*sign(pipelined_realization(l,6))) < 0
      sign_str='-';
    else
      sign_str='+';
    end
    if size(pipelined_realization,2) == 11
      if nnz(pipelined_realization(l,9:11)) ~= 0
        if (sign(pipelined_realization(l,3))*sign(pipelined_realization(l,9))) < 0
          sign_str=[sign_str,' -'];
        else
          sign_str=[sign_str,' +'];
        end
      end
    end
    %check if node can only be computed by a real multiplication
%    if all(pipelined_realization(l,3:8) == [1 0 0 0 0 0]) && (pipelined_realization(l,1) ~= 1)
    if ((pipelined_realization(l,3) == 0) || (pipelined_realization(l,6) == 0)) && ~((pipelined_realization(l,1) == pipelined_realization(l,3)) || (pipelined_realization(l,1) == pipelined_realization(l,6)))
      sign_str='*';
    %check end node without add or sub (only shift)
    elseif pipelined_realization(l,6) == 0
      sign_str='';
    end
    if pipelined_realization(l,2) == pipelined_realization(l,4)
      %no delay -> this is a node without register (output)
      fprintf(fid, ['x_',num2str(pipelined_realization(l,1)),' [label="',num2str(pipelined_realization(l,1)),'",shape="none",height=0.0];\n']);
    else
      %this is a node without register:
      fprintf(fid, ['x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',sign_str,'\\n',num2str(pipelined_realization(l,1)),'",shape="box"];\n']);
    end
end
fprintf(fid, '}\n');

%write edges
for l=1:pipelined_realization_size(1)
  %check end node without add or sub (only shift)
  if pipelined_realization(l,6) == 0
    if pipelined_realization(l,2) == pipelined_realization(l,4)
      %no delay -> this is a node without register (output)
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,3))),'_s',num2str(pipelined_realization(l,4)),' -> x_',num2str(pipelined_realization(l,1)),' [label="',num2str(pipelined_realization(l,5)),' ",fontsize=12]\n']);
    else
      %this is a node without register:
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,3))),'_s',num2str(pipelined_realization(l,4)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,5)),' ",fontsize=12]\n']);
    end
  else
    %check no of adder inputs:
    if size(pipelined_realization,2) == 8
      %two input adders:
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,3))),'_s',num2str(pipelined_realization(l,4)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,5)),' ",fontsize=12]\n']);
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,6))),'_s',num2str(pipelined_realization(l,7)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,8)),' ",fontsize=12]\n']);
    elseif nnz(pipelined_realization(l,9:11)) == 0
      %two input adders:
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,3))),'_s',num2str(pipelined_realization(l,4)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,5)),' ",fontsize=12]\n']);
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,6))),'_s',num2str(pipelined_realization(l,7)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,8)),' ",fontsize=12]\n']);
    else
      %three input adders:
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,3))),'_s',num2str(pipelined_realization(l,4)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,5)),' ",fontsize=12]\n']);
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,6))),'_s',num2str(pipelined_realization(l,7)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,8)),' ",fontsize=12]\n']);
      fprintf(fid, ['x_',num2str(abs(pipelined_realization(l,9))),'_s',num2str(pipelined_realization(l,10)),' -> x_',num2str(pipelined_realization(l,1)),'_s',num2str(pipelined_realization(l,2)),' [label="',num2str(pipelined_realization(l,11)),' ",fontsize=12]\n']);
    end
  end
end

fprintf(fid, '}\n');
fclose(fid);
