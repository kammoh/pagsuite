#include "rpagt.h"
#include "adder_depth.h"
#include "fundamental.h"
#include "log2_64.h"
#include "debug.h"
#include "csd.h"
#include "compute_successor_set.h"
#include <utility>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include "log2_64.h" // adder_depth
#include "types.h"

using namespace::std;

rpagt::rpagt()
{
}

int rpagt::adder_depth(int_t x)
{
  return log3c_64(nonzeros(x));
}

int_t rpagt::get_best_single_predecessor(const int_set_t &working_set, const int_set_t &predecessor_set, int s)
{

  int_set_t::iterator set_iter;

  int_double_map_t single_p_gain_map;
  int_double_map_t::iterator single_p_gain_map_iter;

  int_pair_double_map_t p_w_gain_map;
  int_pair_double_map_t::iterator p_w_gain_map_iter;


  IF_VERBOSE(2) cout << "searching for best single predecessor ..." << endl;


  //compute 2-input adder topologies:
  compute_topology_a_predecessors_2_Add_I(&working_set, NULL, adder_depth_constraints[s-1], wordsize_constraints[s-1],NULL,&p_w_gain_map);
  compute_topology_b_predecessors_2_Add_I(&working_set, NULL, adder_depth_constraints[s-1], wordsize_constraints[s-1],NULL,&p_w_gain_map);
  compute_topology_c_predecessors_2_Add_I(&working_set, &predecessor_set, NULL, adder_depth_constraints[s-1], wordsize_constraints[s-1],NULL,&p_w_gain_map);

  //compute 3-input adder topologies:
  compute_topology_a_predecessors_3_add(&working_set, &p_w_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1]);
  compute_topology_b_predecessors_3_add(&working_set, &predecessor_set, &p_w_gain_map, adder_depth_constraints[s-1], wordsize_constraints[s-1]);
  compute_topology_c_predecessors_3_add(&working_set, &predecessor_set,&p_w_gain_map,adder_depth_constraints[s-1],wordsize_constraints[s-1]);

  IF_VERBOSE(4) cout << "p_w_gain_map=" << p_w_gain_map << endl;


  //convert p_w_gain_map to single_p_gain_map:
  int_pair_t key;
  int_t p,w,p_last=-1;
  double gain;
  for(p_w_gain_map_iter = p_w_gain_map.begin(); p_w_gain_map_iter != p_w_gain_map.end(); ++p_w_gain_map_iter)
  {
    key = (*p_w_gain_map_iter).first;
    p = key.first;
    w = key.second;
    gain = (*p_w_gain_map_iter).second;

    if(p == p_last)
    {
      single_p_gain_map[p] = single_p_gain_map[p] + gain;
    }
    else
    {
      single_p_gain_map[p] = gain;
    }
    p_last = p;
  }

  IF_VERBOSE(4) cout << "single_p_gain_map=" << single_p_gain_map << endl;

  //remove already chosen predecessors from gain map:
  for(set_iter = predecessor_set.begin(); set_iter != predecessor_set.end(); ++set_iter)
  {
    single_p_gain_map.erase(*set_iter);
  }
  IF_VERBOSE(3) cout << "3-input gain_map=" << single_p_gain_map << endl;

  if(single_p_gain_map.empty())
  {
    return -1;
  }

  //make a random decision of the best predecessors
  int decision = get_local_decision(single_p_gain_map.size()-1);
  IF_VERBOSE(3) cout << "rand variance decision= " << decision << endl;

  int_t best_single_predecessor;

  //remove the best N (which is equal to 'decision') elements from set:
  for(int i=0; i < decision; i++)
  {
    single_p_gain_map_iter = max_element(single_p_gain_map.begin(), single_p_gain_map.end(), int_double_map_cmp());
    single_p_gain_map.erase((*single_p_gain_map_iter).first);
  }

  single_p_gain_map_iter = max_element(single_p_gain_map.begin(), single_p_gain_map.end(), int_double_map_cmp());
  best_single_predecessor = (*single_p_gain_map_iter).first;

  IF_VERBOSE(3) cout << "max. gain 3-input single: " << best_single_predecessor << ":" << (*single_p_gain_map_iter).second << endl;
  return best_single_predecessor;
}

void  rpagt::get_best_multi_predecessor(const int_set_t &working_set, int_set_t *predecessor_set, int s)
{
  IF_VERBOSE(2) cout << "searching for best single predecessor pairs & triplets ..." << endl;

  int_set_t::iterator set_iter;

  int nz_max;

  if(adder_depth_constraints[s-1] >= 0)
    nz_max = (int) pow(3.0,adder_depth_constraints[s-1]);
  else
    nz_max = -1;

  IF_VERBOSE(3) cout << "optimizing for wordsize constraint=" << wordsize_constraints[s-1] << ", max. nonzeros constraint=" << nz_max << ", adder depth constraint=" << adder_depth_constraints[s-1] << endl;

  IF_VERBOSE(3) cout << "searching for best predecessor pairs & triplets from MSD using max. nonzeros=" << nz_max << " and max. wordsize " << wordsize_constraints[s-1] << endl;

  int_triplet_set_t predecessor_triplet_set;
  int_triplet_set_t::iterator p_set_iter;
  int_triplet_double_map_t triplet_gain_map;
  int_set_t successor_set;
  int_set_t realized_target_set;


  double gain, gain_max=0;
  int_triplet_t predecessor_triplet,predecessor_triplet_best;

  predecessor_triplet_best.first = -1;
  predecessor_triplet_best.second = -1;
  predecessor_triplet_best.third = -1;

  int_set_t::iterator working_set_iter;

  //serch for each element from the working_set
  for(working_set_iter = working_set.begin(); working_set_iter != working_set.end(); ++working_set_iter)
  {
    int_t w=*working_set_iter;


    //compute predecessor pairs and triplets witch can be used to create the current w
    compute_topology_d_predecessors_3_add(w, nz_max, wordsize_constraints[s-1], &predecessor_triplet_set);

    //compute the gain for all predecessor triplet's
    for(p_set_iter=predecessor_triplet_set.begin(); p_set_iter != predecessor_triplet_set.end(); ++p_set_iter)
    {
      predecessor_triplet = (*p_set_iter);

      if(msd_successor_evaluation)
      {
        if(triplet_gain_map.find(predecessor_triplet) == triplet_gain_map.end())
        {
          successor_set.clear();
          compute_successor_set(predecessor_triplet.first, predecessor_triplet.second,predecessor_triplet.third, c_max, &successor_set, false);

          realized_target_set.clear();
          set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

          for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          {

            //if 2 are equal the gain have to be different
            if((predecessor_triplet.first == 0)||
               (predecessor_triplet.first == predecessor_triplet.second)||
               (predecessor_triplet.second == predecessor_triplet.third)||
               (predecessor_triplet.third == predecessor_triplet.first))
            {
              gain = triplet_gain_map[predecessor_triplet] + 1.0 / (2*cost_ternary_add(*set_iter,predecessor_triplet.first,predecessor_triplet.second,predecessor_triplet.third));
            }
            else
            {
              gain = triplet_gain_map[predecessor_triplet] + 1.0 / (3*cost_ternary_add(*set_iter,predecessor_triplet.first,predecessor_triplet.second,predecessor_triplet.third));
            }
            triplet_gain_map[predecessor_triplet] = gain;
          }
        }
      }
      else
      {
        //if 2 are equal the gain have to be different
        if((predecessor_triplet.first == 0)||
           (predecessor_triplet.first == predecessor_triplet.second)||
           (predecessor_triplet.second == predecessor_triplet.third)||
           (predecessor_triplet.third == predecessor_triplet.first))
        {
          gain = triplet_gain_map[predecessor_triplet] + 1.0 / (2*cost_ternary_add(*set_iter,predecessor_triplet.first,predecessor_triplet.second,predecessor_triplet.third));
        }
        else
        {
          gain = triplet_gain_map[predecessor_triplet] + 1.0 / (3*cost_ternary_add(*set_iter,predecessor_triplet.first,predecessor_triplet.second,predecessor_triplet.third));
        }
        triplet_gain_map[predecessor_triplet] = gain;
      }
    }
    predecessor_triplet_set.clear();
  }

  IF_VERBOSE(3) cout << "triplet gain map=" << triplet_gain_map << endl;


  //select best predecessor triplet:
  int decision = get_local_decision(triplet_gain_map.size()-1);
  IF_VERBOSE(2) cout << "rand variance decision= " << decision << endl;

  int_triplet_double_map_t::iterator triplet_gain_map_iter;

  //remove the best N (which is equal to 'decision') elements from set:
  for(int i=0; i < decision; i++)
  {
    triplet_gain_map_iter = max_element(triplet_gain_map.begin(), triplet_gain_map.end(), int_triplet_double_map_cmp());
    triplet_gain_map.erase((*triplet_gain_map_iter).first);
  }
  triplet_gain_map_iter = max_element(triplet_gain_map.begin(), triplet_gain_map.end(), int_triplet_double_map_cmp());
  predecessor_triplet_best = (*triplet_gain_map_iter).first;
  gain_max = (*triplet_gain_map_iter).second;

  IF_VERBOSE(2) cout << "best predecessor triplet: " << predecessor_triplet_best << " with gain " << gain_max << endl;

  if((predecessor_triplet_best.first == 0) && (predecessor_triplet_best.second == 0) && (predecessor_triplet_best.third == 0))
  {
    cerr << "Error: no predecessors were found (maybe optimization plan is too tough?)" << endl;
    flush(cerr);
    exit(-1);
  }

  //if the triplet is a pair the 0 must not be inserted!!
  if(predecessor_triplet_best.first != 0) predecessor_set->insert(predecessor_triplet_best.first);
  predecessor_set->insert(predecessor_triplet_best.second);
  predecessor_set->insert(predecessor_triplet_best.third);

}

void rpagt::compute_topology_a_predecessors_3_add(const int_set_t *working_set, int_pair_double_map_t *p_w_gain_map, int s_max, int ws_max, int_set_t *p_set_b)
{
  IF_VERBOSE(4) cout << "compute 3-input predecessors for topology a" << endl;
  int_set_t::iterator set_iter_a,set_iter_b;

  int_set_t possible_divider_set;

  for(set_iter_a = working_set->begin(); set_iter_a != working_set->end(); ++set_iter_a)
  {
    int_t w = *set_iter_a; //element from working_set
    int_t div = 3; // ,quot;
    int k = 3; //shift factor 1
    int l = 2; //shift factor 2

    while(div <= 2*w)// k loop
    {
      while((div <= 2*w) && (l < k))// l loop
      {
        //2^k-2^l-1
        div = (1ll << k) - (1ll << l) - 1;
        IF_VERBOSE(5) cout << "div=2^" << k << " - 2^" << l << " - 1 = " << div << endl;
        if(div != 0) if((w % div) == 0) if(div != 1) possible_divider_set.insert(div);

        //2^k+2^l-1
        div = (1ll << k) + (1ll << l) - 1;
        IF_VERBOSE(5) cout << "div=2^" << k << " + 2^" << l << " - 1 = " << div << endl;
        if(div != 0) if((w % div) == 0) if(div != 1) possible_divider_set.insert(div);

        //2^k-2^l+1
        div = (1ll << k) - (1ll << l) + 1;
        IF_VERBOSE(5) cout << "div=2^" << k << " - 2^" << l << " + 1 = " << div << endl;
        if(div != 0) if((w % div) == 0) if(div != 1) possible_divider_set.insert(div);

        //2^k+2^l+1
        div = (1ll << k) + (1ll << l) + 1;
        IF_VERBOSE(5) cout << "div=2^" << k << " + 2^" << l << " + 1 = " << div << endl;
        if(div != 0) if((w % div) == 0) if(div != 1) possible_divider_set.insert(div);

        l++;
      }
      l=2;
      k++;
    }
  }

  IF_VERBOSE(5) cout << "possible_divider_set=" << possible_divider_set << endl;

  //to avoid double conting of identical predecessors, evaluate the gain map in a secon step:
  for(set_iter_a = working_set->begin(); set_iter_a != working_set->end(); ++set_iter_a)
  {
    int_t w = *set_iter_a;//element from working_set
    int_t div,quot;

    for(set_iter_b = possible_divider_set.begin(); set_iter_b != possible_divider_set.end(); ++set_iter_b)
    {
      div = *set_iter_b;
      if((w % div) == 0)
      {
        quot=w/div;
        if(((s_max < 0) || (adder_depth(quot) <= s_max)) && ((ws_max < 0) || (log2c_64(quot) <= ws_max)))
        {
          IF_VERBOSE(4) cout << "**case 3a: w=" << w << "=" << quot << "*" << div << " (p'=" << quot << ")" << endl;

          if(p_set_b != NULL) p_set_b->insert(quot);

          (*p_w_gain_map)[int_pair_t(quot,w)] = max((*p_w_gain_map)[int_pair_t(quot,w)],1/cost_ternary_add(w,quot,quot,quot));
        }
      }
    }
  }
}


void rpagt::compute_topology_b_predecessors_3_add(const int_set_t *working_set, const int_set_t *predecessor_set, int_pair_double_map_t *p_w_gain_map, int s_max, int ws_max, int_set_t *p_set_c)
{
  IF_VERBOSE(4) cout << "compute 3-input predecessors for topology b" << endl;
  if(!predecessor_set->empty())
  {
    int_set_t::iterator working_set_iter;
    int_set_t::iterator potential_set_iter;
    int_set_t::iterator predecessor_set_iter;

    int_set_t pot_pre_step_one;
    int_set_t potential_predecessors;
    int_double_map_t gain_map_dummi;
    int_double_map_t::iterator gain_map_dummi_iter;


    for(working_set_iter = working_set->begin(); working_set_iter != working_set->end(); ++working_set_iter)
    {
      int_t w = *working_set_iter;

      for(predecessor_set_iter = predecessor_set->begin(); predecessor_set_iter != predecessor_set->end(); ++predecessor_set_iter)
      {
        int_t p_realized = *predecessor_set_iter;
        pot_pre_step_one.clear();
        compute_successor_set(w, p_realized,c_max, &pot_pre_step_one);
        IF_VERBOSE(8) cout << " in case c for 3: pot_pre_step_one: "<< std::endl << pot_pre_step_one << std::endl;

        compute_topology_b_predecessors_2_Add_I(&pot_pre_step_one, NULL, s_max, ws_max,&potential_predecessors);

        for(potential_set_iter = potential_predecessors.begin(); potential_set_iter != potential_predecessors.end(); ++potential_set_iter)
        {
          int_t p = *potential_set_iter;
          if(((s_max < 0) || (adder_depth(p) <= s_max)) && ((ws_max < 0) || (log2c_64(p) <= ws_max)))
          {
            IF_VERBOSE(4) cout << "**case 3b met for w=" << w << " (p=" << p << ", p'=" << p_realized << ")" << endl;

            if(p_set_c != NULL) p_set_c->insert(p);

            (*p_w_gain_map)[int_pair_t(p,w)] = max((*p_w_gain_map)[int_pair_t(p,w)],1/cost_ternary_add(w,p,p,p_realized));

          }
        }
        potential_predecessors.clear();
      }
    }
  }
}

void rpagt::compute_topology_c_predecessors_3_add(const int_set_t *working_set, const int_set_t *predecessor_set, int_pair_double_map_t *p_w_gain_map, int s_max, int ws_max, int_set_t *p_set_c)
{
  IF_VERBOSE(4) cout << "compute 3-input predecessors for topology c" << endl;
  if(!predecessor_set->empty())
  {
    int_set_t::iterator working_set_iter;
    int_set_t::iterator potential_set_iter;
    int_set_t::iterator predecessor_1_set_iter;
    int_set_t::iterator predecessor_2_set_iter;


    int_set_t potential_predecessors;

    for(working_set_iter = working_set->begin(); working_set_iter != working_set->end(); ++working_set_iter)
    {
      int_t w = *working_set_iter;

      for(predecessor_1_set_iter = predecessor_set->begin(); predecessor_1_set_iter != predecessor_set->end(); ++predecessor_1_set_iter)
      {
        int_t p_realized1 = *predecessor_1_set_iter;
        for(predecessor_2_set_iter = predecessor_set->begin(); predecessor_2_set_iter != predecessor_set->end(); ++predecessor_2_set_iter)
        {
          int_t p_realized2 = *predecessor_2_set_iter;
          compute_successor_set(w, p_realized1,p_realized2, c_max, &potential_predecessors);

          for(potential_set_iter = potential_predecessors.begin(); potential_set_iter != potential_predecessors.end(); ++potential_set_iter)
          {
            int_t p = *potential_set_iter;
            if(((s_max < 0) || (adder_depth(p) <= s_max)) && ((ws_max < 0) || (log2c_64(p) <= ws_max)))
            {
              IF_VERBOSE(4) cout << "**case 3c met for w=" << w << " (p=" << p << ", p'=" << p_realized1 << " p''=" << p_realized2 << ")" << endl;

              if(p_set_c != NULL) p_set_c->insert(p);

              (*p_w_gain_map)[int_pair_t(p,w)] = max((*p_w_gain_map)[int_pair_t(p,w)],1/cost_ternary_add(w,p,p_realized1,p_realized2));
            }
          }
          potential_predecessors.clear();
        }
      }
    }
  }
}

void rpagt::compute_topology_d_predecessors_3_add(int_t x, int nz_max, int ws_max, int_triplet_set_t *predecessor_triplet_set)
{
  //ToDo: implement ws_max constraint!!
  IF_VERBOSE(4) cout << "compute 3-input predecessors for topology d (pairs and tripplets)" << endl;

  sd_set_t msd_set;

  int ws = log2c_64(x);

  //if max. nonzeros are unconstrained, use wordsize-1
  if(nz_max < 0)
  {
    nz_max=ws-1;
  }

  IF_VERBOSE(3) cout << "max. nonzeros:" << nz_max << endl;
  IF_VERBOSE(3) cout << "max. wordsize:" << ws_max << endl;
  IF_VERBOSE(3) cout << "ws(" << x << ") = " << ws << endl;
  dec2msd(x, &msd_set);
  IF_VERBOSE(4) cout << "msd_set(" << x << "):" << endl << msd_set << endl;

  sd_set_t::iterator msd_set_iter;
  for(msd_set_iter = msd_set.begin(); msd_set_iter != msd_set.end(); ++msd_set_iter)
  {
    sd_t msd = *msd_set_iter;
    int nz = nonzeros(&msd);

    IF_VERBOSE(4) cout << "msd(" << x << ")=" << msd << ", nz=" << nz << endl;

    vector<int> nonzero_values(nz);        //vector that stores signs of nonzero values
    vector<int_t> nonzero_shift_factor(nz); //vector that stores the shift weight (2^"shift factor")

    //fill nonzero_values and nonzero_shift_factor with data:
    vector<int>::iterator int_vector_iter;
    int i=0;
    int_t shift_factor=0;
    for (int_vector_iter=msd.begin(); int_vector_iter != msd.end(); ++int_vector_iter)
    {
      if(*int_vector_iter != 0)
      {
        nonzero_values[i]=*int_vector_iter;
        nonzero_shift_factor[i]=shift_factor;
        i++;
      }
      shift_factor++;
    }
    IF_VERBOSE(4) cout << "nonzero_values=" << nonzero_values << endl;
    IF_VERBOSE(4) cout << "nonzero_shift_factor=" << nonzero_shift_factor << endl;

  permutation_for_predeccessor_pairs(nonzero_values, nonzero_shift_factor, predecessor_triplet_set, ws_max,nz_max, true);

  }
}

void rpagt::permutation_for_predeccessor_pairs(vector<int> &nonzero_values, vector<int_t> &nonzero_shift_factor, int_triplet_set_t *predecessor_triplet_set, int &ws_max,int nz_max, bool rekursion, int_t p3)
{
  //iterate for different nonzero count for the left side predecessor p1 (the right side predecessor p2 has size nz-nz_p1):
  int nz_p2;
  int nz = nonzero_values.size();

  //compute the input value x (defind by nonzero_indices,nonzero_values and nonzero_shift_factor)
  int_t x = 0;
  for(int i=0; i < nz; i++)
  {
    x += ((int_t) nonzero_values[i]) << nonzero_shift_factor[i];
  }
  IF_VERBOSE(7) cout << "x=" << x << std::endl;

  int nz_max_left;
  int ws_max_left;
  if(rekursion)
  {
    nz_max_left = nz_max*2;
    ws_max_left = ws_max*2;
  }
  else
  {
    nz_max_left = nz_max;
    ws_max_left = ws_max;
  }

  for(int nz_p1=nz_max_left; nz_p1 > 0; nz_p1--)
  {
    if(nz_p1 >= nz)
      continue;

    nz_p2=nz-nz_p1;
    if(nz_p2 > nz_p1) //frueher: (nz_p2 > nz_max) !!!
      break;

    IF_VERBOSE(4) cout << "nz_p1=" << nz_p1 << ", nz_p2=" << nz_p2 << endl;
    vector<int> left_nonzero_indices(nz_p1); //vector left_nonzeros is used to address the nonzeros which are used for one part of the pair

    //init left_nonzero_indices:
    for(int i=0; i < nz_p1; i++)
    {
      left_nonzero_indices[i]=i;
    }

    //permutate left_nonzero_indices:
    int_t p1=-1,p2=-1;
    int ws_p1=-1,ws_p2=-1;
    int index;
    while(true) //do permutation: (if(index < 0) break;)
    {
      index=nz_p1-1;
      p1=0;
      //evaluate nonzero_values:
      for(int i=0; i < nz_p1; i++)
      {
        p1 += ((int_t) nonzero_values[left_nonzero_indices[i]]) << nonzero_shift_factor[left_nonzero_indices[i]];
      }

      int min_index_p2=-1,max_index_p2=-1; //!!!

      if(ws_max > 0)
      {
        //detect wordsize of p1 and p2:

        IF_VERBOSE(5) cout << "left_nonzero_indices=" << left_nonzero_indices << endl;

        int min_index_p1,max_index_p1;
        min_index_p1=left_nonzero_indices[0];
        max_index_p1=left_nonzero_indices[nz_p1-1];

        //wordsize of p1 can be directly determined:
        ws_p1 = nonzero_shift_factor[max_index_p1]-nonzero_shift_factor[min_index_p1]+1;

        IF_VERBOSE(5) cout << "min. index p1=" << left_nonzero_indices[0] << " max. index p1=" << left_nonzero_indices[nz_p1-1] << " wordsize p1=" << ws_p1 << endl;

        // if wordsize constraint of p1 is met, check p2:
        if(ws_p1 <= ws_max_left)
        {
          int i;
          //to find the first index of p2, search for the first occurrence of an index step by 2:
          for(i=0; i < nz_p1; i++)
          {
            if(i != left_nonzero_indices[i])
              break;
          }
          min_index_p2 = i; //min index is step position

          //to find the last index of p2, search backwards for the first occurrence of an index step by -2:
          int j=0;
          for(i=nz_p1-1; i >= 0; i--, j++)
          {
            if(left_nonzero_indices[i] != nz-1-j)
              break;
          }
          max_index_p2 = nz-1-j;
          ws_p2 = nonzero_shift_factor[max_index_p2]-nonzero_shift_factor[min_index_p2]+1;
          IF_VERBOSE(5) cout << "min. index p2=" << min_index_p2 << " max. index p2=" << max_index_p2 << " wordsize p2=" << ws_p2 << endl;
        }
      }

      //for constrained wordsize, check wordsize for p1 and p2 before computing them, otherwise continue with permutation:
      if((ws_max < 0) || ((ws_p1 <= ws_max_left) && (ws_p2 <= ws_max)))
      {
        p1 = p1;
        p2 = x - p1;
        IF_VERBOSE(5) cout << "left_nonzero_indices=" << left_nonzero_indices << ": (" << (p1+p2+p3) << "=" << p1 << "+" << p2 << "+" << p3 << ")";

        p1 = fundamental(abs(p1));
        p2 = fundamental(abs(p2));
        p3 = fundamental(abs(p3));
        IF_VERBOSE(7) cout  << " fun triplet: (" << p1 << "," << p2 << "," << p3 << ")" << endl;

#ifdef DEBUG
        if(ws_max > 0)
        {
          if(!((log2f_64(p1)+1==ws_p1) || (log2f_64(p1)+2==ws_p1)) || !((log2f_64(p2)+1==ws_p2) || (log2f_64(p2)+2==ws_p2)))
          {
            cout << "nonzero_values=" << nonzero_values << endl;
            cout << "nonzero_shift_factor=" << nonzero_shift_factor << endl;
            cout << "left_nonzero_indices=" << left_nonzero_indices << ": fun pair: (" << p1 << "," << p2 << "," << p3 << ")" << endl;
            cout << "min. index p1=" << left_nonzero_indices[0] << " max. index p1=" << left_nonzero_indices[nz_p1-1] << " wordsize p1=" << ws_p1 << endl;
            cout << "min. index p2=" << min_index_p2 << " max. index p2=" << max_index_p2 << " wordsize p2=" << ws_p2 << endl;
            cout << "?? wl_p1: " << log2f_64(p1)+1 << "<=" <<  ws_p1 << "??" << endl;
            cout << "?? wl_p2: " << log2f_64(p2)+1 << "<=" <<  ws_p2 << "??" << endl;
          }
          assert((log2f_64(p1)+1==ws_p1) || (log2f_64(p1)+2==ws_p1));
          assert((log2f_64(p2)+1==ws_p2) || (log2f_64(p2)+2==ws_p2));
        }
#endif //DEBUG

        //to make p1 < p2 < p3
        int_t tmp, insert_p1 = p1, insert_p2 = p2, insert_p3 = p3;
        if(insert_p3 < insert_p2)
        {
            tmp = insert_p2;
            insert_p2 = insert_p3;
            insert_p3 = tmp;
        }
        if(insert_p2 < insert_p1)
        {
            tmp = insert_p1;
            insert_p1 = insert_p2;
            insert_p2 = tmp;
        }
        if(insert_p3 < insert_p2)
        {
            tmp = insert_p2;
            insert_p2 = insert_p3;
            insert_p3 = tmp;
        }


        if((nz_p1 <= nz_max) && (nz_p2 <= nz_max) && (ws_p1 <= ws_max))
        {
          IF_VERBOSE(4)cout  << " predecessor triplet: (" << insert_p1 << "," << insert_p2 << "," << insert_p3 << ")" << endl;
          predecessor_triplet_set->insert(int_triplet_t(insert_p1,insert_p2,insert_p3));
        }
        else
        {
          IF_VERBOSE(7) cout  << "!! invalid predecessor triplet: (" << insert_p1 << "," << insert_p2 << "," << insert_p3 << ")" << endl;
        }


      }

      if(rekursion)//for 3 input adders
      {
        vector<int> left_nonzero_values(nz_p1);
        vector<int_t> left_nonzero_shift_factor(nz_p1);
        for(int i = 0; i < nz_p1; i++)
        {
          left_nonzero_values[i] = nonzero_values[left_nonzero_indices[i]];
          left_nonzero_shift_factor[i] = nonzero_shift_factor[left_nonzero_indices[i]];
        }

        //bad sort algorithm
        int_t cash1;
        int cash2;
        bool switched = true;
        vector<int_t>::iterator vec_int_t_iter = left_nonzero_shift_factor.begin()++;
        vector<int_t>::iterator vec_int_t_iter_bevor = left_nonzero_shift_factor.begin();
        vector<int>::iterator vec_int_iter = left_nonzero_values.begin()++;
        vector<int>::iterator vec_int_iter_bevor = left_nonzero_values.begin();

        while(switched)
        {
          switched = false;
          vec_int_iter = nonzero_values.begin();
          for(; vec_int_t_iter != left_nonzero_shift_factor.end(); vec_int_t_iter++)
          {
            if((*vec_int_t_iter) < (*vec_int_t_iter_bevor))
            {
              cash1 = *vec_int_t_iter;
              *vec_int_t_iter = *vec_int_t_iter_bevor;
              *vec_int_t_iter_bevor = cash1;

              cash2 = *vec_int_iter;
              *vec_int_iter = *vec_int_iter_bevor;
              *vec_int_iter_bevor = cash2;
              switched = true;
            }
            vec_int_t_iter_bevor = vec_int_t_iter;
            vec_int_iter_bevor = vec_int_iter;
          }
        }
        permutation_for_predeccessor_pairs(left_nonzero_values, left_nonzero_shift_factor, predecessor_triplet_set, ws_max, nz_max, false, p2);
      }


      //do permutation:
      while(left_nonzero_indices[index] >= nz-1-(nz_p1-1-index))
      {
        index--;
        if(index < 0)
          break;
      }
      if(index < 0)
        break;

      if(left_nonzero_indices[index] < nz-1-(nz_p1-1-index))
        left_nonzero_indices[index]++;

      for(;index < nz_p1-1;index++)
      {
        if(left_nonzero_indices[index] < nz-1)
          left_nonzero_indices[index+1] = left_nonzero_indices[index]+1;
      }

    }
  }
}
