#include "compute_successor_set.h"

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

#include "csd.h"
#include "rpag_basis.h"
#include "rpag.h"   // two input adder
#include "rpagt.h"  // three input adder
#include "rpagvm.h" // vector matrix
#include "main.h"
#include "tic_toc.h"

#include "fundamental.h"

#define testfunktion 0

#if testfunktion

void test()
{
  std::cout << "Hallo dies ist die test routine" << std::endl;

  vec_t test(3);
  test =5;
  std::cout << generate_matlab_line(test=5,1,test=1,0,2,1,test=3,0,0,1);

  {

  vec_t mytest(4);
  vec_set_t set_a;
  vec_set_t set_b;
  vec_set_t set_c;



  mytest[0] = 0;//8
  mytest[1] = 5;//3
  mytest[2] = 0;//6
  mytest[3] = 0;//9
set_a.insert(mytest);
mytest[0] = 1;//8
mytest[1] = 24;//3
mytest[2] = 0;//6
mytest[3] = 0;//9
set_b.insert(mytest);





    //compute_successor_set(&set_a,&set_b,70,&set_c,false);
global_verbose=7;
    compute_successor_set(&set_a,&set_b,60,&set_c);

    for(vec_set_t::iterator it= set_c.begin(); it !=set_c.end(); ++it)
    {
      std::cout << "(" << *it << ")" << std::endl;
    }

    std::cin.get();

    exit(0);

//  vec_t x(0);
//  x.push_back(-5);
//  x.push_back(10);
//  x.push_back(20);
//  std::cout << "adder depth(" << x << "):" << log2c_64(nonzeros(abs(x))) <<std::endl;

//  std::cout <<"mod :"<< (10%3) <<std::endl;
//  std::cout <<"mod :"<< (-10%3) <<std::endl;
//  std::cout <<"shift :"<< (10<<1) <<std::endl;
//  std::cout <<"shift :"<< (-10<<1) <<std::endl;

//  int_t inti =-3;
//  std::cout <<"Norm:" << x << " -> " << norm(x) <<std::endl;
//  std::cout <<"Norm:" << inti << " -> " << norm(inti) <<std::endl;

    //compute_topology_d_predecessors_2_Add_I(w, nz_max, wordsize_constraints[s-1], &predecessor_pair_set);

  exit(0);
  }
}

#endif

int print_short_help()
{
  cout << "usage: rpag [OPTIONS] coefficients" << endl;
  cout << endl;
  cout << "General Options:" << endl;
  cout << "Option                                         Meaning" << endl;
  cout << "--help                                         Prints this help" << endl;
  cout << "--verbose=0...8                                Verbosity level (0: no information, 8: all information during optimization), default:1" << endl;
  cout << "--cost_model=hl_fpga|ll_fpga|hl_asic|ll_asic|min_ad_hl_fpga|min_ad_ll_fpga]:" << endl;
  cout << "                                               Selects one of the following cost models (default: hl_fpga):" << endl;
  cout << "                                               hl_fpga: the cost of each adder and register are equal to one" << endl;
  cout << "                                               ll_fpga: the cost of each adder and register are equal to its word size (input word size + coeff. word size)" << endl;
  cout << "                                               hl_asic: the cost of adder is twice than of a register (c_a=2, c_r=1)" << endl;
  cout << "                                               min_ad_hl_fpga: each target is scheduled according to its minimal adder depth; the cost of each adder is one, the cost of a register is zero" << endl;
  cout << "                                               min_ad_ll_fpga: same as 'min_ad_hl_fpga' but adder cost is computed from the word size (input word size + coeff. word size)" << endl;
  cout << "--input_wordsize=[int]                         Word size of the input of the MCM block in no of bits" << endl;
  //features not implemented:
  //  cout << "                                               ll_asic: currently not supported" << endl;
  //  cout << "--exhaustive=true|false                        Enables the exhaustive mode, where allways successor pairs are evaluated, default:false" << endl;
  cout << "--no_of_extra_stages=int                       Per default, the pipeline depth is chosen to the minimum possible, more pipeline stages can be selected by choosing no_of_extra_stages>0, default:0" << endl;
  cout << endl;
  cout << "Options for meta optimizations (where several RPAG runs are used to further optimize the result):" << endl;
  cout << "  There are two meta-heuristics implemented:" << endl;
  cout << "   1) Meta greedy heuristic: The n'th best decisions (set by the 'meta_greedy_search_depth' parameter') are evaluated and the best one is taken for evaluating the next decision." << endl;
  cout << "      The algorithm automatically terminates, the 'no_of_runs' parameter is ignored." << endl;
  cout << "   2) Random selection: Not the locally best decision is taken but the n'th best is chosen randomly (set by 'rand_variance' parameter)." << endl;
  cout << "      The best result out of 'no_of_runs' is taken, the first run is always pure greedy." << endl;
  cout << "      The meta greedy has to be disabled by setting meta_greedy_search_depth=-1 for random selection." << endl;
  cout << "  Note that better results in less iterations are typically achieved by using the meta greedy heuristic." << endl;
  cout << "Option                                         Meaning" << endl;
  cout << "--meta_greedy_search_depth=int                 How many different decisions exept the globally best one are evaluated, default:10?" << endl;
  cout << "--rand_variance=real                           Sets the random variance in selecting not the locally best solution, default:0" << endl;
  cout << "--no_of_runs=int                               Sets the number of optimization runs that are performed for a single instance, default:1" << endl;
  cout << "--rand_seed=int                                For manually setting the seed used for random variance generation, default:current time" << endl;
  cout << "--show_adder_graph                             Computes and plots the adder graph solution including shift values" << endl;
  cout << endl;
  cout << "Options for ternary (3-input) adder support:" << endl;
  cout << "Option                                         Meaning" << endl;
  cout << "--ternary_adders                               Uses ternary adders where possible to reduce resources and pipeline depth" << endl;
  cout << endl;
  cout << "Options for hybrid optimizations (which include embedded multipliers):" << endl;
  cout << "Option                                         Meaning" << endl;
  cout << "--mult_wordsize=int                            Word size of embedded multiplier that should be incorporated into the optimization" << endl;
  cout << "--max_no_of_mult=int                           Maximal number of embedded multiplier that should be used" << endl;
  cout << "--wordsize_constraints=[int int ...]           A vector of word size constraints for each stage" << endl;
  cout << "--adder_depth_constraints=[int int ...]        A vector of adder depth constraints for each stage" << endl;
  cout << endl;
  cout << "Examples:" << endl;
  cout << "rpag 11280171 13342037                         Finds the pipelined adder graph nodes of coefficients 11280171 and 13342037 for an FPGA" << endl;
  cout << endl;
  cout << "rpag --mult_wordsize=17 11280171 13342037      As above, but includes 17 bit multipliers (as many as necessary)" << endl;
  cout << endl;
  cout << "rpag --mult_wordsize=17 \\" << endl;
  cout << "     --max_no_of_mult=1 11280171 13342037      As above, but uses only one embedded multiplier" << endl;
  cout << endl;
  cout << "rpag --mult_wordsize=17 \\" << endl;
  cout << "     --wordsize_constraints=[-1 -1 17 24] \\" << endl;
  cout << "     --adder_depth_constraints=[1 2 3 -1] \\" << endl;
  cout << "     --max_no_of_mult=1 11280171 13342037      As above, but explicitly set the constraints to result in a lower graph depth" << endl;
  cout << endl;
  cout << "--msd_cutter_iteration_max=int                 Limit of iterations for topologie d during permutation. (for -1 ther is no limit)"<< endl;
  cout << "--msd_iteration_max=int                        Limit of different msd representations. (for -1 ther is no limit)"<< endl;

  exit(0);
}

int print_exhaustive_help()
{
  cout << "exhaustive help is not implemented" << endl;
  print_short_help();
  exit(0);
}
int rpag_pointer::input_wordsize;

int main(int argc, char *argv[])
{
#if testfunktion
  test();
#endif
  global_verbose=0;

  rpag_pointer *rpagp = NULL;
  rpagp = new rpag(); //default is RPAG with 2 input adders
  bool ternary_adders = false;
  bool vector_input = false;
  int input_wordsize;
  int_set_t target_set;
  vec_set_t vec_target_set;

  //set_default_elem_count(1);// to be shure that all vectors have minimal one element

  //enum to identify if a sequence of numbers corresponds to coefficients, adder depth constraints or word size constraints:
  enum number_sequence_mode_t{COEFF, AD, WS} number_sequence_mode=COEFF;

  for(int i = 1; i < argc; i++)
  {
    if((argv[i][0] != '-') || (argv[i][1] != '-'))
      switch(number_sequence_mode)
      {
      case COEFF:
        rpagp->target_vec.push_back(argv[i]);
        break;
      case AD:
        rpagp->adder_depth_constraints.push_back(atoi(argv[i]));
        break;
      case WS:
        rpagp->wordsize_constraints.push_back(atoi(argv[i]));
        break;
      }
    else
    {
      number_sequence_mode = COEFF; //default mode
      if(strstr(argv[i], "--verbose="))
      {
        global_verbose = atol(argv[i]+10);
      }
      else if(strstr(argv[i], "--cost_model="))
      {
        if(!strcmp(argv[i]+13,"hl_fpga"))
        {
          rpagp->cost_model = HL_FPGA;
        }
        else if(!strcmp(argv[i]+13,"ll_fpga"))
        {
          rpagp->cost_model = LL_FPGA;
        }
        else if(!strcmp(argv[i]+13,"hl_asic"))
        {
          rpagp->cost_model = HL_ASIC;
        }
        else if(!strcmp(argv[i]+13,"ll_asic"))
        {
          rpagp->cost_model = LL_ASIC;
        }
        else if(!strcmp(argv[i]+13,"min_ad_ll_fpga"))
        {
          rpagp->cost_model = MIN_AD_LL_FPGA;
        }
        else if(!strcmp(argv[i]+13,"min_ad_hl_fpga"))
        {
          rpagp->cost_model = MIN_AD_HL_FPGA;
        }
        else
        {
          cerr << "Error: cost model " << argv[i]+13 << " unknown" << endl;
          exit(-1);
        }
      }
      else if(strstr(argv[i], "--input_wordsize="))
      {
        input_wordsize = atoi(argv[i]+17);
        rpagp->input_wordsize = input_wordsize;
      }
      else if(strstr(argv[i], "--exhaustive="))
      {
        if(strstr(argv[i]+13, "true"))
        {
          rpagp->exhaustive=true;
        }
        else if(strstr(argv[i]+13, "false"))
        {
          rpagp->exhaustive=false;
        }
        else
        {
          cout << "Error: exhaustive must be true or false" << endl;
          return -1;
        }
      }
      else if(strstr(argv[i], "--rand_variance="))
      {
        rpagp->rand_variance = atof(argv[i]+16);
      }
      else if(strstr(argv[i], "--rand_seed="))
      {
        rpagp->rand_seed = atoi(argv[i]+12);
      }
      else if(strstr(argv[i], "--no_of_runs="))
      {
        rpagp->no_of_runs = atoi(argv[i]+13);
      }
      else if(strstr(argv[i], "--mult_wordsize="))
      {
        rpagp->mult_wordsize = atoi(argv[i]+16);
      }
      else if(strstr(argv[i], "--max_no_of_mult="))
      {
        rpagp->max_no_of_mult = atoi(argv[i]+17);
      }
      else if(strstr(argv[i], "--help"))
      {
        print_exhaustive_help();
      }
      else if(strstr(argv[i], "--stages_embedded_mult="))
      {
        rpagp->stages_embedded_mult = atoi(argv[i]+23);

      }
      else if(strstr(argv[i], "--wordsize_constraints=["))
      {
        rpagp->wordsize_constraints.push_back(atoi(argv[i]+24));
        number_sequence_mode = WS; //swith to wordsize constraints
      }
      else if(strstr(argv[i], "--adder_depth_constraints=["))
      {
        rpagp->adder_depth_constraints.push_back(atoi(argv[i]+27));
        number_sequence_mode = AD; //swith to wordsize constraints
      }
      else if(strstr(argv[i], "--force_minimal_depth"))
      {
        rpagp->force_minimal_depth = true;
      }
      else if(strstr(argv[i], "--no_of_extra_stages="))
      {
        rpagp->no_of_extra_stages = atoi(argv[i]+21);
      }
      else if(strstr(argv[i], "--meta_greedy_search_depth="))
      {
        rpagp->meta_greedy_search_depth = atoi(argv[i]+27);
      }
      else if(strstr(argv[i], "--benchmark"))
      {
        rpagp->benchmark = true;
      }
      else if(strstr(argv[i], "--show_adder_graph"))
      {
        rpagp->show_adder_graph = true;
      }
      else if(strstr(argv[i], "--msd_cutter_iteration_max="))
      {
        rpagp->msd_cutter_iteration_max = atoi(argv[i]+27);
      }
      else if(strstr(argv[i], "--msd_iteration_max="))
      {
        rpagp->msd_iteration_max = atoi(argv[i]+20);
      }
      else if(strstr(argv[i], "--ternary_adders"))
      {
        ternary_adders = true;
        rpag_pointer *rpag2p = rpagp;

        // use the functions for 3 input adder.
        rpagp = new rpagt();

        rpagp->input_wordsize = rpag2p->input_wordsize;
        rpagp->target_vec = rpag2p->target_vec;
        rpagp->adder_depth_constraints = rpag2p->adder_depth_constraints;
        rpagp->wordsize_constraints = rpag2p->wordsize_constraints;
        rpagp->cost_model = rpag2p->cost_model;
        rpagp->exhaustive = rpag2p->exhaustive;
        rpagp->rand_variance = rpag2p->rand_variance;
        rpagp->rand_seed = rpag2p->rand_seed;
        rpagp->no_of_runs = rpag2p->no_of_runs;
        rpagp->mult_wordsize = rpag2p->mult_wordsize;
        rpagp->max_no_of_mult = rpag2p->max_no_of_mult;
        rpagp->stages_embedded_mult = rpag2p->stages_embedded_mult;
        rpagp->force_minimal_depth = rpag2p->force_minimal_depth;
        rpagp->no_of_extra_stages = rpag2p->no_of_extra_stages;
        rpagp->meta_greedy_search_depth = rpag2p->meta_greedy_search_depth;
        rpagp->benchmark = rpag2p->benchmark;
        rpagp->show_adder_graph = rpag2p->show_adder_graph;
        rpagp->msd_cutter_iteration_max = rpag2p->msd_cutter_iteration_max;
        rpagp->msd_iteration_max = rpag2p->msd_iteration_max;
        rpagp->ternary_adders = true;
        delete rpag2p;
      }
      else if(strstr(argv[i], "--cmm"))
      {
        vector_input = true;
        rpag_pointer *rpag2p = rpagp;

        // use the functions for vector matrix multiplikation.
        rpagp = new rpagvm();

        rpagp->input_wordsize = rpag2p->input_wordsize;
        rpagp->target_vec = rpag2p->target_vec;
        rpagp->adder_depth_constraints = rpag2p->adder_depth_constraints;
        rpagp->wordsize_constraints = rpag2p->wordsize_constraints;
        rpagp->cost_model = rpag2p->cost_model;
        rpagp->exhaustive = rpag2p->exhaustive;
        rpagp->rand_variance = rpag2p->rand_variance;
        rpagp->rand_seed = rpag2p->rand_seed;
        rpagp->no_of_runs = rpag2p->no_of_runs;
        rpagp->mult_wordsize = rpag2p->mult_wordsize;
        rpagp->max_no_of_mult = rpag2p->max_no_of_mult;
        rpagp->stages_embedded_mult = rpag2p->stages_embedded_mult;
        rpagp->force_minimal_depth = rpag2p->force_minimal_depth;
        rpagp->no_of_extra_stages = rpag2p->no_of_extra_stages;
        rpagp->meta_greedy_search_depth = rpag2p->meta_greedy_search_depth;
        rpagp->benchmark = rpag2p->benchmark;
        rpagp->show_adder_graph = rpag2p->show_adder_graph;
        rpagp->msd_cutter_iteration_max = rpag2p->msd_cutter_iteration_max;
        rpagp->msd_iteration_max = rpag2p->msd_iteration_max;
        rpagp->ternary_adders = rpag2p->ternary_adders;


        delete rpag2p;
      }
      else
      {
        cout << "Error: Illegal Option: " << argv[i] << endl;
        print_short_help();
      }
    }
  }

  //std::cout << "vec_set:" << std::endl << vec_target_set;
  if(rpagp->rand_seed < 0)
  {
    rpagp->rand_seed = time(0); // use current time as seed for random generator
  }

  IF_VERBOSE(2)
  {
    cout << "RPAG parameters:" << endl;
    cout << "    verbosity level=" << global_verbose << endl;
    cout << "    cost model=" << rpagp->cost_model << endl;
    cout << "    input word size=" << rpagp->input_wordsize<< endl;

    cout << "    exhaustive=" << rpagp->exhaustive << endl;
    cout << "    random variance=" << rpagp->rand_variance << endl;
    cout << "    random seed=" << rpagp->rand_seed << endl;
    cout << "    number of runs=" << rpagp->no_of_runs << endl;
    cout << "    meta greedy search depth=" << rpagp->meta_greedy_search_depth << endl;

    cout << "    msd cutter iteration max. =" << rpagp->msd_cutter_iteration_max << endl;
    cout << "    max. no of mult=" << rpagp->max_no_of_mult << endl;
    cout << "    multiplier word size=" << rpagp->mult_wordsize << endl;
    cout << "    wordsize constraints=" << rpagp->wordsize_constraints << endl;
    cout << "    adder depth constraints=" << rpagp->adder_depth_constraints << endl;
    cout << "    no. of extra stages=" << rpagp->no_of_extra_stages << endl;
    cout << "    optimize for ternary adders=" << ternary_adders << endl;

  }

  if(rpagp->target_vec.empty())
  {
    print_short_help();
  }
  else
  {
#ifdef USE_TIME
    tic();
#endif
      rpagp->optimize();
#ifdef USE_TIME
    IF_VERBOSE(1) toc();
#endif
  }


  return 1;
}


