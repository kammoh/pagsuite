#include <iostream>

using namespace std;

#include "types.h"
#include "debug.h"

int global_verbose=0;

ostream& operator<<(ostream &s, sd_t& sd)
{
  sd_t::iterator iter;
  for(iter = sd.begin(); iter != sd.end(); )
  {
    if(*iter >= 0)
      s << " " << *iter;
    else
      s << *iter;

    ++iter;
    if(iter != sd.end())
      s  << " ";
  }
  return s;
}

ostream& operator<<(ostream &s, sd_set_t& msd_set)
{
  sd_set_t::iterator iter;
  for(iter = msd_set.begin(); iter != msd_set.end(); ++iter)
  {
    sd_t sd = *iter;
    s << "(" << sd << ")" << endl;
  }
  return s;
}


ostream& operator<<(ostream &s, int_triplet_t& int_triplet)
{
  s << "<" << int_triplet.first << "," << int_triplet.second << "," << int_triplet.third << ">";
  return s;
}

ostream& operator<<(ostream &s, int_triplet_double_map_t& int_triplet_double_map)
{
  int_triplet_double_map_t::iterator iter;
  for (iter=int_triplet_double_map.begin(); iter != int_triplet_double_map.end(); ++iter)
  {
    int_triplet_t t = (*iter).first;
    s << t << ":" << (*iter).second << " ";
  }
  return s;
}
