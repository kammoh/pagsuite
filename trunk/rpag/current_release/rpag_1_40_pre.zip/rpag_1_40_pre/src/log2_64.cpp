#include "log2_64.h"
#include <math.h>

//64 bit implementation of floor(log2(int x))
int log2f_64(uint64_t n)
{
  if(n == 0) return -1;

  int log = 0;
  if (n & 0xffffffff00000000LL) { n >>= 32; log |= 32; } //check if upper 32 bits contain a one, if true, shift them to LSB and add 32 to the logarithm
  if (n & 0xffff0000)           { n >>= 16; log |= 16; }
  if (n & 0xff00)               { n >>= 8;  log |= 8; }
  if (n & 0xf0)                 { n >>= 4;  log |= 4; }
  if (n & 0xc)                  { n >>= 2;  log |= 2; }
  if (n & 0x2)                  { n >>= 1;  log |= 1; }

  return log;
}

//64 bit implementation of ceil(log2(int x))
int log2c_64(uint64_t n)
{
  if(n == 0) return -1;

  int log = 0;
  uint64_t zero_check=0;
  if (n & 0xffffffff00000000LL) { log |= 32; zero_check |= (n & 0x00000000ffffffffLL); n >>= 32; } //check if upper 32 bits contain a one, if true, shift them to LSB and add 32 to the logarithm
  if (n & 0xffff0000)           { log |= 16; zero_check |= (n & 0x0000ffff);           n >>= 16; }
  if (n & 0xff00)               { log |= 8;  zero_check |= (n & 0x00ff);               n >>= 8;  }
  if (n & 0xf0)                 { log |= 4;  zero_check |= (n & 0x0f);                 n >>= 4;  }
  if (n & 0xc)                  { log |= 2;  zero_check |= (n & 0x3);                  n >>= 2;  }
  if (n & 0x2)                  { log |= 1;  zero_check |= (n & 0x1);                          }

  return zero_check == 0? log : log+1; //if zero_check != 1 means that n != 2^i and it must be round up
}

//64 bit implementation of floor(log3(int x))
int log3f_64(uint64_t n)
{
  if(n == 0) return -1;
//  return (int) floor(logf((float) n)/logf(3));

  int log = 0;
  if (n >= 3)   {log++;} // log = 1
  if (n >= 9)   {log++;} // log = 2
  if (n >= 27)  {log++;} // log = 3
  if (n >= 81)  {log++;} // log = 4
  if (n >= 243) {log++;} // log = 5
  if (n >= 729) {log++;} // log = 6
  if (n >= 2187){log++;} // log = 7
  if (n >= 6561){log++;} // log = 8
  if (n >= 6561){log++;} // log = 9
  if (n >= 19683){log++;} // log = 10
  if (n >= 59049){log++;} // log = 11

  return log;
}

//64 bit implementation of ceil(log3(int x))
int log3c_64(uint64_t n)
{
  if(n == 0) return -1;
//  return (int) ceil(logf((float) n)/logf(3));

  int log = 11;
  if (n <= 59049){log--;} // log = 10
  if (n <= 19683){log--;} // log = 9
  if (n <= 6561){log--;} // log = 8
  if (n <= 2187){log--;} // log = 7
  if (n <= 729) {log--;} // log = 6
  if (n <= 243) {log--;} // log = 5
  if (n <= 81)  {log--;} // log = 4
  if (n <= 27)  {log--;} // log = 3
  if (n <= 9)   {log--;} // log = 2
  if (n <= 3)   {log--;} // log = 1

  return log;
}
