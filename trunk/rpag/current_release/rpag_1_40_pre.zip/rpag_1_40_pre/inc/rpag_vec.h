#ifndef RPAG_VEC_H
#define RPAG_VEC_H
#include <vector>

#include <ostream>
#include <iostream>
//#include <iomanip>

/// Funktionsmakros

#define GET_OPERATION_WITH_T(x) \
        bool out = true;\
        typename rpag_vec<T>::const_iterator iter = this->begin();\
        while(iter != this->end()){\
          if(!(*iter x rhs)){\
            out = false;}\
          ++iter;}\
        return out;

#define GET_OPERATION_WITH_RPAG_VEC(x) \
        if(this->size() == rhs.size()){\
          bool out = true;\
          typename rpag_vec<T>::const_iterator it_r = rhs.begin(), it_l = this->begin();\
          while(it_l != this->end()){\
            if(!(*it_l x *it_r)){\
            out = false;}\
            ++it_l;\
            ++it_r;}\
            return out;}\
        else{\
          return false;}

#define SET_OPERATION_WITH_T(x) \
        typename rpag_vec<T>::const_iterator it = this->begin(); \
        rpag_vec<T> out(0); \
        while(it != this->end()){ \
          out.push_back((*it x rhs)); \
          ++it;} \
        return out;

#define SET_OPERATION_RETURN_SELF_WITH_T(x) \
        typename rpag_vec<T>::iterator iter = this->begin();\
        while(iter != this->end()){\
          *iter x rhs;\
          ++iter;}\
        return *this;

#define SET_OPERATION_WITH_RPAG_VEC(x) \
        rpag_vec<T> out(0); \
        if(this->size() == rhs.size()){\
          typename rpag_vec<T>::const_iterator it_l = this->begin();\
          typename rpag_vec<T>::const_iterator it_r = rhs.begin();\
          while(it_l != this->end()){\
            out.push_back(*it_l x *it_r);\
            ++it_l;\
            ++it_r;}}else{std::cout << "\n!fehler!\n";}\
         return out;

#define SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(x) \
        if(this->size() == rhs.size()){\
          typename rpag_vec<T>::iterator it_l = this->begin();\
          typename rpag_vec<T>::const_iterator it_r = rhs.begin();\
          while(it_l != this->end()){\
            *it_l x *it_r;\
            ++it_l;\
            ++it_r;}}else{std::cout << "\n!fehler!\n";}\
         return *this;

template<typename T, typename Alloc = std::allocator<T> >
class rpag_vec : public std::vector<T, Alloc>
{

public:

    static unsigned int default_elem_count;
    friend void set_default_elem_count(unsigned int input);
    rpag_vec<T, Alloc>(void)
    {
      for(unsigned int elements=default_elem_count; elements > 0; --elements)
      {
        this->push_back(0);
      }
    }

    rpag_vec<T, Alloc>(unsigned int elements)
    {
      for(; elements > 0; --elements)
      {
        this->push_back(0);
      }
    }

    void set_default_elem_count(unsigned int input)
    {
      this->default_elem_count = input;
    }



    /// Zugriffssoperationen
    ///    mit einem Element
    rpag_vec<T, Alloc> operator=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(=)
    }
    rpag_vec<T, Alloc> operator+=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(+=)
    }
    rpag_vec<T, Alloc> operator-=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(-=)
    }
    rpag_vec<T, Alloc> operator*=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(*=)
    }
    rpag_vec<T, Alloc> operator/=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(/=)
    }
    rpag_vec<T, Alloc> operator%=(const T rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_T(%=)
    }


    const rpag_vec<T, Alloc> operator+(const T rhs) const
    {
      std::cout << std::endl << "addition aufgerufen" << std::endl;
      SET_OPERATION_WITH_T(+)
    }
    const rpag_vec<T, Alloc> operator-(const T rhs) const
    {
      SET_OPERATION_WITH_T(-)
    }
    const rpag_vec<T, Alloc> operator*(const T rhs) const
    {
      SET_OPERATION_WITH_T(*)
    }
    const rpag_vec<T, Alloc> operator/(const T rhs) const
    {
      SET_OPERATION_WITH_T(/)
    }
    const rpag_vec<T, Alloc> operator%(const T rhs) const
    {
      SET_OPERATION_WITH_T(%)
    }
    const rpag_vec<T, Alloc> operator<< (const T rhs) const
    {
      SET_OPERATION_WITH_T(<<)
    }
    const rpag_vec<T, Alloc> operator>> (const T rhs) const
    {
      SET_OPERATION_WITH_T(>>)
    }


    /// Zugriffssoperationen
    ///         mit rpag_vec

    rpag_vec<T, Alloc> operator=(const rpag_vec<T, Alloc> &rhs)
    {
      typename rpag_vec<T>::const_iterator it_r = rhs.begin();
      if(rhs.size() != this->size())
      {
        this->clear();
        for(; it_r != rhs.end(); ++it_r)
        {
          this->push_back(*it_r);
        }
        return *this;
      }
      else
      {
          typename rpag_vec<T>::iterator it_l = this->begin();
          while(it_l != this->end())
          {
            *it_l = *it_r;
            ++it_l;
            ++it_r;
          }
         return *this;
      }
    }


    rpag_vec<T, Alloc> operator+=(const rpag_vec<T, Alloc> rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(+=)
    }
    rpag_vec<T, Alloc> operator-=(const rpag_vec<T, Alloc> &rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(-=)
    }
    rpag_vec<T, Alloc> operator*=(const rpag_vec<T, Alloc> &rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(*=)
    }
    rpag_vec<T, Alloc> operator/=(const rpag_vec<T, Alloc> &rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(/=)
    }
    rpag_vec<T, Alloc> operator%=(const rpag_vec<T, Alloc> &rhs)
    {
      SET_OPERATION_RETURN_SELF_WITH_RPAG_VEC(%=)
    }


    const rpag_vec<T, Alloc> operator+(const rpag_vec<T, Alloc> &rhs) const
    {
      SET_OPERATION_WITH_RPAG_VEC(+)
    }
    const rpag_vec<T, Alloc> operator-(const rpag_vec<T, Alloc> &rhs) const
    {
      SET_OPERATION_WITH_RPAG_VEC(-)
    }
    const rpag_vec<T, Alloc> operator*(const rpag_vec<T, Alloc> &rhs) const
    {
      SET_OPERATION_WITH_RPAG_VEC(*)
    }
    const rpag_vec<T, Alloc> operator/(const rpag_vec<T, Alloc> &rhs) const
    {
      SET_OPERATION_WITH_RPAG_VEC(/)
    }
    const rpag_vec<T, Alloc> operator%(const rpag_vec<T, Alloc> &rhs) const
    {
      SET_OPERATION_WITH_RPAG_VEC(%)
    }

    /// Zugriffssoperationen
    ///         ohne Element

    rpag_vec<T, Alloc> operator++()
    {
      typename rpag_vec<T>::iterator it_l = this->begin();
      while(it_l != this->end())
      {
        ++(*it_l);
        ++it_l;
      }
      return *this;
    }

    rpag_vec<T, Alloc> operator--()
    {
      typename rpag_vec<T>::iterator it_l = this->begin();
      while(it_l != this->end())
      {
        --(*it_l);
        ++it_l;
      }
      return *this;
    }


    /// Vergleichsoperationen
    ///     mit einem Element

    const bool operator==(const T &rhs) const
    {
      GET_OPERATION_WITH_T(==)
    }
    const bool operator!=(const T &rhs) const
    {
      return (!(*this == rhs));
    }
    const bool operator<(T &rhs) const
    {
      GET_OPERATION_WITH_T(<)
    }
    const bool operator> (const T &rhs) const
    {
      GET_OPERATION_WITH_T(>)
    }
    const bool operator<= (const T &rhs) const
    {
      GET_OPERATION_WITH_T(<=)
    }
    const bool operator>= (const T &rhs) const
    {
      GET_OPERATION_WITH_T(>=)
    }


    /// Vergleichsoperationen
    ///          mit rpag_vec
    bool operator==(const rpag_vec<T, Alloc>& rhs) const
    {
      GET_OPERATION_WITH_RPAG_VEC(==)
    }
    const bool operator!=(const rpag_vec<T, Alloc>& rhs) const
    {
      return (!(*this == rhs));
    }

    const bool less (const rpag_vec<T, Alloc>& rhs) const
    {
      GET_OPERATION_WITH_RPAG_VEC(<)
    }
    const bool greater(const rpag_vec<T, Alloc>& rhs) const
    {
      GET_OPERATION_WITH_RPAG_VEC(>)
    }
    const bool less_or_equal(const rpag_vec<T, Alloc>& rhs) const
    {
      GET_OPERATION_WITH_RPAG_VEC(<=)
    }
    const bool greater_or_equal(const rpag_vec<T, Alloc>& rhs) const
    {
      GET_OPERATION_WITH_RPAG_VEC(>=)
    }
    /// Funktionenen
    /// von rpag_vec

    const T max() const
    {
      typename rpag_vec<T, Alloc>::const_iterator iter = this->begin();
      T value = *iter;
      for(; iter != this->end(); ++iter)
      {
        if(*iter > value)
          value = *iter;
      }
      return value;
    }

    const T min(bool without_zero = false) const
    {

      typename rpag_vec<T, Alloc>::const_iterator iter = this->begin();
      T value=0;
      if(without_zero)
      {
        for(; iter != this->end(); ++iter)
        {
          if(value == 0)
          {
            if(*iter != 0)
            {
              value = *iter;
            }
          }
          else
          {
            if((*iter < value)&&(*iter != 0))
            {
              value = *iter;
            }
          }
        }
        return value;
      }
      else
      {
        for(; iter != this->end(); ++iter)
        {
          if(*iter < value)
          {
            value = *iter;
          }
        }
        return value;
      }
    }

};
template<typename T, typename Alloc> unsigned int rpag_vec<T, Alloc>::default_elem_count = 1;

template<typename T, typename Alloc>
  rpag_vec<T, Alloc> operator+ (const T _lhs, const rpag_vec<T, Alloc> &_rhs)
  {
    return (_rhs + _lhs);
  }

template<typename T, typename Alloc>
  rpag_vec<T, Alloc> operator- (const T _lhs, const rpag_vec<T, Alloc> &_rhs)
  {
    return ((_rhs * ((T)-1)) + _lhs);
  }
template<typename T, typename Alloc>
  rpag_vec<T, Alloc> operator* (const T _lhs, const rpag_vec<T, Alloc> &_rhs)
  {
    return (_rhs * _lhs);
  }

template<typename T, typename Alloc>
  std::ostream & operator<< (std::ostream &s, const rpag_vec<T, Alloc>& vec)
  {
    typename rpag_vec<T, Alloc>::const_iterator iter;
    for(iter = vec.begin(); iter != vec.end();)
    {
      s << (*iter);
      ++iter;
      if(iter != vec.end())
      {s  << ";";}
    }
    return s;
  }

template<typename T, typename Alloc>
  rpag_vec<T, Alloc> abs(const rpag_vec<T, Alloc> &rhs)
  {
    rpag_vec<T, Alloc> out(0);
    typename rpag_vec<T>::const_iterator it_r;
    {
      T dummi;
      for(it_r = rhs.begin(); it_r != rhs.end(); ++it_r)
      {
        dummi = *it_r;
        if(dummi < 0){dummi *= (-1);}
        out.push_back(dummi);

      }
      return out;
    }
  }


#endif // RPAG_VEC_H
