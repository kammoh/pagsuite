#ifndef NORM_H
#define NORM_H

#include "types.h"
#include "debug.h"

int_t norm(int_t in);
vec_t norm(vec_t in);


#endif // NORM_H
