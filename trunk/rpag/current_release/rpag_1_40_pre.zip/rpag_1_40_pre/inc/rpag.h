#ifndef RPAG_H
#define RPAG_H

#include "types.h"
#include "rpag_basis.h"

class rpag :public rpag_basis<int_t>
{
public:
  rpag();
  virtual ~rpag();
protected:

  void compute_topology_a_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_a=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_b_predecessors_2_Add_I(const int_set_t *working_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_b=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_c_predecessors_2_Add_I(const int_set_t *working_set, const int_set_t *predecessor_set, int_double_map_t *gain_map, int s_max, int ws_max=-1, int_set_t *p_set_c=NULL, int_pair_double_map_t *p_w_gain_map=NULL);
  void compute_topology_d_predecessors_2_Add_I(int_t x, int nz_max, int ws_max, int_pair_set_t *predecessor_pair_set);

  virtual int adder_depth(int_t x);

private:
  //###################################################################
  virtual bool is_this_a_two_input_system(void){return true;}

  virtual int_t get_best_single_predecessor(const int_set_t &working_set, const int_set_t &predecessor_set, int s);
  virtual void get_best_multi_predecessor(const int_set_t &working_set, int_set_t *predecessor_set, int s);
  void update_pair_gain_map(set<pair<int_t,int_t> > &predecessor_pair_set, int_t w, const int_set_t &working_set, int_pair_double_map_t &pair_gain_map);

};

#endif // RPAG_H
