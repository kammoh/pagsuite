pub_options.evalCode = false;
pub_options.outputDir = 'doc';
publish('rpag.m',pub_options)