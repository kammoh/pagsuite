#ifndef MT_DEBUG_H
#define MT_DEBUG_H

#include <streambuf>
#include <iostream>

#endif // MT_DEBUG_H
