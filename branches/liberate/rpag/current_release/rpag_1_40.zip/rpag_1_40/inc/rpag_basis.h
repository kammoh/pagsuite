#ifndef RPAG_BASIS_H
#define RPAG_BASIS_H

#include "types.h"

#include "rpag_pointer.h"
#include "adder_depth.h"
#include "fundamental.h"
#include "log2_64.h"
#include "debug.h"
#include "csd.h"
#include "compute_successor_set.h"
#include "norm.h"
#include <utility>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <string> // for rpag_atoll
#include <typeinfo> // for rpag optimize target set


  int_t max_elem(const vec_t &rhs);
  int_t max_elem(const int_t &rhs);

  vec_t my_atoll(vec_t to, char* input);
  int_t my_atoll(int_t to, char* input);


  void make_one_by(vec_t &var, unsigned int i);
  void make_one_by(int_t &var, unsigned int i);

template <class T>
class rpag_basis : public rpag_pointer
{
public:
  rpag_basis();
  virtual ~rpag_basis();

  int optimize();

protected:

  int optimize_single_run(const set<T> *target_fun_set, vector< set<T> > *pipeline_set);

  //internal parameters:
  int_t c_max;

  int stages_input_pag;
  int stages_output_pag;

  static double cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_hl_fpga(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_hl_fpga(int_t x);
  static double cost_pag_hl_fpga(vector<set<T> > *pipeline_set);
  static double cost_add_vector_hl_fpga(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max = 1);
  static double cost_reg_vector_hl_fpga(vec_t x, int c_max = 1);

  static double cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_ll_fpga(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_ll_fpga(int_t x);
  static double cost_pag_ll_fpga(vector<set<int_t> > *pipeline_set);
  static double cost_pag_ll_fpga(vector<set<vec_t> > *pipeline_set);
  //static double cost_add_vector_ll_fpga(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max = 1);
  //static double cost_reg_vector_ll_fpga(vec_t x, int c_max = 1);

  static double cost_add_hl_asic(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_hl_asic(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_hl_asic(int_t x);
  static double cost_pag_hl_asic(vector<set<T> > *pipeline_set);
  static double cost_add_vector_hl_asic(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max = 1);
  static double cost_reg_vector_hl_asic(vec_t x, int c_max = 1);

  static double cost_add_min_ad(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  static double cost_ternary_add_min_ad(int_t x, int_t u, int_t v, int_t w);
  static double cost_reg_min_ad(int_t x);
  static double cost_add_vector_min_ad(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max = 1);
  static double cost_reg_vector_min_ad(vec_t x, int c_max = 1);
  static double cost_pag_min_ad_hl_fpga(vector<set<T> > *pipeline_set);
  static double cost_pag_min_ad_ll_fpga(vector<set<T> > *pipeline_set);



  //function pointer to selected cost model:
  double (*cost_add)(int_t x, int_t u, int_t v, int no_of_predecessors_used);
  double (*cost_ternary_add)(int_t x, int_t u, int_t v, int_t w);
  double (*cost_reg)(int_t x);// als template?
  double (*cost_pag)(vector<set<T> > *pipeline_set);
  double (*cost_add_vec)(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max); //als template?
  double (*cost_reg_vec)(vec_t x, int c_max); //als template?


  int get_local_decision(int min_decision);

public:
    T _target;
  template<typename T2>
  void load_targate_set(T2 targate_set)
  {
    _target = targate_set;
  }

  virtual int adder_depth(T x);

  int_vec_t decision_vec;
  int_vec_t decision_max_vec;
  unsigned decision_cnt;

protected:
  void compute_topology_e_predecessors_2_add(T w1, T w2, int l_max, int nz_max, int ws_max, set<pair<T,T> > *predecessor_pair_set);

  inline void evaluate_usefull_predecessor_pair(T w1, T w2, set<pair<T,T> > *predecessor_pair_set, int nz_max, int_t l11, int_t l12, int_t l21, int_t l22, int_t r1, int_t r2, int_t s12, int_t s22)
  {
//    cout << "w1=" << w1 << ", w2=" << w2 << endl;
    T p1,p2;
//    cout << "s12=" << s12 << ", s22=" << s22 << ", l11=" << l11 << ", l12=" << l12 << ", l21=" << l21 << ", l22=" << l22 << ", r1=" << r1 << ", r2=" << r2 << endl;
    //den p1: 2^{l_{11}+l_{22}}\, - (-1)^{s_{22}} 2^{l_{12}+l_{21}
    int_t den = (1LL<<(l11+l22))-(s22<<(l12+l21));

    if(den != 0)
    {
      //num p1: w_1 2^{r_1+l_{22}}\, - (-1)^{s_{12}} (-1)^{s_{22}} w_2 2^{r_2+l_{21}}
      T num = (w1<<(r1+l22))-((s12*s22*w2)<<(r2+l21));

//      cout << "1 num=" << num << " den=" << den << endl;

      if(num % den == 0)
      {
        p1 = fundamental(norm(num / den));
//        cout << "p1=" << p1 << ", nonzeros(p1)=" << nonzeros(p1) << endl;
        if(nonzeros(p1) <= nz_max)
        {
          //den p2: 2^{l_{21}+l_{12}} - (-1)^{s_{22}}\, 2^{l_{22}+l_{11}}
          den = (1LL<<(l21+l12)) - (s22<<(l22+l11));
          if(den != 0)
          {
            //num p2: w_1 \, 2^{r_1+l_{12}} - (-1)^{s_{12}} \, w_2 \, 2^{r_2+l_{11}}
            num = (w1<<(r1+l12)) - ((s12*w2)<<(r2+l11));
//            cout << "2 num=" << num << " den=" << den << endl;
            if(num % den == 0)
            {
              p2 = fundamental(norm(num / den));
              if(nonzeros(p2) <= nz_max)
              {
                if(p1 > p2)
                {
                  //swap p1 and p2:
                  T tmp=p1; p1=p2; p2=tmp;
                }
                IF_VERBOSE(4) cout << "(p1,p2)=[" << p1 << "," << p2 << "]" << ", with s12=" << s12 << ", s22=" << s22 << ", l11=" << l11 << ", l12=" << l12 << ", l21=" << l21 << ", l22=" << l22 << ", r1=" << r1 << ", r2=" << r2 << endl;
                predecessor_pair_set->insert(pair<T,T >(p1,p2));
              }
            }
          }
        }
      }
    }
  }

private:
  //###################################################################
  virtual bool is_this_a_two_input_system(void)=0;

  virtual T get_best_single_predecessor(const set<T> &working_set, const set<T> &predecessor_set, int s)
  {
		UNUSED(working_set);
		UNUSED(predecessor_set);
		UNUSED(s);
		std::cout << "Error: Called from base class! This should never happen!\n";
    exit(-1);
  }

	virtual void get_best_multi_predecessor(const set<T> &working_set, set<T> *predecessor_set, int s)
  {
		UNUSED(working_set);
		UNUSED(predecessor_set);
		UNUSED(s);
		std::cout << "Error: Called from base class! This should never happen!\n";
		exit(-1);
  }

  int_t compute_c_max(int_t target_fun_max);

  int initialize(const set<T>* target_set, set<T>* target_fun_set);
  int create_constraints(int adder_depth_max, int target_wordsize_max);
  void check_constraints(int no_of_pipeline_stages);

};

template <class T>
std::string generate_matlab_line(T r, int stage_r, T r1, int stage_r1, int k_r1, bool sg_r1, T r2, int stage_r2, int k_r2, bool sg_r2)
{
  if(sg_r1){r1 *= -1;}
  if(sg_r2){r2 *= -1;}
  std::string out;
  out = "{[" + toString(r) + "]," + toString(stage_r) + ",[" + toString(r1) + "]," + toString(stage_r1) + "," + toString(k_r1) + ",[" + toString(r2) + "]," + toString(stage_r2) + "," + toString(k_r2) + "}";
  return out;
}

template <class T>
void create_adder_graph(vector< set<T> > pipeline_set, int_t c_max, int &count_register,int &count_adder, stringstream &pag)
{
  IF_VERBOSE(1) cout << "create adder-graph" << endl;
  typename set<T>::const_iterator set_iter, set_iter_2, set_iter_3;

  set<T> basis_set;
  for(unsigned int i=0; i < vec_t::default_elem_count; ++i)
  {
      T basis;
      basis = 0;// it is not possible to set the elemts bevor they are created.
      make_one_by(basis,i);
      basis_set.insert(basis);
  }
  pipeline_set.insert(pipeline_set.begin(),basis_set);

  pag << "{";
  for(unsigned int s = pipeline_set.size()-1; s > 0; --s)
  {
    for(set_iter = (pipeline_set)[s].begin(); set_iter != (pipeline_set)[s].end(); ++set_iter)
    {
      if(!((s == pipeline_set.size()-1) && (set_iter == (pipeline_set)[s].begin())))
                pag << ",";// work ever but not in step 1;

      int realization_found = false;

      //Topologie a Register
      //seach element in previous stage
      if((pipeline_set)[s-1].find(*set_iter) != (pipeline_set)[s-1].end())
      {
        IF_VERBOSE(3) cout << "Hit for topology a register for element " << *set_iter << endl;
        //element found -> count as register
        T r2;
        r2=0;
        pag << generate_matlab_line(*set_iter,s,*set_iter,s-1,0,0,r2,0,0,0);
        realization_found=true;
        count_register++;
        continue;
      }

      //Topologie b Adder with one element
      for(set_iter_2 = (pipeline_set)[s-1].begin(); set_iter_2 != (pipeline_set)[s-1].end(); ++set_iter_2)
      {
        int k_max;
        {
          vec_t r1(1),r2(1);
          r1 = *set_iter_2;
          r2 = *set_iter_2;
          k_max = log2c_64((int_t) max(ceil(((double)c_max+abs(r2).max())/((double)abs(r1).min(true))),ceil(((double)c_max+abs(r1).max())/((double)abs(r2).min(true)))));
        }

        T r;
        T r1= *set_iter_2;
        T r2= *set_iter_2;

        for(int k=1; k < k_max; k++)
        {
          r=(r1 << k) + r2;
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 1 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,k,0,r2,s-1,0,0);
            realization_found=true;
            count_adder++;
            break;
          }

          r = ((r1 << k) - r2);
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 2 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,k,0,r2,s-1,0,1);
            realization_found=true;
            count_adder++;
            break;
          }
          r = (r2 - (r1 << k));
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 3 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,k,0,r2,s-1,0,1);
            realization_found=true;
            count_adder++;
            break;
          }
        }
        if(realization_found) break;

        // without shift (k=0)
        {
          int right_shift=0;
          r = r1 + r2;
          right_shift = fundamental_count(r);
          r = fundamental(r);
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 4 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,-right_shift,0,r2,s-1,-right_shift,0);
            realization_found=true;
            count_adder++;
            break;
          }
          r = r1 - r2;
          r = (r);
          right_shift = fundamental_count(r);
          r = fundamental(r);
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 5 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,-right_shift,0,r2,s-1,-right_shift,-1);
            realization_found=true;
            count_adder++;
            break;
          }
          r = r2 - r1;
          r = (r);
          right_shift = fundamental_count(r);
          r = fundamental(r);
          if(r == *set_iter)
          {
            IF_VERBOSE(3) cout << "Hit for topology b (adder with one element), case 6 for element " << *set_iter << endl;
            pag << generate_matlab_line(r,s,r1,s-1,-right_shift,-1,r2,s-1,-right_shift,0);
            realization_found=true;
            count_adder++;
            break;
          }
        }
      }
      if(realization_found) continue;

      //Topologie c / d Adder with two elements
      for(set_iter_2 = (pipeline_set)[s-1].begin(); set_iter_2 != (pipeline_set)[s-1].end(); ++set_iter_2)
      {
        for(set_iter_3 = (pipeline_set)[s-1].begin(); set_iter_3 != set_iter_2; ++set_iter_3)
        {
          if(*set_iter_2 != *set_iter_3)
          {
            int k_max;
            {
              vec_t r1(1),r2(1);
              r1 = *set_iter_2;
              r2 = *set_iter_3;
              k_max = log2c_64((int_t) max(ceil(((double)c_max+abs(r2).max())/((double)abs(r1).min(true))),ceil(((double)c_max+abs(r1).max())/((double)abs(r2).min(true)))));
            }

            T r;
            T r1;
            T r2;
            r1 = (*set_iter_2);
            r2 = (*set_iter_3);

            for(int k=1; k < k_max; k++)
            {
              r = (r1 << k) + r2;
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 1 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,k,0,r2,s-1,0,0);
                realization_found=true;
                count_adder++;
                break;
              }

              r = r1 + (r2 << k);
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 2 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,0,0,r2,s-1,k,0);
                realization_found=true;
                count_adder++;
                break;
              }

              r = ((r1 << k) - r2);
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 3 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,k,0,r2,s-1,0,1);
                realization_found=true;
                count_adder++;
                break;
              }
              r = ((r2 << k) - r1);
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 4 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,0,1,r2,s-1,k,0);
                realization_found=true;
                count_adder++;
                break;
              }


              r = (r1 - (r2 << k));
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 5 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,0,0,r2,s-1,k,1);
                realization_found=true;
                count_adder++;
                break;
              }
              r = (r2 - (r1 << k));
              //r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 6 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,k,1,r2,s-1,0,0);
                realization_found=true;
                count_adder++;
                break;
              }
            }
            if(realization_found) break;

            // without shift (k=0)
            {
              int right_shift=0;
              r = r1 + r2;
              right_shift = fundamental_count(r);
              r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 7 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,-right_shift,0,r2,s-1,-right_shift,0);
                realization_found=true;
                count_adder++;
                break;
              }
              r = r1 - r2;
              r = (r);
              right_shift = fundamental_count(r);
              r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 8 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,-right_shift,0,r2,s-1,-right_shift,-1);
                realization_found=true;
                count_adder++;
                break;
              }
              r = r2 - r1;
              r = (r);
              right_shift = fundamental_count(r);
              r = fundamental(r);
              if(r == *set_iter)
              {
                IF_VERBOSE(3) cout << "Hit for topology  c / d (adder with two elements), case 9 for element " << *set_iter << endl;
                pag << generate_matlab_line(r,s,r1,s-1,-right_shift,-1,r2,s-1,-right_shift,0);
                realization_found=true;
                count_adder++;
                break;
              }
            }
          }
        }
        if(realization_found) break;
      }
      if(!realization_found){std::cout << "error pipeline rialization is invalid to realize element " << *set_iter << endl; exit(-1);}
    }
  }
  pag << "}";
}



template <class T>
rpag_basis<T>::rpag_basis()
{
  //default values:
  cost_model=HL_FPGA;
  exhaustive=false;
  max_no_of_mult=-1; //no limit of multipliers
  mult_wordsize=-1;  //no multipliers used
  stages_embedded_mult=-1; //no of pipeline stages used for multiplication
  msd_successor_evaluation=true;
//  extra_pipeline_stages=0;
  stages_input_pag=-1;
  stages_output_pag=-1;
  force_minimal_depth=false;
  input_wordsize=-1;
  no_of_extra_stages=0;
  benchmark =false;

  rand_variance=0.0;
  rand_seed=-1;
  no_of_runs=1;
  meta_greedy_search_depth=10;
  target_vec.clear();
  show_adder_graph= false;
  ternary_adders = false;

  msd_cutter_iteration_max = 3000;
  msd_iteration_max = -1;
}

template <class T>
rpag_basis<T>::~rpag_basis()
{}

/*** cost functions for high-level FPGA model ***/

#if 1
template <class T>
double rpag_basis<T>::cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  return no_of_predecessors_used;
}

#else

double rpag::cost_add_hl_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  if(no_of_predecessors_used == 1)
  {
//    return (double) log2c_64(nonzeros(x)); //(2)
//    return ((double) nonzeros(u))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)))/((double) log2c_64(nonzeros(x))); //(3b)
    return ((double) log2c_64(u))/((double) log2c_64(x)); //(3c)
  }
  else
  {
//    return (double) log2c_64(nonzeros(x)); //(2)
//    return ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)) + log2c_64(nonzeros(v)))/((double) log2c_64(nonzeros(x))); //(3b)
    return ((double) log2c_64(u) + log2c_64(v))/((double) log2c_64(x)); //(3c)
  }
}

#endif

template <class T>
double rpag_basis<T>::cost_ternary_add_hl_fpga(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return 1;
}

template <class T>
double rpag_basis<T>::cost_reg_hl_fpga(int_t x)
{
  UNUSED(x);
  return 1;
}

template <class T>
double rpag_basis<T>::cost_pag_hl_fpga(vector<set<T> > *pipeline_set)
{
  double pag_cost=0;
  for(unsigned s=0; s < pipeline_set->size(); s++)
  {
    pag_cost += ((double) (*pipeline_set)[s].size());
  }
  return pag_cost;
}

template <class T>
double rpag_basis<T>::cost_reg_vector_hl_fpga(vec_t x, int c_max)
{
  //cost function 4:
  return 1 + ((double) abs(x).max())/((double) c_max);
}

template <class T>
double rpag_basis<T>::cost_add_vector_hl_fpga(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max)
{
  UNUSED(x);
#if 0
  //cost function 0 (original cost function):
  UNUSED(c_max);
  if(no_of_predecessors_used > 1)
  {
    return no_of_predecessors_used + max(abs(u).max(),abs(v).max());
  }
  else
  {
    return (no_of_predecessors_used);
  }
  //cost function 1:
  if(no_of_predecessors_used > 1)
  {
      int unequal_elements=0;
      for(unsigned i=0; i < u.size(); i++)
      {
        unequal_elements += (u[i] != v[i]);
      }
      return no_of_predecessors_used*((double) unequal_elements)/((double) (2*u.size())) + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max);
  }
  else
  {
      return no_of_predecessors_used*((double) max(abs(u).max(),abs(v).max()))/((double) c_max);
  }
  //cost function 2:
  if(no_of_predecessors_used > 1)
  {
      int unequal_elements=0;
      for(unsigned i=0; i < u.size(); i++)
      {
        unequal_elements += (u[i] != v[i]);
      }
      return no_of_predecessors_used*((double) unequal_elements)/((double) (2*u.size()));
  }
  else
  {
      return no_of_predecessors_used;
  }
  //cost function 3:
  return no_of_predecessors_used + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max);
#endif
  //cost function 4:
  if(no_of_predecessors_used > 1)
  {
    return no_of_predecessors_used + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max);
  }
  else
  {
    return no_of_predecessors_used + ((double) abs(u).max())/((double) c_max);
  }
#if 0
  //cost function 5:
  if(no_of_predecessors_used > 1)
  {
    return no_of_predecessors_used + ((double) max(nonzeros(u),nonzeros(v)))/((double) log2c_64(c_max));
  }
  else
  {
    return no_of_predecessors_used + ((double) nonzeros(u))/((double) log2c_64(c_max));
  }
  //cost function 6:
  if(no_of_predecessors_used > 1)
  {
    int unequal_elements=0;
    for(unsigned i=0; i < u.size(); i++)
    {
      unequal_elements += (u[i] != v[i]);
    }
    return no_of_predecessors_used + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max) + ((double) unequal_elements)/((double) (2*u.size()));
  }
  else
  {
    return no_of_predecessors_used + ((double) abs(u).max())/((double) c_max);
  }
  //cost function 7:
    int nonzero_elements=0;
    for(unsigned i=0; i < u.size(); i++)
    {
      if(u[i] != 0) nonzero_elements++;
      if(no_of_predecessors_used > 1)
      {
        if(v[i] != 0) nonzero_elements++;
      }
    }
    return no_of_predecessors_used + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max) + ((double) nonzero_elements)/((double) (2*u.size()));
#endif
}

/*** cost functions for low-level FPGA model ***/

#if 0
template <class T>
double rpag_basis<T>::cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(u);
  UNUSED(v);
  return input_wordsize+log2c_64(x);
}
#else
//double factor = 1.0;

template <class T>
double rpag_basis<T>::cost_add_ll_fpga(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  assert(no_of_predecessors_used <= 2);

  if(no_of_predecessors_used == 0)
  {
    return 1; //(1)
//    return input_wordsize+log2c_64(x); //(2)
//    return 1; //(3a-d)
//    return 1.0; //(4)
  }
  else if(no_of_predecessors_used == 1)
  {
    return 1; //(1)
//    return input_wordsize+log2c_64(x); //(2)
//    return ((double) nonzeros(u))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)))/((double) log2c_64(nonzeros(x))); //(3b)
//    return ((double) log2c_64(u))/((double) log2c_64(x)); //(3c)
//    return ((double) input_wordsize+log2c_64(u))/((double) input_wordsize+log2c_64(x)); //(3c)
//    return 1.0/(1.0 + factor*(1.0 - ((double) nonzeros(u))/((double) nonzeros(x))) ); //(4a)
//    return 1.0/(1.0 + factor*(1.0 - ((double) input_wordsize+log2c_64(u))/((double) input_wordsize+log2c_64(x))) ); //(4b)
  }
  else
  {
//    cout << "no_of_predecessors_used=" << no_of_predecessors_used << endl;
    return 2; //(1)
//    return 2*input_wordsize+log2c_64(x); //(2)
//    return ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x)); //(3a)
//    return ((double) log2c_64(nonzeros(u)) + log2c_64(nonzeros(v)))/((double) log2c_64(nonzeros(x))); //(3b)
//    return ((double) log2c_64(u) + log2c_64(v))/((double) log2c_64(x)); //(3c)
//    return ((double) 2*input_wordsize + log2c_64(u) + log2c_64(v))/((double) input_wordsize + log2c_64(x)); //(3c)
//    return 1.0/(1.0 + factor*(1.0 - ((double) nonzeros(u)+nonzeros(v))/((double) nonzeros(x))) ); //(4a)
//    return 1.0/(1.0 + factor*(1.0 - ((double) 2*input_wordsize+log2c_64(u)+log2c_64(v))/((double) input_wordsize+log2c_64(x))) ); //(4b)
  }
}
#endif

template <class T>
double rpag_basis<T>::cost_ternary_add_ll_fpga(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return input_wordsize+log2c_64(x);
}

#if 0
template <class T>
double rpag_basis<T>::cost_reg_ll_fpga(int_t x)
{
  return input_wordsize+log2c_64(x);
}
#else
template <class T>
double rpag_basis<T>::cost_reg_ll_fpga(int_t x)
{
  return cost_add_ll_fpga(x,0,0,0);
}
#endif

template <class T>
double rpag_basis<T>::cost_pag_ll_fpga(vector<set<int_t> > *pipeline_set)
{
  set<int_t>::iterator set_iter;
  double cost=0.0;

  for(unsigned s=0; s < pipeline_set->size(); ++s)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      cost += ((double) input_wordsize+log2c_64((*set_iter)));
    }
  }
  return cost;
}

template <class T>
double rpag_basis<T>::cost_pag_ll_fpga(vector<set<vec_t> > *pipeline_set)
{
  set<vec_t>::iterator set_iter;
  double cost=0.0;

  for(unsigned s=0; s < pipeline_set->size(); ++s)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      cost += (double) compute_word_size(*set_iter, input_wordsize);
    }
  }
  return cost;
}

/*
template <class T>
double rpag_basis<T>::cost_add_vector_ll_fpga(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max)
{
  UNUSED(x);
  UNUSED(c_max);

	if(no_of_predecessors_used > 1)
  {
    return (no_of_predecessors_used + max(abs(u).max(),abs(v).max()));
  }
  else
  {
    return (no_of_predecessors_used);
  }
}

template <class T>
double rpag_basis<T>::cost_reg_vector_ll_fpga(vec_t x, int c_max)
{
  //cost function 4:
  return 1 + ((double) abs(x).max())/((double) c_max); //ToDo: Modify cost function to LL FPGA Model
}
*/

/*** cost functions for high-level ASIC model ***/


template <class T>
double rpag_basis<T>::cost_add_hl_asic(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  return 2*no_of_predecessors_used;
}

template <class T>
double rpag_basis<T>::cost_ternary_add_hl_asic(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return 4;
}

template <class T>
double rpag_basis<T>::cost_reg_hl_asic(int_t x)
{
  UNUSED(x);
  return 1;
}

template <class T>
double rpag_basis<T>::cost_pag_hl_asic(vector<set<T> > *pipeline_set)
{
  UNUSED(pipeline_set);
  cerr << "unsupported cost model!" << endl;
  return -1;
}

template <class T>
double rpag_basis<T>::cost_add_vector_hl_asic(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max)
{
	UNUSED(x);
  UNUSED(c_max);

  if(no_of_predecessors_used > 1)
  {
    return (no_of_predecessors_used + max(abs(u).max(),abs(v).max()));
  }
  else
  {
    return (no_of_predecessors_used);
  }
}

template <class T>
double rpag_basis<T>::cost_reg_vector_hl_asic(vec_t x, int c_max)
{
  //cost function 4:
  return 1 + ((double) abs(x).max())/((double) c_max); //ToDo: Modify cost function to HL ASIC Model
}


template <class T>
double rpag_basis<T>::cost_add_min_ad(int_t x, int_t u, int_t v, int no_of_predecessors_used)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  return no_of_predecessors_used;
}

template <class T>
double rpag_basis<T>::cost_ternary_add_min_ad(int_t x, int_t u, int_t v, int_t w)
{
  UNUSED(x);
  UNUSED(u);
  UNUSED(v);
  UNUSED(w);
  return 1;
}

template <class T>
double rpag_basis<T>::cost_reg_min_ad(int_t x)
{
	UNUSED(x);
	return 0;
}

template <class T>
double rpag_basis<T>::cost_pag_min_ad_hl_fpga(vector<set<T> > *pipeline_set)
{
  int no_of_adders=0;
  typename set<T>::iterator set_iter;

  for(unsigned int s = 0; s < pipeline_set->size(); ++s)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      if(s == 0)
      {
        if(nonzeros(*set_iter) != 1)
          no_of_adders++;
      }
      else
      {
        //seach element in previous stage
        if((*pipeline_set)[s-1].find(*set_iter) == (*pipeline_set)[s-1].end())
        {
          //element not found -> count as adder
          no_of_adders++;
        }
      }
    }
  }
  return no_of_adders;

  /*
  int no_of_adders=0,no_of_registers=0,no_of_registered_ops=0;
  typename set<T>::iterator set_iter;

  for(unsigned int s = 0; s < pipeline_set->size(); ++s)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      if(s == 0)
      {
        if(nonzeros(*set_iter) == 1)
          no_of_registers++;
        else
          no_of_adders++;
      }
      else
      {
        //seach element in previous stage
        if((*pipeline_set)[s-1].find(*set_iter) != (*pipeline_set)[s-1].end())
        {
          //element found -> count as register
          no_of_registers++;
        }
        else
        {
          no_of_adders++;
        }
      }
    }
    no_of_registered_ops += (*pipeline_set)[s].size();
  }
  return no_of_adders;
*/

}

template <class T>
double rpag_basis<T>::cost_pag_min_ad_ll_fpga(vector<set<T> > *pipeline_set)
{
  double cost=0.0;
  typename set<T>::iterator set_iter;
  for(unsigned int s = 0; s < pipeline_set->size(); ++s)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      if(s == 0)
      {
        if(nonzeros(*set_iter) != 1)
        {
          cost += (double) compute_word_size(*set_iter, input_wordsize);
        }
      }
      else
      {
        //seach element in previous stage
        if((*pipeline_set)[s-1].find(*set_iter) == (*pipeline_set)[s-1].end())
        {
          //element not found -> count as adder
          cost += (double) compute_word_size(*set_iter, input_wordsize);
        }
      }
    }
  }
  return cost;
}

template <class T>
double rpag_basis<T>::cost_add_vector_min_ad(vec_t x, vec_t u, vec_t v, int no_of_predecessors_used, int c_max)
{
#if 0
  //cost function 0 (original cost function):
  UNUSED(x);
  UNUSED(c_max);
  if(no_of_predecessors_used > 1)
  {
    return (no_of_predecessors_used + max(abs(u).max(),abs(v).max()));
  }
  else
  {
    return (no_of_predecessors_used);
  }
#endif
  //cost function 4:
  UNUSED(x);
  UNUSED(c_max);
  if(no_of_predecessors_used > 1)
  {
    return no_of_predecessors_used + ((double) max(abs(u).max(),abs(v).max()))/((double) c_max);
  }
  else
  {
    return no_of_predecessors_used + ((double) abs(u).max())/((double) c_max);
  }
}

template <class T>
double rpag_basis<T>::cost_reg_vector_min_ad(vec_t x, int c_max)
{
  UNUSED(x);
  UNUSED(c_max);
  return 0;
}

template <class T>
int_t rpag_basis<T>::compute_c_max(int_t target_fun_max)
{
  return 1LL << (log2c_64(target_fun_max)+1);
}


template <class T>
int rpag_basis<T>::adder_depth(T x)
{
  assert(is_this_a_two_input_system());
  return log2c_64(nonzeros(x));
}


template <class T>
int rpag_basis<T>::get_local_decision(int decision_max)
{
  int decision;

  if((meta_greedy_search_depth <= 0) && (rand_variance > 0) && (decision_max > 0))
  {
    //random selection heuristic is selected:
    double rnd=(double) rand()/RAND_MAX;
    decision = ((int) round(rnd*min(rand_variance,((double) decision_max))));
  }
  else
  {
    decision=0;
  }

  if(decision_cnt >= decision_vec.size())
  {
    //decision vector length is less than actual decision -> enlarge vector
    decision_vec.push_back(decision);
    decision_max_vec.push_back(decision_max);
  }
  else
  {
    //decision vector length is large enough, read from or write result (for debug) to this vector
    if(meta_greedy_search_depth > 0)
    {
      decision = decision_vec[decision_cnt];
      decision_max_vec[decision_cnt] = decision_max;
    }
    else
    {
      decision_vec[decision_cnt] = decision;
    }
  }
  decision_cnt++;

  if(decision > decision_max) decision = decision_max; //it may happen that the decision max value changes and is then less than the predicted value in the decision_vec -> limit to the max value

  return decision;
}

template <class T>
int rpag_basis<T>::initialize(const set<T>* target_set, set<T>* target_fun_set)
{
  typename set<T>::iterator set_iter;
  int ad,ad_max=0,no_of_pipeline_stages;

  srand(rand_seed); //set random seed

  if(adder_depth_constraints.size() != wordsize_constraints.size())
  {
    cerr << "Error: adder depth and word size constraints must be of equal length!" << endl;
    exit(1);
  }

  if((max_no_of_mult > 0) && (mult_wordsize < 0))
  {
    cerr << "Error: No multiplier word size is given.";
    exit(-1);

  }

  //select cost model:
  switch(cost_model)
  {
  case HL_FPGA:
    IF_VERBOSE(2) cout << "using hl_fpga cost model" << endl;
    cost_add = cost_add_hl_fpga;
    cost_ternary_add = cost_ternary_add_hl_fpga;
    cost_reg = cost_reg_hl_fpga;
    cost_pag = cost_pag_hl_fpga;
    cost_add_vec = cost_add_vector_hl_fpga;
    cost_reg_vec = cost_reg_vector_hl_fpga;
    break;
  case LL_FPGA:
    IF_VERBOSE(2) cout << "using ll_fpga cost model" << endl;
    if(input_wordsize < 0)
    {
      cerr << "Error: input word size necessary for ll_fpga cost model (parameter: --input_wordsize)" << endl;
      exit(-1);
    }
    cost_add = cost_add_ll_fpga;
    cost_ternary_add = cost_ternary_add_ll_fpga;
    cost_reg = cost_reg_ll_fpga;
    cost_pag = cost_pag_ll_fpga;
    cost_add_vec = cost_add_vector_hl_fpga; //uses the same cost function as HL FPGA!
    cost_reg_vec = cost_reg_vector_hl_fpga; //uses the same cost function as HL FPGA!
    break;
  case LL_ASIC:
    cerr << "Error: LL_ASIC cost model currently not supported!" << endl;
    exit(-1);
    break;
  case HL_ASIC:
    IF_VERBOSE(2) cout << "using hl_asic cost model" << endl;
    cost_add = cost_add_hl_asic;
    cost_ternary_add = cost_ternary_add_hl_asic;
    cost_reg = cost_reg_hl_asic;
    cost_pag = cost_pag_hl_asic;
    cost_add_vec = cost_add_vector_hl_asic;
    cost_reg_vec = cost_reg_vector_hl_asic;
    break;
  case MIN_AD_HL_FPGA:
    IF_VERBOSE(2) cout << "using ll fpga cost model for minimal adder depth" << endl;
    cost_add = cost_add_min_ad;
    cost_ternary_add = cost_ternary_add_min_ad;
    cost_reg = cost_reg_min_ad;
    cost_pag = cost_pag_min_ad_hl_fpga; //only the PAG cost are different for low level FPGA model
    cost_add_vec = cost_add_vector_min_ad;
    cost_reg_vec = cost_reg_vector_min_ad;
    break;
  case MIN_AD_LL_FPGA:
    IF_VERBOSE(2) cout << "using hl fpga cost model for minimal adder depth" << endl;
    if(input_wordsize < 0)
    {
      cerr << "Error: input word size necessary for min_ad_ll_fpga cost model (parameter: --input_wordsize)" << endl;
      exit(-1);
    }
    cost_add = cost_add_min_ad;
    cost_ternary_add = cost_ternary_add_min_ad;
    cost_reg = cost_reg_min_ad;
    cost_pag = cost_pag_min_ad_ll_fpga;  //only the PAG cost are different for low level FPGA model
    cost_add_vec = cost_add_vector_min_ad;
    cost_reg_vec = cost_reg_vector_min_ad;
    break;
  }

  if(max_no_of_mult == 0)
    mult_wordsize=-1;

  //compute fundamentals and adder depths:
  T fun;
  for(set_iter = target_set->begin(); set_iter != target_set->end(); ++set_iter)
  {
    fun = fundamental(norm(*set_iter));
    if(fun != 0)
      target_fun_set->insert(fun);
  }
  IF_VERBOSE(2) cout << "target fundamentals=" << *target_fun_set << endl;

  int_t target_fun_max=0;
  for(set_iter = target_fun_set->begin(); set_iter != target_fun_set->end(); ++set_iter)
  {
    ad = adder_depth(*set_iter);
    IF_VERBOSE(5) cout << "adder_depth(" << *set_iter << ")=" << ad << endl;
    if(ad > ad_max)
      ad_max = ad;

    if(max_elem(*set_iter) > target_fun_max)
      target_fun_max = max_elem(*set_iter);
  }

  c_max = this->compute_c_max(target_fun_max);

  IF_VERBOSE(2) cout << "c_max=" << c_max << endl;

  int target_wordsize_max = log2c_64(target_fun_max);

  IF_VERBOSE(2) cout << "max target value is " << target_fun_max << ", max target word size is " << target_wordsize_max << " bit" << endl;

  if((adder_depth_constraints.size() == 0) && (wordsize_constraints.size() == 0))
  {
    IF_VERBOSE(3) cout << "Determining adder depth and word size constraints" << endl;
    create_constraints(ad_max + no_of_extra_stages,target_wordsize_max);
    no_of_pipeline_stages=stages_output_pag+stages_input_pag;
  }
  else
  {
    if(mult_wordsize > 0)
    {
      stages_input_pag = log2c_64(mult_wordsize+1)-1;
      no_of_pipeline_stages = adder_depth_constraints.size();
      stages_output_pag = no_of_pipeline_stages - stages_input_pag + no_of_extra_stages;
    }
    else
    {
      stages_input_pag = adder_depth_constraints.size() + no_of_extra_stages;
      no_of_pipeline_stages = stages_input_pag;
      stages_output_pag = 0;
    }
  }


  IF_VERBOSE(2) cout << "optimization plan:" << endl;
  for(int s=0; s < no_of_pipeline_stages; s++)
  {
    IF_VERBOSE(2) cout << "stage " << s+1 << ", wordsize constraint=" << wordsize_constraints[s] << ", adder depth constraint=" << adder_depth_constraints[s] << endl;
  }
  return no_of_pipeline_stages;
}

template <class T>
int rpag_basis<T>::optimize()
{
  set<T> *target_set= new set<T>;
  {
    vector<char*>::iterator it;
    for(it = target_vec.begin(); it != target_vec.end();++it)
    {
      T to=0;
      target_set->insert(my_atoll(to,(*it)));
    }

  //chek for valid input:
  //all inputs have to have the same size
    unsigned int size=0;
    it = target_vec.begin();
    vec_t test;
    test = my_atoll(test,(*it));
    size= test.size();

    for(; it != target_vec.end();++it)
    {
      test = my_atoll(test,(*it));
      if(test.size() != size)
      {
        std::cout << "ERROR: \t This is not a valid Paramet set! " << std::endl;
        std::cout << "\t All elements must have the same size!" << std::endl;
        std::cout << "\t For Example:{ 5+0 -7+3 0-3 } or { 5 7 99 }" << std::endl;
        exit(-1);
      }
    }
  }

  set<T> target_fun_set;
  int no_of_pipeline_stages = initialize(target_set,&target_fun_set);

	if(no_of_pipeline_stages == 0)
	{
//    IF_VERBOSE(0) cout << "best result: pag cost=0, pipeline_set_best={" << target_fun_set << "}" << endl;
    IF_VERBOSE(0) cout << "results:" << endl;
    IF_VERBOSE(0) cout << "pipeline_set_best={" << target_fun_set << "}" << endl;
    IF_VERBOSE(0) cout << "pag cost=0" << endl;
    IF_VERBOSE(0) cout << "pure adders=0" << endl;
    exit(0);
	}
  unsigned act_decision_no=0,act_decision_value=0;
  unsigned act_decision_value_best=0;

  check_constraints(no_of_pipeline_stages);

  //  validate_parameters();
  IF_VERBOSE(2) cout << "No of pipeline stages: " << no_of_pipeline_stages << endl;

  double rand_variance = this->rand_variance;

  vector< set<T> > pipeline_set(no_of_pipeline_stages);
  vector< set<T> > pipeline_set_best(no_of_pipeline_stages);
  double pag_cost,pag_cost_best=10E10;

  for(int i=0; (i < no_of_runs) || (meta_greedy_search_depth > 0); i++)
  {
    //if several runs are done, the first one should be without random variance
    if((no_of_runs > 1) && (i==0))
    {
      this->rand_variance = 0.0;
    }
    else
    {
      this->rand_variance = rand_variance;
    }

    optimize_single_run(&target_fun_set,&pipeline_set);

    //check total cost of result:
    pag_cost = cost_pag(&pipeline_set);
    if(pag_cost < pag_cost_best)
    {
      pag_cost_best = pag_cost;
      pipeline_set_best = pipeline_set;
      act_decision_value_best = act_decision_value;
    }


    IF_VERBOSE(1) cout << "iteration " << i << ": decision_vec=(" << decision_vec << "), pag cost=" << pag_cost << ", pipeline_set=" << pipeline_set << endl;
//    IF_VERBOSE(1) cout << "iteration " << i << ": decision_max_vec=(" << decision_max_vec << ")" << " decision_cnt=" << decision_cnt << endl;

    //adjust decision vector:
		if(meta_greedy_search_depth > 0)
    {
			if(decision_vec.size() == 0) break; //trivial case, exit optimization loop
      if(decision_cnt < decision_vec.size())
      {
        decision_vec.resize(decision_cnt);
        decision_max_vec.resize(decision_cnt);
        if(act_decision_no >= decision_cnt) break; //decision vector was resized in one of the last iteration -> exit optimization loop
      }
      if((((int) act_decision_value) < meta_greedy_search_depth) && (act_decision_value < decision_max_vec[act_decision_no]))
      {
        act_decision_value++;
      }
      else
      {
        if(act_decision_no < decision_cnt-1)
        {
          decision_vec[act_decision_no] = act_decision_value_best;
          act_decision_value_best=0;

          do
          {
            act_decision_no++; //select next decision element, if this has a max decision value of zero, increment again
          } while((act_decision_no < decision_cnt-1) && (decision_max_vec[act_decision_no]==0));
          act_decision_value=1;
        }
        else
        {
          break; //exit optimization loop
        }
      }
      decision_vec[act_decision_no] = act_decision_value;
    }
//    IF_VERBOSE(1) cout << "iteration " << i << ": new decision_vec=(" << decision_vec << ") " << ", act_decision_no=" << act_decision_no << endl;

  }

  if(benchmark)
  {
    int no_of_adders=0,no_of_registers=0,no_of_registered_ops=0;
    typename set<T>::iterator set_iter;
    for(unsigned int s = 0; s < pipeline_set_best.size(); ++s)
    {
      for(set_iter = pipeline_set_best[s].begin(); set_iter != pipeline_set_best[s].end(); ++set_iter)
      {
        if(s == 0)
        {
          if(nonzeros(*set_iter) == 1)
            no_of_registers++;
          else
            no_of_adders++;
        }
        else
        {
          //seach element in previous stage
          if(pipeline_set_best[s-1].find(*set_iter) != pipeline_set_best[s-1].end())
          {
            //element found -> count as register
            no_of_registers++;
          }
          else
          {
            no_of_adders++;
          }
        }
      }
      no_of_registered_ops += pipeline_set_best[s].size();
    }
    cout << "no_of_pipeline_stages=\t" << pipeline_set_best.size() << std::endl;
    cout << "no_of_registered_ops=\t" << no_of_registered_ops << std::endl;
    cout << "no_of_registers=\t" << no_of_registers << std::endl;
    cout << "no_of_adders=\t\t" << no_of_adders << std::endl;
    cout << "pag_cost=\t\t" << pag_cost_best << std::endl;
  }
  if(show_adder_graph)
  {
    if(ternary_adders)
    {
      cout <<" Sorry: show_adder_graph is not implemented for ternary adders yet."<< std::endl;
    }
    else
    {
      int no_of_adders=0,no_of_registers=0,no_of_registered_ops=0;

      stringstream pag;
      create_adder_graph(pipeline_set_best, c_max,no_of_registers,no_of_adders,pag);
//      IF_VERBOSE(0) cout << "best result: pag cost=" << pag_cost_best << ", adders=" << no_of_adders << " pipeline_set_best=" << pipeline_set_best << ", pipelined adder graph=" << pag.str() << endl;
      IF_VERBOSE(0) cout << "results:" << endl;
      IF_VERBOSE(0) cout << "pipeline_set_best=" << pipeline_set_best << endl;
      IF_VERBOSE(0) cout << "pipelined adder graph=" << pag.str() << endl;
      IF_VERBOSE(0) cout << "pag cost=" << pag_cost_best << endl;
      IF_VERBOSE(0) cout << "pure adders=" << no_of_adders << endl;

      no_of_registered_ops = no_of_adders+no_of_registers;
      IF_VERBOSE(1) cout << endl << pag.str() << endl << endl;
      IF_VERBOSE(1) cout << "no_of_pipeline_stages=" << pipeline_set_best.size() << std::endl;
      IF_VERBOSE(1) cout << "no_of_registered_ops=" << no_of_registered_ops << std::endl;
      IF_VERBOSE(1) cout << "no_of_registers=" << no_of_registers << std::endl;
      IF_VERBOSE(1) cout << "no_of_adders=" << no_of_adders << std::endl;
      IF_VERBOSE(1) cout << "pag_cost=" << pag_cost_best << std::endl;

    }
  }
  else
  {
    IF_VERBOSE(0) cout << "best result: pag_cost=" << pag_cost_best << ", pipeline_set_best=" << pipeline_set_best << endl;
  }
  return 1;
}

template <class T>
int rpag_basis<T>::optimize_single_run(const set<T> *target_fun_set, vector< set<T> > *pipeline_set)
{
  //Variables, sets and maps needed during optimization
  set<T> embedded_mult_set;
  set<T> working_set;
  set<T> predecessor_set;
  embedded_mult_set.clear();
  working_set.clear();
  predecessor_set.clear();

  T best_single_predecessor;
  set<T> successor_set;
  set<T> realized_target_set;

  int no_of_stages_skipped=0;

  typename set<T>::iterator set_iter;
  int s=0;

  decision_cnt = 0; //reset decision counter

  int no_of_pipeline_stages = pipeline_set->size();

#ifdef EMBEDDED_MULT_FIX_ME
  if((stages_embedded_mult < 0) && (mult_wordsize > 0))
  {
    stages_embedded_mult = stages_input_pag;
    IF_VERBOSE(2) cout << "Embedded multiplier pipeline stages: " << stages_embedded_mult << endl;
  }

  if(no_of_pipeline_stages == 0)
  {
    //all elements can be realized using embedded multipliers
    embedded_mult_set = *target_fun_set;
    goto finito;
  }
#endif
  //the pipelineset has to be cleard from a preview optimazation
  for(int i=0; i<no_of_pipeline_stages; ++i)
  {
    (*pipeline_set)[i].clear();
  }

  if((cost_model == MIN_AD_HL_FPGA) || (cost_model == MIN_AD_LL_FPGA))
  {
    int min_adder_depth=0;
    for(set_iter = target_fun_set->begin(); set_iter != target_fun_set->end(); ++set_iter)
    {
      min_adder_depth = adder_depth(*set_iter);
      if(min_adder_depth > 0)
      {
        (*pipeline_set)[min_adder_depth-1].insert(*set_iter);
      }
    }
  }
  else
  {
    (*pipeline_set)[no_of_pipeline_stages-1] = *target_fun_set;
  }

  IF_VERBOSE(2) cout << "initial pipeline_set=" << *pipeline_set << endl;

  //############################################################################################################//
  //######################################      main optimization loop   #######################################//
  //############################################################################################################//
  for(s=no_of_pipeline_stages-1; s > 0; s--)
  {
    IF_VERBOSE(3) cout << "****** realizing elements in pipeline stage " << s << " ******" << endl;

		predecessor_set = (*pipeline_set)[s-1];
    working_set = (*pipeline_set)[s];

		IF_VERBOSE(4) cout << "predecessor_set=" << predecessor_set << endl;
		IF_VERBOSE(4) cout << "working_set=" << working_set << endl;

		//if there are target coefficients which should be realized in a lower pipeline stage than the output stage (which currently can not be configured),
    //remove corresponding elements from working set
    if(!predecessor_set.empty())
    {
      successor_set.clear();
      realized_target_set.clear();
      compute_successor_set(&predecessor_set, c_max, &successor_set, false, is_this_a_two_input_system());
      set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

      if(!realized_target_set.empty())
      {
        IF_VERBOSE(3) cout << "**coefficient(s) " << realized_target_set << " can be already be realized using p=" << predecessor_set << endl;

        for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          working_set.erase(*set_iter);
      }
    }


#ifdef EMBEDDED_MULT_FIX_ME
    if(s == stages_embedded_mult-1)
    {
      //remove elements from working set that are realized by embedded multipliers
      for(set_iter = embedded_mult_set.begin(); set_iter != embedded_mult_set.end(); ++set_iter)
        working_set.erase(*set_iter);
    }
    IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
    IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;

    //############################################################################################################//
    //#######################     include embedded multipliers for hybrid PMCM   #################################//
    //############################################################################################################//
    if(s == stages_embedded_mult-1)
    {
      IF_VERBOSE(3) cout << "realizing coefficients with embedded multipliers..." << endl;

      //coefficients can be realized using embedded multipliers in this stage:
      if((max_no_of_mult < 0) || (working_set.size() <= (unsigned) max_no_of_mult))
      {
        IF_VERBOSE(2) cout << "all coefficients at this stage can be realized using multipliers -> terminate" << endl;
        embedded_mult_set = working_set;
        no_of_stages_skipped = s;
        break;
      }
      else
      {
        //chose coefficients that are realized using embedded multipliers:
        int_double_map_t working_set_depth_map;
        for(set_iter = working_set.begin(); set_iter != working_set.end(); ++set_iter)
        {
          working_set_depth_map[*set_iter] = log(nonzeros(*set_iter))/log(2);
        }
        IF_VERBOSE(3) cout << "working_set_depth_map=" << working_set_depth_map << endl;

        int_double_map_t::iterator max_ad_gain_map_iter;
        while(embedded_mult_set.size() < (unsigned) max_no_of_mult)
        {
          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp_both());
//          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp());

          IF_VERBOSE(4) cout << "max. adder depth: " << (*max_ad_gain_map_iter).first << "," << (*max_ad_gain_map_iter).second << endl;

          embedded_mult_set.insert((*max_ad_gain_map_iter).first);
          working_set.erase((*max_ad_gain_map_iter).first);
          //set depth to -1 that embedded multiplier elements are ignored for remaining adder depth:
          working_set_depth_map[(*max_ad_gain_map_iter).first] = -1;
        }

        if(force_minimal_depth)
        {
          max_ad_gain_map_iter = max_element(working_set_depth_map.begin(), working_set_depth_map.end(), int_double_map_cmp());
          IF_VERBOSE(3) cout << "remaining adder depth for element " << (*max_ad_gain_map_iter).first << ": " << ceil((*max_ad_gain_map_iter).second) << endl;
          no_of_stages_skipped = adder_depth_constraints[s]-ceil((*max_ad_gain_map_iter).second);
          IF_VERBOSE(3) cout << "skipping " << no_of_stages_skipped << " stage(s)" << endl;

          if(no_of_stages_skipped > 0)
          {
            for(int i=0; i < no_of_pipeline_stages; i++)
            {
              if(i+no_of_stages_skipped < no_of_pipeline_stages)
              {
                (*pipeline_set)[i] = (*pipeline_set)[i+no_of_stages_skipped];
              }
              else
              {
                pipeline_set->pop_back();
              }
            }
            IF_VERBOSE(3) cout << "reduced pipeline_set=" << (*pipeline_set) << endl;
            s -= no_of_stages_skipped;
            stages_embedded_mult -= no_of_stages_skipped;
            IF_VERBOSE(3) cout << "****** pipeline stages reduced to " << s << " ******" << endl;
            if(s == 0)
            {
              IF_VERBOSE(3) cout << "remaining elements can be realized from input '1' -> terminating" << endl;
              no_of_stages_skipped = no_of_pipeline_stages;
              goto finito;
            }
          }
        }
      }
      IF_VERBOSE(3) cout << "coefficients realized with embedded multipliers: " << embedded_mult_set << endl;

      if(s+no_of_stages_skipped == no_of_pipeline_stages)
      {
        IF_VERBOSE(3) cout << "embedded multipliers at last stage realized -> continue with next lower stage" << endl;
        continue; //embedded multipliers at last stage realized -> continue with next previous stage
      }

      IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
      IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;
    }
#endif

    //############################################################################################################//
    //######################################     single stage optimization loop    ###############################//
    //############################################################################################################//
    while(!working_set.empty())
    {
      //searching for best predecessors
      best_single_predecessor = get_best_single_predecessor(working_set, predecessor_set, s);

      if(exhaustive)
      {
        cerr << "error: exhaustive mode currently unsupported!" << endl;
        exit(-1);
      }
      else
      {
        if((best_single_predecessor != -1)&&(best_single_predecessor != 0))
        {
          predecessor_set.insert(best_single_predecessor);
        }
        else
        {
          IF_VERBOSE(3) cout << "no single predecessor found, searching for multiple predecessors" << endl;

          get_best_multi_predecessor(working_set, &predecessor_set, s);

        }

        successor_set.clear();
        compute_successor_set(&predecessor_set, c_max, &successor_set, false,is_this_a_two_input_system());
        IF_VERBOSE(8)
        {
          std::cout << "predecessor_set = " << predecessor_set << std::endl;
          std::cout << "successor_set = " << successor_set << std::endl;
          std::cout << "working_set = " << working_set << std::endl;
        }
        realized_target_set.clear();
        set_intersection(successor_set.begin(), successor_set.end(), working_set.begin(), working_set.end(), inserter(realized_target_set, realized_target_set.begin()));

        IF_VERBOSE(3) cout << "coefficient(s) " << realized_target_set << " can be realized using p=" << predecessor_set << endl;

        for(set_iter = realized_target_set.begin(); set_iter != realized_target_set.end(); ++set_iter)
          working_set.erase(*set_iter);

        IF_VERBOSE(3) cout << "working_set=" << working_set << endl;
        IF_VERBOSE(3) cout << "predecessor_set=" << predecessor_set << endl;
      }
    }

    (*pipeline_set)[s-1].insert(predecessor_set.begin(),predecessor_set.end());
//    predecessor_set.clear();

  }

#ifdef EMBEDDED_MULT_FIX_ME
	finito:
#endif //EMBEDDED_MULT_FIX_ME

#ifdef EMBEDDED_MULT_FIX_ME
  //elliminate multiplier nodes from realization:
  if(stages_embedded_mult > 0)
  {
    IF_VERBOSE(2) cout << "pipeline_set=" << (*pipeline_set) << endl;
    for(set_iter = embedded_mult_set.begin(); set_iter != embedded_mult_set.end(); ++set_iter)
    {
      (*pipeline_set)[stages_embedded_mult-1].erase(*set_iter);
    }
    IF_VERBOSE(2) cout << "reduced pipeline_set=" << (*pipeline_set) << endl;
  }

  if(!embedded_mult_set.empty())
  {
    IF_VERBOSE(2) cout << "coefficients realized by embedded multiplers: [" << embedded_mult_set << "]" << endl;
  }
#endif
  //count no of adders and registers:
  int no_of_adders=0,no_of_registers=0,no_of_registered_ops=0;
  for(unsigned int s=0; s < pipeline_set->size(); s++)
  {
    for(set_iter = (*pipeline_set)[s].begin(); set_iter != (*pipeline_set)[s].end(); ++set_iter)
    {
      if(s == 0)
      {
        if(nonzeros(*set_iter)==1)
          no_of_registers++;
        else
          no_of_adders++;
      }
      else
      {
        bool element_is_mult=false;
        //is the element realized by a multiplier?
        if(s == (unsigned) stages_embedded_mult-1)
        {
          if(embedded_mult_set.find(*set_iter) != embedded_mult_set.end())
          {
            element_is_mult=true;
          }
        }
        //ignore multiplies for counting adders and registers
        if(!element_is_mult)
        {
          //seach element in previous stage
          if((*pipeline_set)[s-1].find(*set_iter) != (*pipeline_set)[s-1].end())
          {
            //element found -> count as register
            no_of_registers++;
          }
          else
          {
            no_of_adders++;
          }
        }
      }

    }
    no_of_registered_ops += (*pipeline_set)[s].size();
  }

  IF_VERBOSE(2) cout << "no of adders=" << no_of_adders << endl;
  IF_VERBOSE(2) cout << "no of registers=" << no_of_registers << endl;
  IF_VERBOSE(2) cout << "no of registered operations=" << no_of_registers + no_of_adders << endl;
  IF_VERBOSE(2) cout << "no of embedded multipliers= " << embedded_mult_set.size() << endl;
  IF_VERBOSE(2) cout << "effective adder depth / min. pipeline depth of multipliers=" << no_of_pipeline_stages-no_of_stages_skipped << endl;

  //cout << " adders & registers & add+reg & mults & stages & time\\" << endl;
  //cout << " " << no_of_adders << " & " << no_of_registers << " & " << no_of_registers + no_of_adders << " & " << embedded_mult_set.size() << " & " << no_of_pipeline_stages-no_of_stages_skipped << "\\" << endl;
  IF_VERBOSE(2) cout << "pipeline_set=" << (*pipeline_set) << endl;

  return 1;
}

template <class T>
int rpag_basis<T>::create_constraints(int adder_depth_max, int target_wordsize_max)
{
  if(stages_input_pag < 0)
  {
    IF_VERBOSE(3) cout << "No stages for input PAG are given, determining the minimal necessary number of stages" << endl;

    if(mult_wordsize > 0)
    {
      //multipliers are used, the input PAG stages are determined using half the multiplier wordsize
//      stages_input_pag = log2c_64(ceil(mult_wordsize/2.0));
      stages_input_pag = log2c_64(mult_wordsize+1)-1;
    }
    else
    {
      //no multipliers are used, the input PAG stages are determined from the maximum adder depth of the target coefficients:
      stages_input_pag = adder_depth_max;
    }
  }
  IF_VERBOSE(3) cout << "Input PAG stages: " << stages_input_pag << endl;

  if(stages_output_pag < 0)
  {
    IF_VERBOSE(3) cout << "No stages for output PAG are given, determining the minimal necessary number of stages" << endl;

    if((mult_wordsize > 0) && (target_wordsize_max > mult_wordsize))
    {
      //if wordsize is halfed in each stage, ceil(log2(target_wordsize_max/mult_wordsize))+1 stages are necessary:
      stages_output_pag = ((int) ceil(log2(((double) target_wordsize_max)/mult_wordsize)));
    }
    else
    {
      //no mutliplier is used, so no output PAG is necessary:
      stages_output_pag = 0;
    }
  }
  IF_VERBOSE(3) cout << "Output PAG stages: " << stages_output_pag << endl;

  //determine the optimization plan
  if(mult_wordsize == -1)
  {
    //no multipliers are used, simply constrain the adder depth
    for(int s=0; s < stages_input_pag; s++)
    {
      wordsize_constraints.push_back(-1);
      adder_depth_constraints.push_back(s+1);
    }
  }
  else
  {
    //multipliers are used, constrain the adder depth of the input PAG and the word length of the output PAG:
    for(int s=0; s < stages_input_pag-1; s++)
    {
      wordsize_constraints.push_back(-1);
      adder_depth_constraints.push_back(s+1);
    }
    wordsize_constraints.push_back(mult_wordsize);
    adder_depth_constraints.push_back(-1);
    for(int s=0; s < stages_output_pag-1; s++)
    {
      adder_depth_constraints.push_back(-1);
      wordsize_constraints.push_back((s+2)*mult_wordsize); //!!!!
    }
    wordsize_constraints.push_back(target_wordsize_max);
    adder_depth_constraints.push_back(-1);
  }



  return 1;
}

template <class T>
void rpag_basis<T>::check_constraints(int no_of_pipeline_stages)
{
  for(int s=0; s < no_of_pipeline_stages-1; s++)
  {
    IF_VERBOSE(4) cout << "checking constraints in stage " << s << endl;
    if((adder_depth_constraints[s] > 0) && (adder_depth_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << adder_depth_constraints[s+1] << "<=" << adder_depth_constraints[s]+1 << endl;
      if(adder_depth_constraints[s+1] > adder_depth_constraints[s]+1)
      {
        cout << "Warning: constraints inconsistent, adder depth difference is greater than one from stage " << s << " to stage " << s+1 << endl;
      }
    }
    if((wordsize_constraints[s] > 0) && (wordsize_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << wordsize_constraints[s+1] << "<=" << (wordsize_constraints[s]<<1) << endl;

      if(is_this_a_two_input_system())
      {
        if(wordsize_constraints[s+1] > (wordsize_constraints[s]<<1))
        {
          cout << "Warning: constraints inconsistent, word size is more than doubled from stage " << s << " to stage " << s+1 << endl;
        }
      }
      else
      {
        if(wordsize_constraints[s+1] > 3*(wordsize_constraints[s]))
        {
          cout << "Warning: constraints inconsistent, word size is more than a factor of three from stage " << s << " to stage " << s+1 << endl;
        }
      }
    }
    if((adder_depth_constraints[s] > 0) && (wordsize_constraints[s+1] > 0))
    {
      IF_VERBOSE(4) cout << "checking " << (log2c_64(wordsize_constraints[s+1]+1)-1) << "<=" << adder_depth_constraints[s]+1 << endl;
      if((log2c_64(wordsize_constraints[s+1]+1)-1) > adder_depth_constraints[s]+1)
      {
        cout << "Warning: there is no guarantee that a word size of " << wordsize_constraints[s+1] << " in stage " << s+1 << " can be reached with an adder depth of " << adder_depth_constraints[s] << " in stage " << s << endl;
      }
    }
  }
}


template <class T>
void rpag_basis<T>::compute_topology_e_predecessors_2_add(T w1, T w2, int l_max, int nz_max, int ws_max, set<pair<T,T> > *predecessor_pair_set)
{
  int l11, l12, l21, l22, r1, r2, s12, s22;


  UNUSED(ws_max); //ToDo: Implement & test filter for word size constraint

  IF_VERBOSE(4) cout << "l_max=" << l_max << endl;

  //case i:
  IF_VERBOSE(5) cout << "evaluating topology (e) case i" << endl;
  l21=0; l22=0; r1=0; r2=0;
  for(s12=1; s12 >= -1; s12-=2)
  {
    for(s22=1; s22 >= -1; s22-=2)
    {
      for(l11=1; l11 < l_max; l11++)
      {
        for(l12=1; l12 < l_max; l12++)
        {
          evaluate_usefull_predecessor_pair(w1,w2,predecessor_pair_set,nz_max,l11,l12,l21,l22,r1,r2,s12,s22);
        }
      }
    }
  }

  //case ii:
  IF_VERBOSE(5) cout << "evaluating topology (e) case ii" << endl;
  l21=0; l12=0; r1=0; r2=0;
  for(s12=1; s12 >= -1; s12-=2)
  {
    for(s22=1; s22 >= -1; s22-=2)
    {
      for(l11=1; l11 < l_max; l11++)
      {
        for(l22=1; l22 < l_max; l22++)
        {
          evaluate_usefull_predecessor_pair(w1,w2,predecessor_pair_set,nz_max,l11,l12,l21,l22,r1,r2,s12,s22);
        }
      }
    }
  }

  //case iii:
  IF_VERBOSE(5) cout << "evaluating topology (e) case iii" << endl;
  l21=0; l12=0; l22=0; r1=0;
  for(s12=1; s12 >= -1; s12-=2)
  {
    for(s22=1; s22 >= -1; s22-=2)
    {
      for(l11=1; l11 < l_max; l11++)
      {
        for(r2=1; r2 < l_max; r2++)
        {
          evaluate_usefull_predecessor_pair(w1,w2,predecessor_pair_set,nz_max,l11,l12,l21,l22,r1,r2,s12,s22);
        }
      }
    }
  }

  //case iv:
  IF_VERBOSE(5) cout << "evaluating topology (e) case iv" << endl;
  l11=0; l21=0; l12=0; l22=0;
  for(s12=1; s12 >= -1; s12-=2)
  {
    for(s22=1; s22 >= -1; s22-=2)
    {
      for(r1=1; r1 < l_max; r1++)
      {
        for(r2=1; r2 < l_max; r2++)
        {
          evaluate_usefull_predecessor_pair(w1,w2,predecessor_pair_set,nz_max,l11,l12,l21,l22,r1,r2,s12,s22);
        }
      }
    }
  }
}



#endif // RPAG_BASIS_H

