#ifndef RPAG_POINTER_H
#define RPAG_POINTER_H

typedef enum {LL_FPGA,HL_FPGA,LL_ASIC,HL_ASIC,MIN_AD_HL_FPGA,MIN_AD_LL_FPGA} cost_model_t;

class rpag_pointer
{
public:
  rpag_pointer(){}
  virtual ~rpag_pointer(){}
  virtual int
  optimize()=0;

  vector<char*> target_vec;

  //user specified parameters:
  cost_model_t cost_model;
  bool exhaustive;
  double rand_variance;
  int rand_seed;
  int no_of_runs; //number of runs (with random variance)
  static int input_wordsize;
  int mult_wordsize;
  int max_no_of_mult;
  int stages_embedded_mult;
  int no_of_extra_stages;
  bool force_minimal_depth;
  int meta_greedy_search_depth;
  bool benchmark;
  bool show_adder_graph;
  bool ternary_adders;
  long msd_cutter_iteration_max;
  long msd_iteration_max;

  vector<int> wordsize_constraints;
  vector<int> adder_depth_constraints;

  bool msd_successor_evaluation; //determines, if predecessors are computed from all MSDs for gain calculation (more precise but more time consuming)
};

#endif // RPAG_POINTER_H
