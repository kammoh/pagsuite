#include "rpag_basis.h"


int_t max_elem(const vec_t &rhs)
{
    return abs(rhs).max();
}

int_t max_elem(const int_t &rhs)
{
  return rhs;
}

vec_t my_atoll(vec_t to, char* input)
{
	UNUSED(to);
	char const* cut = "+-";

  int pos=0;
  vec_t output(0);
  std::string in = input;

  while(pos != -1)
  {
    pos = in.find_first_of(cut,1);
    output.push_back(atoll(in.substr(0,pos).c_str()));
    in.erase(0,pos);
  }

  vec_t::default_elem_count=output.size();
  return norm(output);
}

int_t my_atoll(int_t to, char* input)
{
	UNUSED(to);
	return atoll(input);
}

void make_one_by(vec_t &var, unsigned int i)
{
  var[i] = 1;
}
void make_one_by(int_t &var, unsigned int i)
{
	UNUSED(i);
  var = 1;
}
