#include "norm.h"

#include <algorithm>

int_t norm(int_t in)
{
	return abs(in);
}

vec_t norm(vec_t in) // the first element witch is different  to zero have to be positiv!
{
	vec_t out = in;
	vec_t::iterator it;
	for(it = in.begin(); it != in.end(); ++it)
	{
		if(*it != 0)
		{
			if(*it < 0)
			{
				out = in* (-1);
			}
			break;
		}
	}
	return out;
}
