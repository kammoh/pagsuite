#include "fundamental.h"

void fundamental(int_set_t *set)
{
  int_set_t::iterator seti;
  int_t fun;

  for(seti = set->begin(); seti != set->end(); ++seti)
  {
    fun = fundamental(*seti);
    if(fun != *seti)
    {
      set->erase(*seti);
      set->insert(fun);
    }
  }
}

void fundamental(vec_set_t *set)
{
  vec_set_t::iterator seti;
  vec_t fun;

  for(seti = set->begin(); seti != set->end(); ++seti)
  {
    fun = fundamental(*seti);
    if(fun != *seti)
    {
      set->erase(*seti);
      set->insert(fun);
    }
  }
}
