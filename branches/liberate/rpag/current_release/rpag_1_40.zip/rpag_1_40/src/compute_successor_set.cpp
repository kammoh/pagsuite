#include "compute_successor_set.h"
#include "fundamental.h"
#include "log2_64.h"
#include "debug.h"
#include <cstdlib>
#include <cmath>
#include "norm.h"

//###################################################################################################
//#######################################     basis     #############################################
//###################################################################################################
void compute_successor_set(int_t r1, int_t r2, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    int_t s;

    if((r1 > c_max)||(r2 > c_max)) return;

    //for k=0, the fundamental() method hast to be called
    s=fundamental(r1 + r2);
#ifdef DEBUG
    IF_VERBOSE(7) cout << s << "=" << r1 << "+" << r2 << endl;
#endif
    if(s <= c_max) (*successor_set).insert(s);
#ifdef DEBUG
    if(s <= c_max) IF_VERBOSE(8) cout << s << "=|" << r1 << "+" << r2 << "|" << endl;
#endif
    if(s <= c_max) (*successor_set).insert(fundamental(abs(r1 - r2)));

    if(r1 < r2)
    {
      int_t temp = r1;
      r1 = r2;
      r2 = temp;
    }
    int k_max = log2c_64((int_t) ceil(((double)c_max+r1)/((double)r2)));
    if(k_max < 0) return;

#ifdef DEBUG
    IF_VERBOSE(7) cout << "r1=" << r1 << ", r2=" << r2 << ", k_max=" << k_max << ", c_max=" << c_max << endl;
#endif

    for(int k=1; k <= k_max; k++)
    {
        s=(r1 << k) + r2;
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << k << "*" << r1 << "+" << r2 << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=r1 + (r2 << k);
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << r1 << "+" << "2^" << k << "*" << r2 << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=abs((r1 << k) - r2);
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=|" << "2^" << k << "*" << r1 << "-" << r2 << "|" << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=abs(r1 - (r2 << k));
#ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=|" << r1 << "-" << "2^" << k << "*" << r2 << "|" << endl;
#endif
        if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
    }
    successor_set->erase(0);
    if(erase_predecessor)
    {
      successor_set->erase(r1);
      successor_set->erase(r2);
    }
  }
  else
  {
    compute_successor_set(r1,r2,c_max,successor_set,erase_predecessor);
    compute_successor_set(r1,r2,r2,c_max,successor_set,erase_predecessor);
    compute_successor_set(r1,r1,r2,c_max,successor_set,erase_predecessor);
  }
}

void compute_successor_set(const int_set_t *r1_set, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    int_t r1,r2,s;
    int k_max;

    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;
    
    for (r1_p=r1_set->begin(); r1_p != r1_set->end(); ++r1_p)
    {
        for (r2_p=r2_set->begin(); r2_p != r2_set->end(); ++r2_p) //!!!
        {    
            r1 = *r1_p;
            r2 = *r2_p;
            if(r1 < r2)
            {
              int_t temp = r1;
              r1 = r2;
              r2 = temp;
            }
            k_max = log2c_64((int_t) ceil(((double)c_max+r1)/((double)r2)));

            IF_VERBOSE(7) cout << "computing successor set of " << r1 << " and " << r2 << " k_max=" << k_max << endl;

            //for k=0, the fundamental() method hast to be called
            (*successor_set).insert(fundamental(r1 + r2));
            (*successor_set).insert(fundamental(abs(r1 - r2)));
            
            for(int k=1; k < k_max; k++)
            {
                s=(r1 << k) + r2;
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
                s=r1 + (r2 << k);
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
                s=abs((r1 << k) - r2);
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
                s=abs(r1 - (r2 << k));
                if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
            }
            if(erase_predecessor)
            {
              successor_set->erase(r1);
              successor_set->erase(r2);
            }
        }
    }
    successor_set->erase(0);
//    successor_set->erase(1);
  }
  else
  {
    // 3 input adders
    int_t r1,r2;

    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;

    for (r1_p=r1_set->begin(); r1_p != r1_set->end(); ++r1_p)
    {
      for (r2_p=r1_set->begin(); r2_p != r1_set->end(); ++r2_p) //!!!
      {
        r1 = *r1_p;
        r2 = *r2_p;
        compute_successor_set(r1,r1,r2,c_max,successor_set,erase_predecessor);
        compute_successor_set(r1,r2,r2,c_max,successor_set,erase_predecessor);
      }
    }
  }
}

//Diese Funktion lässt sich beschleunigen!!! Siehe fir_mcm_opt, "Berechnung der Nachfolgemenge" !!!!
void compute_successor_set(const int_set_t *realized_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  if(two_input_adder)
  {
    compute_successor_set(realized_set, realized_set, c_max, successor_set, erase_predecessor, two_input_adder);
  }
  else
  {
    // 3 input adders
    int_set_t::iterator r1_p;
    int_set_t::iterator r2_p;
    int_set_t::iterator r3_p;

    for (r1_p=realized_set->begin(); r1_p != realized_set->end(); ++r1_p)
    {
      for (r2_p=realized_set->begin(); r2_p != realized_set->end(); ++r2_p) //!!!
      {
        for (r3_p=realized_set->begin(); r3_p != realized_set->end(); ++r3_p) //!!!
        {
          compute_successor_set((*r1_p),(*r2_p),(*r3_p),c_max,successor_set,erase_predecessor);
        }
      }
    }
  }
}

/* This function is currently not used:
void compute_successor_set(int_t r1, const int_set_t *r2_set, int_t c_max, int_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
    int_set_t::iterator r2_p;

    for (r2_p=r2_set->begin(); r2_p != r2_set->end(); ++r2_p) //!!!
    {
      compute_successor_set(r1, *r2_p, c_max, successor_set, erase_predecessor, two_input_adder);
    }
}
*/

void compute_successor_set(vec_t r1, vec_t r2, int_t c_max, vec_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
	UNUSED(two_input_adder);
	vec_t s;
  int k_max = log2c_64((int_t) max(ceil(((double)c_max+abs(r2).max())/((double)abs(r1).min(true))),ceil(((double)c_max+abs(r1).max())/((double)abs(r2).min(true)))));

    //int_t k_max=log2c_64((int_t) round(c_max-(abs(r1).max()))/abs(r2).max());

    IF_VERBOSE(7) std::cout <<"k_max = " << k_max << std::endl;

    IF_VERBOSE(7) cout << "computing successor set of " << r1 << " and " << r2 << " k_max=" << k_max << endl;

    //for k=0, it isn't nessassery to check all
    s = fundamental(norm(r1 + r2));
    if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
    s = fundamental(norm(r1 - r2));
    if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
    s = fundamental(norm(r2 - r1));
    if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);

    for(int k=1; k < k_max; k++)
    {
        s=fundamental(norm((r1 << k) + r2));
        if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
        s=fundamental(norm(r1 + (r2 << k)));
        if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);

        s=fundamental(norm((r1 << k) - r2));
        if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
        s=fundamental(norm(r1 - (r2 << k)));
        if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
    }
    if(erase_predecessor)
    {
      successor_set->erase(r1);
      successor_set->erase(r2);
    }
}

void compute_successor_set(const vec_set_t *r1_set, const vec_set_t *r2_set, int_t c_max, vec_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{

  if(two_input_adder)
  {
    vec_t r1,r2,s;
    int k_max;

    vec_set_t::iterator r1_p;
    vec_set_t::iterator r2_p;

    for (r1_p=r1_set->begin(); r1_p != r1_set->end(); ++r1_p)
    {
        for (r2_p=r2_set->begin(); r2_p != r2_set->end(); ++r2_p) //!!!
        {

          r1 = *r1_p;
          r2 = *r2_p;

          k_max = log2c_64((int_t) max(ceil(((double)c_max+abs(r2).max())/((double)abs(r1).min(true))),ceil(((double)c_max+abs(r1).max())/((double)abs(r2).min(true)))));
          IF_VERBOSE(7) std::cout << std::endl << "r1 max=" << abs(r1).max() << "  r2 max=" << abs(r2).max() << "  k_max=" << k_max << std::endl;


          IF_VERBOSE(7) cout << "computing successor set of " << r1 << " and " << r2 << " k_max=" << k_max << endl;

          //for k=0, it isn't nessassery to check all
          s = fundamental(norm(r1 + r2));
          if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
          s = fundamental(norm(r1 - r2));
          if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
          s = fundamental(norm(r2 - r1));
          if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);

          for(int k=1; k < k_max; k++)
          {
              s=fundamental(norm((r1 << k) + r2));
              if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s); //as k_max can be too large such that s overflows, detect such an overflow
              s=fundamental(norm(r1 + (r2 << k)));
              if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);

              s=fundamental(norm((r1 << k) - r2));
              if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
              s=fundamental(norm(r1 - (r2 << k)));
              if((s != 0) && (abs(s) <= c_max)) (*successor_set).insert(s);
          }
          if(erase_predecessor)
          {
            successor_set->erase(r1);
            successor_set->erase(r2);
          }
      }
    }
//    successor_set->erase((int_t) 0); //!!!???
  }
  else
  {
    std::cout << "\n!! Error: in compute_successor_set(vec_set_t, vec_set_t,...) 3-input adder not implementet !!\n";
    exit(-1);
  }
}
void compute_successor_set(const vec_set_t *realized_set, int_t c_max, vec_set_t *successor_set, bool erase_predecessor, bool two_input_adder)
{
  compute_successor_set(realized_set, realized_set, c_max, successor_set, erase_predecessor, two_input_adder);
}

//###################################################################################################
//#######################################    3 input    #############################################
//###################################################################################################

void permut(int &a, int &b, int &c, int &k, int &l, int index)
{
  switch(index)
  {
  case 0:
    a = k;
    b = 0;
    c = l;
  break;
  case 1:
    a = l;
    b = k;
    c = 0;
  break;
  case 2:
    a = 0;
    b = l;
    c = k;
  break;
  case 3:
    a = k;
    b = l;
    c = 0;
  break;
  case 4:
    a = l;
    b = 0;
    c = k;
  break;
  case 5:
    a = 0;
    b = k;
    c = l;
  break;
  default:
    std::cout << "unknown index in: void permut(int &a, int &b, int &c, int &k, int &l, int index)" << std::endl;
    exit(-1);
  break;
  }

}

void compute_successor_set(int_t r1, int_t r2, int_t r3, int_t c_max, int_set_t *successor_set, bool erase_predecessor)
{
  int a = 0;
  int b = 0;
  int c = 0;
  int permut_border = 6;

  r1 = fundamental(r1);
  r2 = fundamental(r2);
  r3 = fundamental(r3);
  //set r1 to the maximum value
  { //to make r1 > r2 > r3
    int tmp;
    if(r3 > r2)
    {
        tmp = r2;
        r2 = r3;
        r3 = tmp;
    }
    if(r2 > r1)
    {
        tmp = r1;
        r1 = r2;
        r2 = tmp;
    }
    if(r3 > r2)
    {
        tmp = r2;
        r2 = r3;
        r3 = tmp;
    }
  }
  int_t s;

  if(r1 > c_max) return;

  int k_max = log2c_64((int_t) ceil(((double)c_max+r1)/((double)r3)));
  if(k_max < 0) return;

#ifdef DEBUG
  IF_VERBOSE(7) cout << "r1=" << r1 << ", r2=" << r2 << ", r3=" << r3 << ", k_max=" << k_max << ", c_max=" << c_max << endl;
#endif


  for(int k = 0; k <= k_max; k++)
  {
    for(int l = 0; l <= k; l++)
    {
      if((k == l)||(k==0)||(l==0)){permut_border = 3;} else {permut_border = 6;}//if k = l it's not necessary to switch k and l

      for(int permut_counter = 0; permut_counter < permut_border; permut_counter++)
      {
        permut(a,b,c,k,l,permut_counter);

        s = abs((r1<<a) + (r2<<b) + (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) + (r2<<b) - (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) - (r2<<b) + (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs((r1<<a) - (r2<<b) - (r3<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl << std::endl;
        #endif

        /* unnoetig da durch bereits abgedekt
        s = abs(-(r1<<a) + (r2<<b) + (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs(-(r1<<a) + (r2<<b) - (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " + " << "2^" << b << " * " << r2 << " - " << "2^" << c << " * " << r3 << std::endl;
        #endif

        s = abs(-(r1<<a) - (r2<<b) + (r2<<c));
        if((s > 0) && (s <= c_max)) (*successor_set).insert(fundamental(s));
        #ifdef DEBUG
        IF_VERBOSE(8) cout << s << "=" << "-2^" << a << " * " << r1 << " - " << "2^" << b << " * " << r2 << " + " << "2^" << c << " * " << r3 << std::endl << std::endl;
        #endif


        //unnoetig da durch  + + + bereits abgedekt
        //s = abs(-r1<<a - r2<<b - r2<<c);
        //if((s > 0) && (s <= c_max)) (*successor_set).insert(s);
        */
      }
    }
  }
  successor_set->erase(0);
  //successor_set->erase(1); //!!!!!!!!!!!
  if(erase_predecessor)
  {
    successor_set->erase(r1);
    successor_set->erase(r2);
    successor_set->erase(r3);
  }
}
