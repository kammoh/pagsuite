#ifndef MT_LIMITS_H
#define MT_LIMITS_H

namespace mt_limits {
    extern const unsigned int limit_cfgs;
    extern const unsigned int limit_nodes[];
}



#endif // MT_LIMITS_H
