% adder_depth_cached_prepare() loads data for adder_depth_cached

function adder_depth_cached_prepare()

global numberdata;
load('numberdata2_20');

